How to generate configure:

aclocal -I tclconfig
autoconf

Running configure will generate a package that will load the Cairo/Gtk
libraries dynamically.
Use --disable-dynamicgtk to link with the Cairo/Gtk libraries.
