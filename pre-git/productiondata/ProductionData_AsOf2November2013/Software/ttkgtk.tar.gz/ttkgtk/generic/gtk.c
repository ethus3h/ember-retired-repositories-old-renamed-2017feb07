/*
 * gtk.c 
 * -------------------
 *
 * This file is part of the TtkGtk package, a Ttk based theme that uses
 * Gtk/GNOME for drawing.
 *
 * Copyright (C) 2012 by:
 * Georgios Petasis, petasis@iit.demokritos.gr, petasisg@yahoo.gr
 * Software and Knowledge Engineering Laboratory,
 * Institute of Informatics and Telecommunications,
 * National Centre for Scientific Research (NCSR) "Demokritos",
 * Aghia Paraskevi, 153 10, Athens, Greece.
 *
 */

#include "symbols.h"
#include "gtktheme.h"
#include <string.h>

/*
 * Declaration of functions defined in cairo.c.
 */
extern cairo_t *TtkGtk_GetCairoDrawingContext(Tk_Window tkwin, Drawable d);
extern void TtkGtk_DestroyCairoDrawingContext(cairo_t *surface);

extern const char *const  TtkGtk_stateNames[];        /* In gtktheme.c */
extern const unsigned int TtkGtk_StateNames[];        /* In gtktheme.c */
extern const char *const  TtkGtk_classNames[];        /* In gtktheme.c */
extern const char *const  TtkGtk_classNameDefines[];  /* In gtktheme.c */
#ifndef LINK_TO_GTK
extern TtkGtk_SymbolTable TtkGtk_symbols;             /* In symbols.c  */
extern int TtkGtk_LoadGtkSymbols(Tcl_Interp *interp, Tcl_LoadHandle lh);
#endif

/*
 * Declarations of functions defined in this file.
 */
GtkStyleContext *TtkGtk_GetGtkStyleContext(void);

TCL_DECLARE_MUTEX(ttkgtkMutex2);

/*
 * ============================================================================
 *  Gtk helper commands...
 * ============================================================================
 */

int TtkGtk_ThemeNameObjCmd(ClientData clientData, Tcl_Interp *interp,
                           int objc, Tcl_Obj *const objv[]) {
  GtkSettings *settings = NULL;
  GValue      *value;
  if (objc != 1) {Tcl_WrongNumArgs(interp, 1, objv, ""); return TCL_ERROR;}

  value = ckalloc(sizeof(GValue));
  memset(value, 0, sizeof(GValue));
  Tcl_MutexLock(&ttkgtkMutex2);
  settings = TtkGtk_gtk_settings_get_default();
  if (settings) {
    TtkGtk_g_value_init(value, G_TYPE_STRING);
    TtkGtk_g_object_get_property((GObject *)settings, "gtk-theme-name", value);
    Tcl_SetResult(interp, (char *) TtkGtk_g_value_get_string(value),
                          TCL_VOLATILE);
    TtkGtk_g_value_unset(value);
  }
  Tcl_MutexUnlock(&ttkgtkMutex2);
  ckfree(value);
  return TCL_OK;
}; /* Tilegtk_ThemeNameObjCmd */

int TtkGtk_ThemeColorObjCmd(ClientData clientData, Tcl_Interp *interp,
                            int objc, Tcl_Obj *const objv[]) {
  static const char *Methods[] = {
    "foreground", "background", (char *) NULL
  };
  enum methods {
    FOREGROUND,    BACKGROUND
  };
  GtkThemeData *themeData = (GtkThemeData *) clientData;
  GtkStyleContext *context;
  GdkRGBA color;
  int section, state;
  XColor c;

  if (themeData == NULL) {
    Tcl_SetResult(interp, "cannot find current theme", TCL_STATIC);
    return TCL_ERROR;
  }

  if (objc != 3) {
    Tcl_WrongNumArgs(interp, 1, objv, "foreground|background gtk-state");
    return TCL_ERROR;
  }

  if (Tcl_GetIndexFromObj(interp, objv[1], (const char **) Methods,
                          "method", 0, &section) != TCL_OK) {
    return TCL_ERROR;
  }
  if (Tcl_GetIndexFromObj(interp, objv[2], (const char **) TtkGtk_stateNames,
                          "gtk-state", 0, &state) != TCL_OK) {
    return TCL_ERROR;
  }

  /* Allocate a context... */
  /* context = TtkGtk_GetGtkStyleContext(); */
  context = themeData->context;
  if (context == NULL) {
    Tcl_SetResult(interp, "cannot allocate style context", TCL_STATIC);
    return TCL_ERROR;
  }
  
  switch ((enum methods) section) {
    case FOREGROUND:
      TtkGtk_gtk_style_context_get_color(context,
                 TtkGtk_StateNames[state], &color);
      break;
    case BACKGROUND:
      TtkGtk_gtk_style_context_get_background_color(context,
                 TtkGtk_StateNames[state], &color);
      break;
  }
  c.red   = (unsigned short) (color.red   * 65535);
  c.green = (unsigned short) (color.green * 65535);
  c.blue  = (unsigned short) (color.blue  * 65535);

  Tcl_SetResult(interp, (char *) Tk_NameOfColor(&c), TCL_VOLATILE);
  
  return TCL_OK;
}; /* TtkGtk_ThemeColorObjCmd */

int TtkGtk_ThemePropertyObjCmd(ClientData clientData, Tcl_Interp *interp,
                               int objc, Tcl_Obj *const objv[]) {
  GtkThemeData *themeData = (GtkThemeData *) clientData;
  GtkStyleContext *context;
  int classNameIndex = 0;
  const char *property;
  GValue *value;

  if (themeData == NULL) {
    Tcl_SetResult(interp, "cannot find current theme", TCL_STATIC);
    return TCL_ERROR;
  }

  if (objc != 3) {
    Tcl_WrongNumArgs(interp, 1, objv, "widget property");
    return TCL_ERROR;
  }

  /* Get the widget class name */
  if (Tcl_GetIndexFromObj(interp, objv[1], TtkGtk_classNames,
                    "className", 0, &classNameIndex) != TCL_OK) {
    if (Tcl_GetIndexFromObj(interp, objv[1], TtkGtk_classNameDefines,
                    "className", 0, &classNameIndex) != TCL_OK) {
      /* This is not a Gtk class name */
      /* Tcl_SetResult(interp, "invalid class name: ", TCL_STATIC);
         Tcl_AppendResult(interp, Tcl_GetString(objv[0]), NULL); */
      return TCL_ERROR;
    }
  }
  Tcl_ResetResult(interp);

  property = Tcl_GetString(objv[2]);

  /* Get the Gtk style context */
  if (themeData->class_context[classNameIndex] != NULL) {
    context = themeData->class_context[classNameIndex];
  } else {
    context = themeData->context;
  }

  if (context == NULL) {
    Tcl_SetResult(interp, "cannot find current context", TCL_STATIC);
    return TCL_ERROR;
  }

  value = ckalloc(sizeof(GValue));
  memset(value, 0, sizeof(GValue));
  TtkGtk_g_value_init(value, G_TYPE_STRING);
  TtkGtk_gtk_style_context_get_style_property(context, property, value);

  Tcl_SetResult(interp, (char *) TtkGtk_g_value_get_string(value),
                        TCL_VOLATILE);
  TtkGtk_g_value_unset(value);
  ckfree(value);

  return TCL_OK;
}; /* TtkGtk_ThemePropertyObjCmd */

/*
 * ============================================================================
 *  Gtk initialisation...
 * ============================================================================
 */

static int TtkGtk_GtkLibraryLoaded = 0;
extern int TtkGtkTheme_Init(Tcl_Interp *interp, GtkThemeData **td);

int TtkGtk_GtkInit(ClientData clientData, Tcl_Interp *interp,
                   int objc, Tcl_Obj *const objv[]) {
#ifndef LINK_TO_GTK
  Tcl_LoadHandle lh;
#endif
  int argc = 0;
  char **argv = NULL;
  GtkThemeData *themeData;

#ifndef LINK_TO_GTK
  if (objc != 2) {
    Tcl_WrongNumArgs(interp, 1, objv, "gtk-library-filename");
    return TCL_ERROR;
  }
#endif

  if (TtkGtk_GtkLibraryLoaded == 0) {
    Tcl_MutexLock(&ttkgtkMutex2);

#ifndef LINK_TO_GTK
    /*
     * Load the library provided by the first argument...
     */
    if (Tcl_LoadFile(interp, objv[1], NULL, 0, NULL, &lh) != TCL_OK) {
      Tcl_MutexUnlock(&ttkgtkMutex2);
      return TCL_ERROR;
    }

    /*
     * Load the needed symbols from the library...
     */
    if (TtkGtk_LoadGtkSymbols(interp, lh) != TCL_OK) {
      Tcl_MutexUnlock(&ttkgtkMutex2);
      return TCL_ERROR;
    }
#endif /* LINK_TO_GTK */

    /*
     * Initialise Gtk...
     */
    TtkGtk_gtk_init(&argc, &argv);

    TtkGtk_GtkLibraryLoaded = 1;
    Tcl_MutexUnlock(&ttkgtkMutex2);
  }; /* if (!TtkGtk_GtkLibraryLoaded) */

  if (!TtkGtk_GtkLibraryLoaded) return TCL_ERROR;

  /*
   * Initialise the Gtk theme...
   */
  if (TtkGtkTheme_Init(interp, &themeData) != TCL_OK) return TCL_ERROR;

  /*
   * Helper commands:
   */
  Tcl_CreateObjCommand(interp, "::ttk::theme::" PACKAGE_NAME
                               "::currentThemeName",
      TtkGtk_ThemeNameObjCmd, (ClientData) themeData, NULL);
  Tcl_CreateObjCommand(interp, "::ttk::theme::" PACKAGE_NAME
                               "::currentThemeColor",
      TtkGtk_ThemeColorObjCmd, (ClientData) themeData, NULL);
  Tcl_CreateObjCommand(interp, "::ttk::theme::" PACKAGE_NAME
                               "::currentThemeProperty",
      TtkGtk_ThemePropertyObjCmd, (ClientData) themeData, NULL);

  return TCL_OK;
}; /* TtkGtk_GtkInit */

/*
 * ============================================================================
 *  Gtk style context helper functions...
 * ============================================================================
 */

GtkStyleContext *TtkGtk_GetGtkStyleContext(void) {
  GtkStyleContext *sc = TtkGtk_gtk_style_context_new();
  GtkWidgetPath *path;
  if (sc == NULL) return NULL;

  path = TtkGtk_gtk_widget_path_new();
  TtkGtk_gtk_widget_path_append_type(path, TtkGtk_gtk_window_get_type());

  TtkGtk_gtk_style_context_set_screen(sc, TtkGtk_gdk_screen_get_default());
  TtkGtk_gtk_style_context_set_path(sc, path);
  TtkGtk_gtk_style_context_set_state(sc, 0);
  TtkGtk_gtk_widget_path_free(path);
  return sc;
}; /* TtkGtk_GetGtkStyleContext */

GtkStyleContext *TtkGtk_GetGtkStyleContextForType(ptr_class_get_type fn) {
  GtkStyleContext *sc = TtkGtk_gtk_style_context_new();
  GtkWidgetPath *path;
  if (sc == NULL) return NULL;

  path = TtkGtk_gtk_widget_path_new();
  TtkGtk_gtk_widget_path_append_type(path, TtkGtk_gtk_window_get_type());
  TtkGtk_gtk_widget_path_append_type(path, fn());

  TtkGtk_gtk_style_context_set_screen(sc, TtkGtk_gdk_screen_get_default());
  TtkGtk_gtk_style_context_set_path(sc, path);
  TtkGtk_gtk_style_context_set_state(sc, 0);
  TtkGtk_gtk_widget_path_free(path);
  return sc;
}; /* TtkGtk_GetGtkStyleContextForType */

GtkStyleContext *TtkGtk_GetGtkStyleContextForSpinButton(void) {
  GtkStyleContext *sc = TtkGtk_gtk_style_context_new();
  GtkWidgetPath *path, *siblings_path;
  gint up_pos, down_pos;
  GType spin;

  if (sc == NULL) return NULL;

  path          = TtkGtk_gtk_widget_path_new();
  siblings_path = TtkGtk_gtk_widget_path_new();

  spin = TtkGtk_gtk_spin_button_get_type();
  TtkGtk_gtk_widget_path_append_type(path, TtkGtk_gtk_window_get_type());
  TtkGtk_gtk_widget_path_append_type(path, spin);

  TtkGtk_gtk_widget_path_append_type(siblings_path,TtkGtk_gtk_entry_get_type());
  down_pos = TtkGtk_gtk_widget_path_append_type(siblings_path, spin);
  up_pos   = TtkGtk_gtk_widget_path_append_type(siblings_path, spin);

  TtkGtk_gtk_widget_path_iter_add_class(siblings_path, up_pos,
                                        GTK_STYLE_CLASS_BUTTON);
  TtkGtk_gtk_widget_path_iter_add_class(siblings_path, down_pos,
                                        GTK_STYLE_CLASS_BUTTON);

  /* this allows compatibility for themes that use .spinbutton.button */
  TtkGtk_gtk_widget_path_iter_add_class(siblings_path, up_pos,
                                        GTK_STYLE_CLASS_SPINBUTTON);
  TtkGtk_gtk_widget_path_iter_add_class(siblings_path, down_pos,
                                        GTK_STYLE_CLASS_SPINBUTTON);

  TtkGtk_gtk_widget_path_append_with_siblings(path, siblings_path, up_pos);
  TtkGtk_gtk_widget_path_append_with_siblings(path, siblings_path, down_pos);

  TtkGtk_gtk_style_context_set_screen(sc, TtkGtk_gdk_screen_get_default());
  TtkGtk_gtk_style_context_set_path(sc, path);
  TtkGtk_gtk_style_context_set_state(sc, 0);
  TtkGtk_gtk_widget_path_free(path);
  TtkGtk_gtk_widget_path_free(siblings_path);
  return sc;
}; /* TtkGtk_GetGtkStyleContextForSpinButton */

void TtkGtk_AllocateCairoContexts(GtkThemeData *themeData) {
  if (themeData == NULL) return;
  /* Generic style context */
  themeData->context = TtkGtk_GetGtkStyleContext();
  /* Context for: GTK_TYPE_BUTTON */
  themeData->class_context[CN_CLASS_BUTTON] =
    TtkGtk_GetGtkStyleContextForType(TtkGtk_gtk_button_get_type);
  /* Context for: GTK_TYPE_CHECK_BUTTON/GTK_TYPE_TOGGLE_BUTTON */
  themeData->class_context[CN_CLASS_CHECK] =
    TtkGtk_GetGtkStyleContextForType(TtkGtk_gtk_check_button_get_type);
  /* Context for: GTK_TYPE_RADIO_BUTTON */
  themeData->class_context[CN_CLASS_RADIO] =
    TtkGtk_GetGtkStyleContextForType(TtkGtk_gtk_radio_button_get_type);
  /* Context for: GTK_TYPE_SPIN_BUTTON */
  themeData->class_context[CN_CLASS_SPINBUTTON] =
    TtkGtk_GetGtkStyleContextForSpinButton();
  /* Context for: GTK_TYPE_ENTRY */
  themeData->class_context[CN_CLASS_ENTRY] =
    TtkGtk_GetGtkStyleContextForType(TtkGtk_gtk_entry_get_type);
  /* Context for: GTK_TYPE_COMBO_BOX */
  themeData->class_context[CN_CLASS_COMBOBOX_ENTRY] =
    TtkGtk_GetGtkStyleContextForType(TtkGtk_gtk_combo_box_get_type);
  /* Context for: GTK_TYPE_SCALE */
  themeData->class_context[CN_CLASS_SCALE] =
    TtkGtk_GetGtkStyleContextForType(TtkGtk_gtk_scale_get_type);
  /* Context for: GTK_TYPE_PROGRESSBAR */
  themeData->class_context[CN_CLASS_PROGRESSBAR] =
    TtkGtk_GetGtkStyleContextForType(TtkGtk_gtk_progress_bar_get_type);
  /* Context for: GTK_TYPE_SCROLLBAR */
  themeData->class_context[CN_CLASS_SCROLLBAR] =
    TtkGtk_GetGtkStyleContextForType(TtkGtk_gtk_scrollbar_get_type);
  TtkGtk_gtk_style_context_set_junction_sides(
             themeData->class_context[CN_CLASS_SCROLLBAR], GTK_JUNCTION_NONE);
  /* Context for: GTK_TYPE_NOTEBOOK */
  themeData->class_context[CN_CLASS_NOTEBOOK] =
    TtkGtk_GetGtkStyleContextForType(TtkGtk_gtk_notebook_get_type);
  /* Context for: GTK_TYPE_PANE_SEPARATOR */
  themeData->class_context[CN_CLASS_PANE_SEPARATOR] =
    TtkGtk_GetGtkStyleContextForType(TtkGtk_gtk_paned_get_type);
  /* Context for: GTK_TYPE_FRAME */
  themeData->class_context[CN_CLASS_FRAME] =
    TtkGtk_GetGtkStyleContextForType(TtkGtk_gtk_frame_get_type);
  /* Context for: GTK_TYPE_VIEW */
  themeData->class_context[CN_CLASS_VIEW] =
    TtkGtk_GetGtkStyleContextForType(TtkGtk_gtk_tree_view_get_type);
  /* Context for: GTK_TYPE_ARROW */
  themeData->class_context[CN_CLASS_ARROW] =
    TtkGtk_GetGtkStyleContextForType(TtkGtk_gtk_arrow_get_type);
}; /* TtkGtk_AllocateCairoContexts */

/*
 * ============================================================================
 * ============================================================================
 * ============================================================================
 *   Ttk Generic Element size calculation...
 * ============================================================================
 * ============================================================================
 * ============================================================================
 */

void TtkGtk_AddOrientationClass(GtkStyleContext *context,
                                ElementData *elementData) {
  /* Add orientation */
  switch ((GtkOrientation) elementData->info->orientation) {
    case GTK_ORIENTATION_HORIZONTAL:
      TtkGtk_gtk_style_context_add_class(context, GTK_STYLE_CLASS_HORIZONTAL);
      break;
    case GTK_ORIENTATION_VERTICAL:
      TtkGtk_gtk_style_context_add_class(context, GTK_STYLE_CLASS_VERTICAL);
      break;
    default:
      break;
  };
}; /* TtkGtk_AddOrientationClass */

#define ADD_BORDER(x) \
  left   += (x).left; \
  top    += (x).top; \
  right  += (x).right; \
  bottom += (x).bottom;

#define ADD_INTEGER(x) \
  left   += (x); \
  top    += (x); \
  right  += (x); \
  bottom += (x);

void TtkGtk_ElementSize(ElementData *elementData, Tk_Window tkwin,
                        int *widthPtr, int *heightPtr, Ttk_Padding *paddingPtr) {
  GtkStyleContext *context;
  GtkBorder padding;
  unsigned int left = 0, top = 0, right = 0, bottom = 0, w = 0, h = 0;

  /* Get the Gtk style context */
  if (elementData->themeData->class_context[elementData->info->classNameIndex]
                            != NULL) {
    context =
       elementData->themeData->class_context[elementData->info->classNameIndex];
  } else {
    context = elementData->themeData->context;
  }
  /* Save the current context */
  TtkGtk_gtk_style_context_save(context);
  /* Set the style context state */
  TtkGtk_gtk_style_context_set_state(context, 0);
  /* Add the class */
  TtkGtk_gtk_style_context_add_class(context, elementData->info->className);

  /* Get the default padding */
  TtkGtk_gtk_style_context_get_padding(context, 0, &padding);
  ADD_BORDER(padding);

  /* Get the default border */
  TtkGtk_gtk_style_context_get_border(context, 0, &padding);
  ADD_BORDER(padding);

  /*
   * Get the dimensions according to part
   */
  switch ((enum TtkGtk_PartNames) elementData->info->partId) {
    case PN_ARROW:
      switch ((enum TtkGtk_ClassNames) elementData->info->classNameIndex) {
        case CN_CLASS_SCROLLBAR: {
          gint size, spacing, trough_border;
          TtkGtk_gtk_style_context_get_style(context,
                 "stepper-size",     &size,
                 "stepper-spacing",  &spacing,
                 "trough-border",    &trough_border,
                 NULL);
          w += size; h += size;
          ADD_INTEGER(trough_border + spacing);
          break;
        }
        case CN_CLASS_COMBOBOX_ENTRY: {
          gint size = 15;
          TtkGtk_gtk_style_context_get_style(context,
                 "arrow-size",     &size,
                 NULL);
          w += size; h += size;
          break;
        }
        case CN_CLASS_ARROW:
          w += 15; h += 15;
          break;
        default:
          break;
      }
      break;
    case PN_BACKGROUND:
    case PN_BACKGROUND_FRAME:
      switch ((enum TtkGtk_ClassNames) elementData->info->classNameIndex) {
        case CN_CLASS_PROGRESSBAR:
          TtkGtk_AddOrientationClass(context, elementData);
          if (elementData->info->orientation == GTK_ORIENTATION_VERTICAL) {
            gint mw, mh;
            TtkGtk_gtk_style_context_get_style(context,
                 "min-vertical-bar-width",  &mw,
                 "min-vertical-bar-height", &mh,
                 NULL);
            w += mw; h += mh;
          } else {
            gint mw, mh;
            TtkGtk_gtk_style_context_get_style(context,
                 "min-horizontal-bar-width",  &mw,
                 "min-horizontal-bar-height", &mh,
                 NULL);
            w += mw; h += mh;
          }
          break;
        default:
          break;
      }
      break;
    case PN_CHECK: {
      gint indicator_size = 16, indicator_spacing = 2;
      TtkGtk_gtk_style_context_get_style(context,
             "indicator-size",    &indicator_size,
             "indicator-spacing", &indicator_spacing,
             NULL);
      w = h = (int) indicator_size;
      left += indicator_spacing; right += indicator_spacing;
      break;
    }
    case PN_EXPANDER:
      switch ((enum TtkGtk_ClassNames) elementData->info->classNameIndex) {
        case CN_CLASS_VIEW: {
          gint expander_size = 14;
          TtkGtk_gtk_style_context_get_style(context,
             "expander-size", &expander_size,
             NULL);
          w = h = (int) expander_size;
          break;
        }
        default:
          break;
      }
      break;
    case PN_EXTENSION:
      switch ((enum TtkGtk_ClassNames) elementData->info->classNameIndex) {
        case CN_CLASS_NOTEBOOK: {
          gint initial_gap = 0, tab_curvature = 1, focus_width = 1,
               focus_padding = 0;
          TtkGtk_gtk_style_context_get_style(context,
             "focus-line-width", &focus_width,
             "focus-padding",    &focus_padding,
             "initial-gap",      &initial_gap,
             "tab-curvature",    &tab_curvature,
             NULL);
          ADD_INTEGER(tab_curvature + focus_width + focus_padding);
          break;
        }
        default:
          break;
      }
      break;
    case PN_FOCUS: {
      gint focus_width = 1, focus_pad = 0;
      TtkGtk_gtk_style_context_get_style(context,
             "focus-line-width", &focus_width,
             "focus-padding",    &focus_pad,
             NULL);
      ADD_INTEGER(focus_width+focus_pad);
      break;
    }
    case PN_FRAME:
      break;
    case PN_FRAME_GAP:
      break;
    case PN_HANDLE:
      switch ((enum TtkGtk_ClassNames) elementData->info->classNameIndex) {
        case CN_CLASS_GRIP: {
          gint mw = 16, mh = 16;
          TtkGtk_gtk_style_context_get_style(context,
               "resize-grip-width",  &mw,
               "resize-grip-height", &mh,
               NULL);
          w += mw; h += mh;
          break;
        }
        case CN_CLASS_PANE_SEPARATOR: {
          gint size = 5;
          TtkGtk_gtk_style_context_get_style(context,
               "handle-size",  &size,
               NULL);
          w += size; h += size;
          break;
        }
        default:
          break;
      }
      break;
    case PN_LAYOUT:
      break;
    case PN_LINE:
      break;
    case PN_OPTION:
      break;
    case PN_SLIDER:
    case PN_ACTIVITY:
      TtkGtk_AddOrientationClass(context, elementData);
      switch ((enum TtkGtk_ClassNames) elementData->info->classNameIndex) {
        case CN_CLASS_SCALE: {
          gint focus_padding, slider_width, slider_length, value_spacing;
          TtkGtk_gtk_style_context_get_style(context,
                 "focus-padding", &focus_padding,
                 "slider-width",  &slider_width,
                 "slider-length", &slider_length,
                 "value-spacing", &value_spacing,
                 NULL);
          if (elementData->info->orientation == GTK_ORIENTATION_VERTICAL) {
            w += slider_width;  h += slider_length;
          } else {
            w += slider_length; h += slider_width;
          }
          break;
        }
        case CN_CLASS_SCROLLBAR: {
          gint slider_width, slider_length, trough_border = 1;
          TtkGtk_gtk_style_context_get_style(context,
                 "slider-width",      &slider_width,
                 "min-slider-length", &slider_length,
                 "trough-border",     &trough_border,
                 NULL);
          if (elementData->info->orientation == GTK_ORIENTATION_VERTICAL) {
            w += slider_width;  h += slider_length;
          } else {
            w += slider_length; h += slider_width;
          }
          ADD_INTEGER(trough_border);
          break;
        }
        default:
          break;
      }
      break;
    case PN_ICON_PIXBUF:
      break;
    case PN_ICON: {
      GtkSettings *settings = NULL;
      gint width, height;
      width = height = elementData->info->size;
      settings = TtkGtk_gtk_settings_get_default();
      if (settings) {
        TtkGtk_gtk_icon_size_lookup_for_settings (settings,
					       elementData->info->size,
					       &width, &height);
      }
      w += width;
      h += height;
      break;
    }
    case PN_INSERTION_CURSOR:
      break;
    case PN_HEADER_ROW: {
      /* Headers are buttons, so get the button dimensions... */
      GtkStyleContext *button_context;
      GtkBorder *tmp_border;
      gint focus_width = 1, focus_pad = 0;
      left = top = right = bottom = 0;

      button_context = elementData->themeData->class_context[CN_CLASS_BUTTON];
      TtkGtk_gtk_style_context_save(button_context);
      TtkGtk_gtk_style_context_set_state(button_context, 0);
      TtkGtk_gtk_style_context_add_class(button_context,GTK_STYLE_CLASS_BUTTON);
      TtkGtk_gtk_style_context_get_padding(button_context, 0, &padding);
      ADD_BORDER(padding);
      TtkGtk_gtk_style_context_get_border(button_context, 0, &padding);
      ADD_BORDER(padding);
      TtkGtk_gtk_style_context_get_style(button_context,
             "default-border", &tmp_border, NULL);
      if (tmp_border) {
        ADD_BORDER(*tmp_border);
        TtkGtk_gtk_border_free(tmp_border);
      } else {
        ADD_INTEGER(1);
      }
      TtkGtk_gtk_style_context_get_style(button_context,
             "default-outside-border", &tmp_border, NULL);
      if (tmp_border) {
        ADD_BORDER(*tmp_border);
        TtkGtk_gtk_border_free(tmp_border);
      }
      TtkGtk_gtk_style_context_get_style(context,
             "focus-line-width", &focus_width,
             "focus-padding",    &focus_pad,
             NULL);
      ADD_INTEGER(focus_width+focus_pad);
      TtkGtk_gtk_style_context_restore(button_context);
      break;
    }
    case PN_BUTTON: {
      GtkBorder *tmp_border;
      TtkGtk_gtk_style_context_get_style(context,
             "default-border", &tmp_border, NULL);
      if (tmp_border) {
        ADD_BORDER(*tmp_border);
        TtkGtk_gtk_border_free(tmp_border);
      } else {
        ADD_INTEGER(1);
      }
      TtkGtk_gtk_style_context_get_style(context,
             "default-outside-border", &tmp_border, NULL);
      if (tmp_border) {
        ADD_BORDER(*tmp_border);
        TtkGtk_gtk_border_free(tmp_border);
      }
      break;
    }
    case PN_SEPARATOR: {
      gboolean wide_sep;
      gint     sep_width;
      gint     sep_height;
      TtkGtk_gtk_style_context_get_style(context,
             "wide-separators",  &wide_sep,
             "separator-width",  &sep_width,
             "separator-height", &sep_height,
             NULL);
      if (elementData->info->orientation == GTK_ORIENTATION_VERTICAL) {
         h += wide_sep ? sep_height : 0;
         //w += wide_sep ? sep_height : 0;
      } else {
         w += wide_sep ? sep_width  : 0;
         //h += wide_sep ? sep_width  : 0;
      }
      break;
    }
    default:
      break;
  }
  *widthPtr   = w;
  *heightPtr  = h;
  *paddingPtr = Ttk_MakePadding(left, top, right, bottom);
  /* Restore the saved context */
  TtkGtk_gtk_style_context_restore(context);
}; /* TtkGtk_ElementSize */

/*
 * ============================================================================
 * ============================================================================
 * ============================================================================
 *   Ttk Generic Element Draw...
 * ============================================================================
 * ============================================================================
 * ============================================================================
 */

void TtkGtk_RenderElement(ElementData *elementData, Tk_Window tkwin, Drawable d,
                          Ttk_Box b, unsigned int state,
                                     unsigned int ttk_state) {
  GtkStyleContext *context;

  /* Get the Gtk style context */
  if (elementData->themeData->class_context[elementData->info->classNameIndex]
                            != NULL) {
    context =
       elementData->themeData->class_context[elementData->info->classNameIndex];
  } else {
    context = elementData->themeData->context;
  }
  /* Save the current context */
  TtkGtk_gtk_style_context_save(context);
  /* Get the Cairo drawing context */
  cairo_t *cr = TtkGtk_GetCairoDrawingContext(tkwin, d);
  /* Set the style context state */
  TtkGtk_gtk_style_context_set_state(context, state);
  /* Add the class */
  TtkGtk_gtk_style_context_add_class(context, elementData->info->className);

  /*
   * Render the element according to part id
   */
  switch ((enum TtkGtk_PartNames) elementData->info->partId) {
    case PN_ARROW: {
      gdouble angle, size = b.width;
      gfloat scaling = 1.0;
      gint arrow_x = b.x, arrow_y = b.y;
      switch ((GtkArrowType) elementData->info->orientation) {
        case GTK_ARROW_RIGHT:
          angle = G_PI / 2;
          TtkGtk_gtk_style_context_add_class(context, GTK_STYLE_CLASS_RIGHT);
          break;
        case GTK_ARROW_DOWN:
          angle = G_PI;
          TtkGtk_gtk_style_context_add_class(context, GTK_STYLE_CLASS_BOTTOM);
          break;
        case GTK_ARROW_LEFT:
          angle = 3 * (G_PI / 2);
          TtkGtk_gtk_style_context_add_class(context, GTK_STYLE_CLASS_LEFT);
          break;
        case GTK_ARROW_UP:
        default:
          angle = 0;
          TtkGtk_gtk_style_context_add_class(context, GTK_STYLE_CLASS_TOP);
          break;
      }

      switch ((enum TtkGtk_ClassNames) elementData->info->classNameIndex) {
        case CN_CLASS_SCROLLBAR:
          scaling = 0.5;
          TtkGtk_gtk_style_context_add_class(context, GTK_STYLE_CLASS_BUTTON);
          TtkGtk_gtk_render_background(context, cr, b.x, b.y, b.width,b.height);
          TtkGtk_gtk_render_frame(context, cr, b.x, b.y, b.width, b.height);
          TtkGtk_gtk_style_context_get_style(context,
             "arrow-scaling", &scaling, NULL);
          break;
        case CN_CLASS_COMBOBOX_ENTRY:
          TtkGtk_gtk_style_context_get_style(context,
             "arrow-scaling", &scaling, NULL);
          break;
        case CN_CLASS_ARROW:
          TtkGtk_gtk_style_context_add_class(context, GTK_STYLE_CLASS_ARROW);
          TtkGtk_gtk_style_context_get_style(context,
             "arrow-scaling", &scaling, NULL);
          break;
        default:
          break;
      }
      size = MIN (b.width, b.height) * scaling;
      arrow_x = b.x + (b.width  - size) / 2;
      arrow_y = b.y + (b.height - size) / 2;
      
      TtkGtk_gtk_render_arrow(context, cr, angle, arrow_x, arrow_y, size);
      break;
    }
    case PN_BACKGROUND:
      switch ((enum TtkGtk_ClassNames) elementData->info->classNameIndex) {
        case CN_CLASS_CHECK:
          if (state & GTK_STATE_FLAG_PRELIGHT) {
            TtkGtk_gtk_render_background(context, cr, b.x, b.y,
                                         b.width, b.height);
          }
          break;
        default:
         TtkGtk_gtk_render_background(context, cr, b.x, b.y, b.width, b.height);
        break;
      }
      break;
    case PN_CHECK:
      TtkGtk_gtk_render_check(context, cr, b.x, b.y, b.width, b.height);
      break;
    case PN_EXPANDER:
      switch ((enum TtkGtk_ClassNames) elementData->info->classNameIndex) {
        case CN_CLASS_VIEW:
          TtkGtk_gtk_style_context_add_class(context, GTK_STYLE_CLASS_EXPANDER);
          TtkGtk_gtk_style_context_set_state(context, state);
          break;
        default:
          break;
      }
      TtkGtk_gtk_render_expander(context, cr, b.x, b.y, b.width, b.height);
      break;
    case PN_EXTENSION: {
      gint gap_side = 0;
      switch ((GtkPositionType) elementData->info->orientation) {
        case GTK_POS_TOP:
          TtkGtk_gtk_style_context_add_class(context, GTK_STYLE_CLASS_TOP);
          TtkGtk_gtk_style_context_add_class(context, GTK_STYLE_CLASS_HORIZONTAL);
          gap_side = GTK_POS_BOTTOM;
          break;
        case GTK_POS_BOTTOM:
          TtkGtk_gtk_style_context_add_class(context, GTK_STYLE_CLASS_BOTTOM);
          TtkGtk_gtk_style_context_add_class(context, GTK_STYLE_CLASS_HORIZONTAL);
          gap_side = GTK_POS_TOP;
          break;
        case GTK_POS_LEFT:
          TtkGtk_gtk_style_context_add_class(context, GTK_STYLE_CLASS_LEFT);
          TtkGtk_gtk_style_context_add_class(context, GTK_STYLE_CLASS_VERTICAL);
          gap_side = GTK_POS_RIGHT;
          break;
        case GTK_POS_RIGHT:
          TtkGtk_gtk_style_context_add_class(context, GTK_STYLE_CLASS_RIGHT);
          TtkGtk_gtk_style_context_add_class(context, GTK_STYLE_CLASS_VERTICAL);
          gap_side = GTK_POS_LEFT;
          break;
        default:
          break;
      }
      switch ((enum TtkGtk_ClassNames) elementData->info->classNameIndex) {
        case CN_CLASS_NOTEBOOK: {
          // unsigned int left = 0, top = 0, right = 0, bottom = 0;
          GtkBorder padding;
          gint tab_overlap = 2;
          /* Get the default padding */
          TtkGtk_gtk_style_context_get_padding(context, 0, &padding);
          //ADD_BORDER(padding);
          /* Get the default border */
          TtkGtk_gtk_style_context_get_border(context, 0, &padding);
          //ADD_BORDER(padding);
          //b.width  -= left + right;
          //b.height += top + bottom;
          TtkGtk_gtk_style_context_add_region(context, GTK_STYLE_REGION_TAB,
                     GTK_REGION_ODD |GTK_REGION_FIRST);

          TtkGtk_gtk_style_context_get_style(context,
             "tab-overlap", &tab_overlap, NULL);
          //b.height += tab_overlap;
          //b.width  += 2 * tab_overlap;
          break;
        }
        default:
          break;
      }
      //b.x += 5;
      //b.y += 5;
      //b.width -= 10;
      //b.height -= 10;
      //printf("gtk_render_extension: x:%d, y:%d, w:%d, h=%d, o:%d\n",
      //        b.x, b.y, b.width, b.height, elementData->info->orientation);
      
      TtkGtk_gtk_render_extension(context, cr, b.x, b.y, b.width, b.height,
                                  gap_side);
      break;
    }
    case PN_FOCUS: {
      gboolean draw_focus = 1;
      if (!(state & GTK_STATE_FLAG_FOCUSED)) break;
      /* If widget is a button, check whether focus must be drawn */
      if (elementData->info->classNameIndex == CN_CLASS_BUTTON) {
        TtkGtk_gtk_style_context_get_style(context,
             "interior-focus", &draw_focus, NULL);
      }
      if (draw_focus) {
        TtkGtk_gtk_render_focus(context, cr, b.x, b.y, b.width, b.height);
      }
      break;
    }
    case PN_FRAME:
      TtkGtk_gtk_render_frame(context, cr, b.x, b.y, b.width, b.height);
      break;
    case PN_FRAME_GAP:
      TtkGtk_AddOrientationClass(context, elementData);
      TtkGtk_gtk_style_context_add_class(context, GTK_STYLE_CLASS_BACKGROUND);
      TtkGtk_gtk_style_context_add_class(context, GTK_STYLE_CLASS_FRAME);
      TtkGtk_gtk_render_frame_gap(context, cr, b.x, b.y, b.width, b.height,
             GTK_POS_TOP, b.x, 1);
      break;
    case PN_HANDLE:
      switch ((enum TtkGtk_ClassNames) elementData->info->classNameIndex) {
        case CN_CLASS_PANE_SEPARATOR:
          TtkGtk_AddOrientationClass(context, elementData);
          break;
        default:
          break;
      }
      TtkGtk_gtk_render_handle(context, cr, b.x, b.y, b.width, b.height);
      break;
    case PN_LAYOUT:
      //TtkGtk_gtk_render_layout(context, cr, b.x, b.y, b.width, b.height);
      break;
    case PN_LINE:
      TtkGtk_gtk_render_line(context, cr, b.x, b.y, b.width, b.height);
      break;
    case PN_OPTION:
      TtkGtk_gtk_render_option(context, cr, b.x, b.y, b.width, b.height);
      break;
    case PN_SLIDER:
      switch ((enum TtkGtk_ClassNames) elementData->info->classNameIndex) {
        case CN_CLASS_SCROLLBAR:
        case CN_CLASS_SCALE:
          TtkGtk_AddOrientationClass(context, elementData);
          TtkGtk_gtk_style_context_add_class(context, GTK_STYLE_CLASS_SLIDER);
          break;
        default:
          break;
      }
      TtkGtk_gtk_render_slider(context, cr, b.x, b.y, b.width, b.height,
                               elementData->info->orientation);
      break;
    case PN_ACTIVITY:
      switch ((enum TtkGtk_ClassNames) elementData->info->classNameIndex) {
        case CN_CLASS_PROGRESSBAR:
          TtkGtk_AddOrientationClass(context, elementData);
          TtkGtk_gtk_style_context_add_class(context, GTK_STYLE_CLASS_PULSE);
          break;
        default:
          break;
      }
      TtkGtk_gtk_render_activity(context, cr, b.x, b.y, b.width, b.height);
      break;
    case PN_ICON_PIXBUF:
      //TtkGtk_gtk_render_icon_pixbuf(context, cr, b.x, b.y, b.width, b.height);
      break;
    case PN_ICON: {
      GtkIconTheme *icon_theme;
      GtkIconInfo *info;
      GdkPixbuf *destination = NULL;
      gboolean symbolic = FALSE;

      switch ((enum TtkGtk_ClassNames) elementData->info->classNameIndex) {
        case CN_CLASS_SPINBUTTON:
          TtkGtk_gtk_style_context_add_class(context, GTK_STYLE_CLASS_BUTTON);
          TtkGtk_gtk_render_background(context, cr, b.x, b.y, b.width,b.height);
          TtkGtk_gtk_render_frame(context, cr, b.x, b.y, b.width, b.height);
          break;
        default:
          break;
      }

      icon_theme = TtkGtk_gtk_icon_theme_get_default();
      info = TtkGtk_gtk_icon_theme_lookup_icon(icon_theme,
                                         elementData->info->iconName,
                                         elementData->info->size,
                    (GtkIconLookupFlags) elementData->info->flags);
      destination =
      TtkGtk_gtk_icon_info_load_symbolic_for_context(info, context, &symbolic,
					             NULL);
      if (destination != NULL) {
        TtkGtk_gtk_style_context_add_class(context, GTK_STYLE_CLASS_IMAGE);
        TtkGtk_gtk_render_icon(context, cr, destination, b.x, b.y);
        TtkGtk_g_object_unref((GObject *) destination);
      }
      if (info) TtkGtk_gtk_icon_info_free(info);
      break;
    }
    case PN_INSERTION_CURSOR:
      //TtkGtk_gtk_render_insertion_cursor(context, cr, b.x, b.y, b.width, b.height);
      break;
    case PN_BACKGROUND_FRAME:
      switch ((enum TtkGtk_ClassNames) elementData->info->classNameIndex) {
        case CN_CLASS_SCROLLBAR:
        case CN_CLASS_PROGRESSBAR:
        case CN_CLASS_SCALE:
          TtkGtk_gtk_style_context_add_class(context, GTK_STYLE_CLASS_TROUGH);
          TtkGtk_AddOrientationClass(context, elementData);
          break;
        case CN_CLASS_COMBOBOX_ENTRY:
          TtkGtk_gtk_style_context_add_class(context, GTK_STYLE_CLASS_BUTTON);
          break;
        default:
          break;
      }
      TtkGtk_gtk_render_background(context, cr, b.x, b.y, b.width, b.height);
      TtkGtk_gtk_render_frame(context, cr, b.x, b.y, b.width, b.height);
      break;
    case PN_BUTTON:
      TtkGtk_gtk_render_background(context, cr, b.x, b.y, b.width, b.height);
      TtkGtk_gtk_render_frame(context, cr, b.x, b.y, b.width, b.height);
      break;
    case PN_SEPARATOR: {
      GtkBorder padding;
      gboolean wide_separators;
      gint separator_width;
      gint separator_height;
      TtkGtk_gtk_style_context_get_padding(context, state, &padding);

      TtkGtk_gtk_style_context_get_style(context,
             "wide-separators",  &wide_separators,
             "separator-width",  &separator_width,
             "separator-height", &separator_height,
             NULL);
      if (elementData->info->orientation == GTK_ORIENTATION_HORIZONTAL) {
        if (wide_separators)
          TtkGtk_gtk_render_frame(context, cr,
                                  0, (b.height - separator_height) / 2,
                                  b.width, separator_height);
        else
          TtkGtk_gtk_render_line(context, cr,
                                 0, (b.height - padding.top) / 2,
                                 b.width - 1, (b.height - padding.top) / 2);
      } else {
        if (wide_separators)
          TtkGtk_gtk_render_frame(context, cr,
                                  (b.width - separator_width) / 2, 0,
                                  separator_width, b.height);
        else
          TtkGtk_gtk_render_line(context, cr,
                                 (b.width - padding.left) / 2, 0,
                                 (b.width - padding.left) / 2, b.height - 1);
      }
      break;
    }
    case PN_HEADER_ROW:
      switch ((enum TtkGtk_ClassNames) elementData->info->classNameIndex) {
        case CN_CLASS_VIEW: {
          TtkGtk_gtk_style_context_add_class(context, GTK_STYLE_CLASS_CELL);
          TtkGtk_gtk_style_context_add_class(context, GTK_STYLE_CLASS_BUTTON);
          //TtkGtk_gtk_style_context_add_class(context, GTK_STYLE_CLASS_RUBBERBAND);
          TtkGtk_gtk_style_context_add_region(context,
                     GTK_STYLE_REGION_COLUMN, 0);
          TtkGtk_gtk_style_context_add_region(context,
                     GTK_STYLE_REGION_COLUMN_HEADER, 0);
          break;
        }
        default:
          break;
      }
      TtkGtk_gtk_render_background(context, cr, b.x, b.y, b.width, b.height);
      TtkGtk_gtk_render_frame(context, cr, b.x, b.y, b.width, b.height);
      break;
    case PN_ROW:
      switch ((enum TtkGtk_ClassNames) elementData->info->classNameIndex) {
        case CN_CLASS_VIEW: {
          TtkGtk_gtk_style_context_add_class(context, GTK_STYLE_CLASS_CELL);
          TtkGtk_gtk_style_context_add_region(context, GTK_STYLE_REGION_COLUMN,
               0);
          if (ttk_state & TTK_STATE_ALTERNATE) {
            TtkGtk_gtk_style_context_add_region(context, GTK_STYLE_REGION_ROW,
               GTK_REGION_ODD);
          } else {
            TtkGtk_gtk_style_context_add_region(context, GTK_STYLE_REGION_ROW,
               GTK_REGION_EVEN);
          }
          break;
        }
        default:
          break;
      }
      TtkGtk_gtk_render_background(context, cr, b.x, b.y, b.width, b.height);
      TtkGtk_gtk_render_frame(context, cr, b.x, b.y, b.width, b.height);
      break;
    default:
      break;
  }

  /* Destroy the Cairo drawing context */
  TtkGtk_DestroyCairoDrawingContext(cr);

  /* Restore the saved context */
  TtkGtk_gtk_style_context_restore(context);
}; /* TtkGtk_RenderElement */
