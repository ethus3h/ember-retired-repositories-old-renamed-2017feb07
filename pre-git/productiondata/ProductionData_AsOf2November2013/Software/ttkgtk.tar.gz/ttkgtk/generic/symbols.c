/*
 * symbols.c 
 * -------------------
 *
 * This file is part of the TtkGtk package, a Ttk based theme that uses
 * Gtk/GNOME for drawing.
 *
 * Copyright (C) 2012 by:
 * Georgios Petasis, petasis@iit.demokritos.gr, petasisg@yahoo.gr
 * Software and Knowledge Engineering Laboratory,
 * Institute of Informatics and Telecommunications,
 * National Centre for Scientific Research (NCSR) "Demokritos",
 * Aghia Paraskevi, 153 10, Athens, Greece.
 *
 */

#include "symbols.h"

#ifndef LINK_TO_GTK

TtkGtk_SymbolTable TtkGtk_symbols;

#define LOAD_SYMBOL(m) \
  TtkGtk_symbols.p_##m = (ptr_##m) Tcl_FindSymbol(interp, lh, #m); \
  if (TtkGtk_symbols.p_##m == NULL) return TCL_ERROR;

int TtkGtk_LoadCairoSymbols(Tcl_Interp *interp, Tcl_LoadHandle lh) {
#ifdef CAIRO_HAS_XLIB_SURFACE
  LOAD_SYMBOL(cairo_xlib_surface_create);
#endif /* CAIRO_HAS_XLIB_SURFACE */
  LOAD_SYMBOL(cairo_create);
  LOAD_SYMBOL(cairo_surface_destroy);
  LOAD_SYMBOL(cairo_destroy);
  return TCL_OK;
}; /* TtkGtk_LoadCairoSymbols */

int TtkGtk_LoadGtkSymbols(Tcl_Interp *interp, Tcl_LoadHandle lh) {
  LOAD_SYMBOL(gtk_init);

  LOAD_SYMBOL(gtk_style_context_new);
  LOAD_SYMBOL(gtk_style_context_get_border);
  LOAD_SYMBOL(gtk_style_context_get_background_color);
  LOAD_SYMBOL(gtk_style_context_get_color);
  LOAD_SYMBOL(gtk_style_context_get_style);
  LOAD_SYMBOL(gtk_style_context_get_style_property);
  LOAD_SYMBOL(gtk_style_context_get_padding);
  LOAD_SYMBOL(gtk_style_context_get_path);
  LOAD_SYMBOL(gtk_style_context_set_junction_sides);
  LOAD_SYMBOL(gtk_style_context_set_path);
  LOAD_SYMBOL(gtk_style_context_set_screen);
  LOAD_SYMBOL(gtk_style_context_set_state);
  LOAD_SYMBOL(gtk_style_context_add_class);
  LOAD_SYMBOL(gtk_style_context_add_region);
  LOAD_SYMBOL(gtk_style_context_remove_class);
  LOAD_SYMBOL(gtk_style_context_save);
  LOAD_SYMBOL(gtk_style_context_restore);

  LOAD_SYMBOL(gtk_widget_path_new);
  LOAD_SYMBOL(gtk_widget_path_append_type);
  LOAD_SYMBOL(gtk_widget_path_append_with_siblings);
  LOAD_SYMBOL(gtk_widget_path_iter_add_class);
  LOAD_SYMBOL(gtk_widget_path_get_object_type);
  LOAD_SYMBOL(gtk_widget_path_to_string);
  LOAD_SYMBOL(gtk_widget_path_ref);
  LOAD_SYMBOL(gtk_widget_path_free);

  LOAD_SYMBOL(gtk_icon_theme_get_default);
  LOAD_SYMBOL(gtk_icon_theme_lookup_icon);
  LOAD_SYMBOL(gtk_icon_info_free);
  LOAD_SYMBOL(gtk_icon_info_get_filename);
  LOAD_SYMBOL(gtk_icon_info_load_symbolic_for_context);
  LOAD_SYMBOL(gtk_icon_size_lookup_for_settings);

  LOAD_SYMBOL(gtk_settings_get_default);

  LOAD_SYMBOL(g_object_new);
  LOAD_SYMBOL(g_object_get_property);
  LOAD_SYMBOL(g_object_set_property);
  LOAD_SYMBOL(g_object_unref);

  LOAD_SYMBOL(g_value_init);
  LOAD_SYMBOL(g_value_get_string);
  LOAD_SYMBOL(g_value_unset);

  LOAD_SYMBOL(gdk_screen_get_default);

  LOAD_SYMBOL(gtk_border_free);

  LOAD_SYMBOL(gtk_render_background);
  LOAD_SYMBOL(gtk_render_arrow);
  LOAD_SYMBOL(gtk_render_check);
  LOAD_SYMBOL(gtk_render_expander);
  LOAD_SYMBOL(gtk_render_focus);
  LOAD_SYMBOL(gtk_render_frame);
  LOAD_SYMBOL(gtk_render_handle);
  LOAD_SYMBOL(gtk_render_line);
  LOAD_SYMBOL(gtk_render_option);
  LOAD_SYMBOL(gtk_render_activity);
  LOAD_SYMBOL(gtk_render_extension);
  LOAD_SYMBOL(gtk_render_frame_gap);
  LOAD_SYMBOL(gtk_render_layout);
  LOAD_SYMBOL(gtk_render_slider);
  LOAD_SYMBOL(gtk_render_icon_pixbuf);
  LOAD_SYMBOL(gtk_render_icon);
  LOAD_SYMBOL(gtk_render_insertion_cursor);

  LOAD_SYMBOL(gtk_window_get_type);
  LOAD_SYMBOL(gtk_button_get_type);
  LOAD_SYMBOL(gtk_check_button_get_type);
  LOAD_SYMBOL(gtk_toggle_button_get_type);
  LOAD_SYMBOL(gtk_radio_button_get_type);
  LOAD_SYMBOL(gtk_spin_button_get_type);
  LOAD_SYMBOL(gtk_entry_get_type);
  LOAD_SYMBOL(gtk_combo_box_get_type);
  LOAD_SYMBOL(gtk_scale_get_type);
  LOAD_SYMBOL(gtk_progress_bar_get_type);
  LOAD_SYMBOL(gtk_scrollbar_get_type);
  LOAD_SYMBOL(gtk_notebook_get_type);
  LOAD_SYMBOL(gtk_paned_get_type);
  LOAD_SYMBOL(gtk_frame_get_type);
  LOAD_SYMBOL(gtk_tree_view_get_type);
  LOAD_SYMBOL(gtk_arrow_get_type);

  return TCL_OK;
}; /* TtkGtk_LoadGtkSymbols */
#endif
