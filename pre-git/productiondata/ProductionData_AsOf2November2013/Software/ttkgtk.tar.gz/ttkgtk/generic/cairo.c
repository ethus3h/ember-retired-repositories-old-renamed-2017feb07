/*
 * cairo.c 
 * -------------------
 *
 * This file is part of the TtkGtk package, a Ttk based theme that uses
 * Gtk/GNOME for drawing.
 *
 * Copyright (C) 2012 by:
 * Georgios Petasis, petasis@iit.demokritos.gr, petasisg@yahoo.gr
 * Software and Knowledge Engineering Laboratory,
 * Institute of Informatics and Telecommunications,
 * National Centre for Scientific Research (NCSR) "Demokritos",
 * Aghia Paraskevi, 153 10, Athens, Greece.
 *
 */

#include "symbols.h"

#ifndef LINK_TO_GTK
extern TtkGtk_SymbolTable TtkGtk_symbols;             /* In symbols.c  */
extern int TtkGtk_LoadCairoSymbols(Tcl_Interp *interp, Tcl_LoadHandle lh);
#endif

TCL_DECLARE_MUTEX(ttkgtkMutex);

static int TtkGtk_CairoLibraryLoaded = 0;

int TtkGtk_CairoInit(ClientData clientData, Tcl_Interp *interp,
                    int objc, Tcl_Obj *const objv[]) {
#ifndef LINK_TO_GTK
  Tcl_LoadHandle lh;

  if (objc != 2) {
    Tcl_WrongNumArgs(interp, 1, objv, "cairo-library-filename");
    return TCL_ERROR;
  }

  Tcl_MutexLock(&ttkgtkMutex);
  if (TtkGtk_CairoLibraryLoaded) {
    Tcl_MutexUnlock(&ttkgtkMutex);
    return TCL_OK;
  }
#endif

#ifndef LINK_TO_GTK
  /*
   * Load the library provided by the first argument...
   */
  if (Tcl_LoadFile(interp, objv[1], NULL, 0, NULL, &lh) != TCL_OK) {
    Tcl_MutexUnlock(&ttkgtkMutex);
    return TCL_ERROR;
  }

  /*
   * Load the needed symbols from the library...
   */
  if (TtkGtk_LoadCairoSymbols(interp, lh) != TCL_OK) {
    Tcl_MutexUnlock(&ttkgtkMutex);
    return TCL_ERROR;
  }
#endif /* LINK_TO_GTK */
  
  TtkGtk_CairoLibraryLoaded = 1;
  Tcl_MutexUnlock(&ttkgtkMutex);
  return TCL_OK;
}; /* TtkGtk_CairoInit */

cairo_surface_t *TtkGtk_GetCairoSurface(Tk_Window tkwin, Drawable d) {
#ifdef CAIRO_HAS_XLIB_SURFACE
  return TtkGtk_cairo_xlib_surface_create(Tk_Display(tkwin),
                                          d,
                                          Tk_Visual(tkwin),
                                          Tk_Width(tkwin),
                                          Tk_Height(tkwin));
#endif
}; /* TtkGtk_GetCairoSurface */

cairo_t *TtkGtk_GetCairoDrawingContext(Tk_Window tkwin, Drawable d) {
  cairo_surface_t *surface = TtkGtk_GetCairoSurface(tkwin, d);
  cairo_t         *context;

  if (surface == NULL) return NULL;
  context = TtkGtk_cairo_create(surface);
  TtkGtk_cairo_surface_destroy(surface);
  return context;
}; /* TtkGtk_GetCairoDrawingContext */

void TtkGtk_DestroyCairoDrawingContext(cairo_t *surface) {
  TtkGtk_cairo_destroy(surface);
}; /* TtkGtk_GetCairoDrawingContext */
