/*
 * gtktheme.c 
 * -------------------
 *
 * This file is part of the TtkGtk package, a Ttk based theme that uses
 * Gtk/GNOME for drawing.
 *
 * Copyright (C) 2012 by:
 * Georgios Petasis, petasis@iit.demokritos.gr, petasisg@yahoo.gr
 * Software and Knowledge Engineering Laboratory,
 * Institute of Informatics and Telecommunications,
 * National Centre for Scientific Research (NCSR) "Demokritos",
 * Aghia Paraskevi, 153 10, Athens, Greece.
 *
 */

#include "ttkgtk.h"
#include "gtktheme.h"
#include <string.h>

/*
 * Declaration of functions defined in gtk.c.
 */

/* Allocate cairo contexts... */
extern void TtkGtk_AllocateCairoContexts(GtkThemeData *themeData);
/* Get element size from Gtk theme... */
extern void TtkGtk_ElementSize(ElementData *elementData, Tk_Window tkwin,
                        int *widthPtr, int *heightPtr, Ttk_Padding *paddingPtr);
/* Draw element using Gtk... */
extern void TtkGtk_RenderElement(ElementData *elementData, Tk_Window tkwin,
                         Drawable d, Ttk_Box b,
                         unsigned int state, unsigned int ttk_state);

unsigned int TtkGtk_Ttk2GtkState(unsigned int state);

/*
 * Gtk state names
 */
const char *const TtkGtk_stateNames[] =
{
    "normal",		/* GTK_STATE_FLAG_NORMAL       */
    "active",		/* GTK_STATE_FLAG_ACTIVE       */
    "prelight",		/* GTK_STATE_FLAG_PRELIGHT     */
    "selected",		/* GTK_STATE_FLAG_SELECTED     */
    "insensitive",	/* GTK_STATE_FLAG_INSENSITIVE  */
    "inconsistent",	/* GTK_STATE_FLAG_INCONSISTENT */
    "focused",		/* GTK_STATE_FLAG_FOCUSED      */
    "backdrop",		/* GTK_STATE_FLAG_BACKDROP     */
    NULL
};

const unsigned int TtkGtk_StateNames[] = {
  GTK_STATE_FLAG_NORMAL,
  GTK_STATE_FLAG_ACTIVE,
  GTK_STATE_FLAG_PRELIGHT,
  GTK_STATE_FLAG_SELECTED,
  GTK_STATE_FLAG_INSENSITIVE,
  GTK_STATE_FLAG_INCONSISTENT,
  GTK_STATE_FLAG_FOCUSED,
  GTK_STATE_FLAG_BACKDROP
};

/*
 * Gtk orientation names
 */
const char *const TtkGtk_orientationNames[] =
{
    "horizontal",	/* GTK_ORIENTATION_HORIZONTAL */
    "vertical",		/* GTK_ORIENTATION_VERTICAL   */
    "arrow_right",	/* GTK_ARROW_RIGHT            */
    "arrow_left",	/* GTK_ARROW_LEFT             */
    "arrow_up",		/* GTK_ARROW_UP               */
    "arrow_down",	/* GTK_ARROW_DOWN             */
    "left",		/* GTK_POS_LEFT               */
    "right",		/* GTK_POS_RIGHT              */
    "top",		/* GTK_POS_TOP                */
    "bottom",		/* GTK_POS_BOTTOM             */
    NULL
};

const unsigned int TtkGtk_OrientationNames[] = {
  GTK_ORIENTATION_HORIZONTAL,
  GTK_ORIENTATION_VERTICAL,
  GTK_ARROW_RIGHT,
  GTK_ARROW_LEFT,
  GTK_ARROW_UP,
  GTK_ARROW_DOWN,
  GTK_POS_LEFT,
  GTK_POS_RIGHT,
  GTK_POS_TOP,
  GTK_POS_BOTTOM
};

/*
 * Compatibility with Gtk 3.2
 */
#ifndef GTK_STYLE_CLASS_SCROLLBARS_JUNCTION
#define GTK_STYLE_CLASS_SCROLLBARS_JUNCTION "scrollbars-junction"
#endif
#ifndef GTK_STYLE_CLASS_LINKED
#define GTK_STYLE_CLASS_LINKED "linked"
#endif
#ifndef GTK_STYLE_CLASS_TOP
#define GTK_STYLE_CLASS_TOP    "top"
#define GTK_STYLE_CLASS_BOTTOM "bottom"
#define GTK_STYLE_CLASS_LEFT   "left"
#define GTK_STYLE_CLASS_RIGHT  "right"
#endif
#ifndef GTK_STYLE_CLASS_PULSE
#define GTK_STYLE_CLASS_PULSE "pulse"
#endif
#ifndef GTK_STYLE_CLASS_ARROW
#define GTK_STYLE_CLASS_ARROW "arrow"
#endif



/*
 * Gtk class names
 */
const char *const TtkGtk_classNames[] =
{
    GTK_STYLE_CLASS_BACKGROUND,        GTK_STYLE_CLASS_BUTTON, 
    GTK_STYLE_CLASS_CALENDAR,          GTK_STYLE_CLASS_CELL, 
    GTK_STYLE_CLASS_COMBOBOX_ENTRY,    GTK_STYLE_CLASS_CHECK, 
    GTK_STYLE_CLASS_DEFAULT,           GTK_STYLE_CLASS_ENTRY, 
    GTK_STYLE_CLASS_HEADER,            GTK_STYLE_CLASS_MENU, 
    GTK_STYLE_CLASS_RADIO,             GTK_STYLE_CLASS_RUBBERBAND, 
    GTK_STYLE_CLASS_SCROLLBAR,         GTK_STYLE_CLASS_SCROLLBARS_JUNCTION, 
    GTK_STYLE_CLASS_SLIDER,            GTK_STYLE_CLASS_TOOLTIP, 
    GTK_STYLE_CLASS_TROUGH,            GTK_STYLE_CLASS_ACCELERATOR, 
    GTK_STYLE_CLASS_DOCK,              GTK_STYLE_CLASS_GRIP, 
    GTK_STYLE_CLASS_MENUBAR,           GTK_STYLE_CLASS_MENUITEM, 
    GTK_STYLE_CLASS_PROGRESSBAR,       GTK_STYLE_CLASS_SPINNER, 
    GTK_STYLE_CLASS_TOOLBAR,           GTK_STYLE_CLASS_PRIMARY_TOOLBAR, 
    GTK_STYLE_CLASS_INLINE_TOOLBAR,    GTK_STYLE_CLASS_PANE_SEPARATOR, 
    GTK_STYLE_CLASS_SEPARATOR,         GTK_STYLE_CLASS_SIDEBAR, 
    GTK_STYLE_CLASS_DND,               GTK_STYLE_CLASS_ERROR, 
    GTK_STYLE_CLASS_EXPANDER,          GTK_STYLE_CLASS_FRAME, 
    GTK_STYLE_CLASS_HIGHLIGHT,         GTK_STYLE_CLASS_IMAGE, 
    GTK_STYLE_CLASS_INFO,              GTK_STYLE_CLASS_MARK, 
    GTK_STYLE_CLASS_NOTEBOOK,          GTK_STYLE_CLASS_QUESTION, 
    GTK_STYLE_CLASS_SCALE,             GTK_STYLE_CLASS_SCALE_HAS_MARKS_ABOVE, 
    GTK_STYLE_CLASS_SCALE_HAS_MARKS_BELOW,   GTK_STYLE_CLASS_SPINBUTTON, 
    GTK_STYLE_CLASS_VIEW,              GTK_STYLE_CLASS_WARNING, 
    GTK_STYLE_CLASS_HORIZONTAL,        GTK_STYLE_CLASS_VERTICAL, 
    GTK_STYLE_CLASS_TOP,               GTK_STYLE_CLASS_BOTTOM, 
    GTK_STYLE_CLASS_LEFT,              GTK_STYLE_CLASS_RIGHT, 
    GTK_STYLE_CLASS_LINKED,            GTK_STYLE_CLASS_ARROW, 
    GTK_STYLE_REGION_COLUMN,           GTK_STYLE_REGION_COLUMN_HEADER, 
    GTK_STYLE_REGION_ROW,              GTK_STYLE_REGION_TAB,
    NULL
};


const char *const TtkGtk_classNameDefines[] =
{
   "GTK_STYLE_CLASS_BACKGROUND",      "GTK_STYLE_CLASS_BUTTON",
   "GTK_STYLE_CLASS_CALENDAR",        "GTK_STYLE_CLASS_CELL",
   "GTK_STYLE_CLASS_COMBOBOX_ENTRY",  "GTK_STYLE_CLASS_CHECK",
   "GTK_STYLE_CLASS_DEFAULT",         "GTK_STYLE_CLASS_ENTRY",
   "GTK_STYLE_CLASS_HEADER",          "GTK_STYLE_CLASS_MENU",
   "GTK_STYLE_CLASS_RADIO",           "GTK_STYLE_CLASS_RUBBERBAND",
   "GTK_STYLE_CLASS_SCROLLBAR",       "GTK_STYLE_CLASS_SCROLLBARS_JUNCTION",
   "GTK_STYLE_CLASS_SLIDER",          "GTK_STYLE_CLASS_TOOLTIP",
   "GTK_STYLE_CLASS_TROUGH",          "GTK_STYLE_CLASS_ACCELERATOR",
   "GTK_STYLE_CLASS_DOCK",            "GTK_STYLE_CLASS_GRIP",
   "GTK_STYLE_CLASS_MENUBAR",         "GTK_STYLE_CLASS_MENUITEM",
   "GTK_STYLE_CLASS_PROGRESSBAR",     "GTK_STYLE_CLASS_SPINNER",
   "GTK_STYLE_CLASS_TOOLBAR",         "GTK_STYLE_CLASS_PRIMARY_TOOLBAR",
   "GTK_STYLE_CLASS_INLINE_TOOLBAR",  "GTK_STYLE_CLASS_PANE_SEPARATOR",
   "GTK_STYLE_CLASS_SEPARATOR",       "GTK_STYLE_CLASS_SIDEBAR",
   "GTK_STYLE_CLASS_DND",             "GTK_STYLE_CLASS_ERROR",
   "GTK_STYLE_CLASS_EXPANDER",        "GTK_STYLE_CLASS_FRAME",
   "GTK_STYLE_CLASS_HIGHLIGHT",       "GTK_STYLE_CLASS_IMAGE",
   "GTK_STYLE_CLASS_INFO",            "GTK_STYLE_CLASS_MARK",
   "GTK_STYLE_CLASS_NOTEBOOK",        "GTK_STYLE_CLASS_QUESTION",
   "GTK_STYLE_CLASS_SCALE",           "GTK_STYLE_CLASS_SCALE_HAS_MARKS_ABOVE",
   "GTK_STYLE_CLASS_SCALE_HAS_MARKS_BELOW", "GTK_STYLE_CLASS_SPINBUTTON",
   "GTK_STYLE_CLASS_VIEW",            "GTK_STYLE_CLASS_WARNING",
   "GTK_STYLE_CLASS_HORIZONTAL",      "GTK_STYLE_CLASS_VERTICAL",
   "GTK_STYLE_CLASS_TOP",             "GTK_STYLE_CLASS_BOTTOM",
   "GTK_STYLE_CLASS_LEFT",            "GTK_STYLE_CLASS_RIGHT",
   "GTK_STYLE_CLASS_LINKED",          "GTK_STYLE_CLASS_ARROW",
   "GTK_STYLE_REGION_COLUMN",         "GTK_STYLE_REGION_COLUMN_HEADER",
   "GTK_STYLE_REGION_ROW",            "GTK_STYLE_REGION_TAB",
   NULL
};

/*
 * TtkGtk part names
 */
const char *const TtkGtk_partNames[] =
{
   "arrow",
   "background",
   "check",
   "expander",
   "extension",
   "focus",
   "frame",
   "frame_gap",
   "handle",
   "layout",
   "line",
   "option",
   "slider",
   "activity",
   "icon_pixbuf",
   "icon",
   "insertion_cursor",
   "background_frame",		/* Virtual: background + frame       */
   "button",			/* Virtual: background + frame       */
   "button_arrow",              /* Virtual: arrow inside a button    */
   "separator",                 /* Virtual: line or frame            */
   "header_row",                /* Virtual: header row               */
   "row",                       /* Virtual: row (as in treeview row) */
   NULL
};

Ttk_ElementOptionSpec TtkGtk_NullElementOptions[];
Ttk_ElementSpec       TtkGtk_NullElementSpec;

static ElementData *NewElementData(GtkThemeData *themeData, ElementInfo *info) {
  ElementData *elementData = ckalloc(sizeof(ElementData));
  elementData->info      = info;
  elementData->themeData = themeData;
  return elementData;
}; /* NewElementData */

/*
 * Destroy elements. If the element was created by the element factory
 * then the info member is dynamically allocated. Otherwise it was
 * static data from the C object and only the ElementData needs freeing.
 */
static void DestroyElementData(void *clientData) {
  ElementData *elementData = clientData;
  if (elementData->info->flags & HEAP_ELEMENT) {
    ckfree(elementData->info->statemap);
    ckfree(elementData->info->className);
    ckfree(elementData->info->elementName);
    if (elementData->info->iconName) ckfree(elementData->info->iconName);
    ckfree(elementData->info);
  }
  ckfree(clientData);
}; /* DestroyElementData */

/*----------------------------------------------------------------------
 * +++ Generic element implementation.
 *
 * Used for elements which are handled entirely by the XP Theme API,
 * such as radiobutton and checkbutton indicators, scrollbar arrows, etc.
 */

static void GenericElementSize(void *clientData, void *elementRecord,
                               Tk_Window tkwin, int *widthPtr, int *heightPtr,
                               Ttk_Padding *paddingPtr) {
  ElementData *elementData = clientData;
  if (!(elementData->info->flags & IGNORE_THEMESIZE)) {
    TtkGtk_ElementSize(elementData, tkwin, widthPtr, heightPtr, paddingPtr);
  }
  /* Append any padding from the element data */
  paddingPtr->left   += elementData->info->padding.left;
  paddingPtr->top    += elementData->info->padding.top;
  paddingPtr->right  += elementData->info->padding.right;
  paddingPtr->bottom += elementData->info->padding.bottom;
  if (elementData->info->flags & PAD_MARGINS) {
    *widthPtr  += Ttk_PaddingWidth(elementData->info->padding);
    *heightPtr += Ttk_PaddingHeight(elementData->info->padding);
  }
}; /* GenericElementSize */

static void GenericElementDraw(void *clientData, void *elementRecord,
                               Tk_Window tkwin, Drawable d,
                               Ttk_Box b, unsigned int state) {
  ElementData *elementData = clientData;
  unsigned int gtk_state;

  if (elementData->info->flags & PAD_MARGINS) {
    b = Ttk_PadBox(b, elementData->info->padding);
  }

  if (elementData->info->statemap == NULL) {
    gtk_state = TtkGtk_Ttk2GtkState(state);
    switch ((enum TtkGtk_ClassNames) elementData->info->classNameIndex) {
      case CN_CLASS_VIEW:
        switch ((enum TtkGtk_PartNames) elementData->info->partId) {
          case PN_EXPANDER:
            /* This is an expansion arrow.
             * Set GTK_STATE_FLAG_ACTIVE if expanded */
            gtk_state = 0;
            if (state & TTK_STATE_LEAF) return;
            if (state & TTK_STATE_OPEN) gtk_state |= GTK_STATE_FLAG_ACTIVE;
            break;
          case PN_ROW:
            if (state & TTK_STATE_ALTERNATE) {
              /* Remove the GTK_STATE_FLAG_INCONSISTENT flag */
              state &= ~(GTK_STATE_FLAG_INCONSISTENT);
            }
            break;
          default:
            break;
        }
        break;
      case CN_CLASS_COMBOBOX_ENTRY:
        switch ((enum TtkGtk_PartNames) elementData->info->partId) {
          case PN_ARROW:
            /* This is a combobox arrow. */
            gtk_state |= GTK_STATE_FLAG_BACKDROP;
            gtk_state &= ~(GTK_STATE_FLAG_INSENSITIVE);
            if ((state & TTK_STATE_ACTIVE)  ||
                (state & TTK_STATE_PRESSED) ||
                (state & TTK_STATE_FOCUS))
                gtk_state |= GTK_STATE_FLAG_SELECTED;
            break;
          default:
            break;
        }
        break;
      default:
        break;
    }
  } else {
    gtk_state = Ttk_StateTableLookup(elementData->info->statemap, state);
  }
  TtkGtk_RenderElement(elementData, tkwin, d, b, gtk_state, state);
}; /* GenericElementDraw */

static Ttk_ElementSpec GenericElementSpec = {
  TK_STYLE_VERSION_2,
  sizeof(NullElement),
  TtkGtk_NullElementOptions,
  GenericElementSize,
  GenericElementDraw
};

/*----------------------------------------------------------------------
 * +++ Sized element implementation.
 *
 * Used for elements which are handled entirely by the XP Theme API,
 * but that require a fixed size adjustment.
 * Note that GetThemeSysSize calls through to GetSystemMetrics
 */

static void GenericSizedElementSize(void *clientData, void *elementRecord,
                                    Tk_Window tkwin,
                                    int *widthPtr, int *heightPtr,
                                    Ttk_Padding *paddingPtr) {
  // ElementData *elementData = clientData;
  printf("GenericSizedElementSize\n");
  *heightPtr = 20;
  *widthPtr  = 20;
}; /* GenericSizedElementSize */

static Ttk_ElementSpec GenericSizedElementSpec = {
  TK_STYLE_VERSION_2,
  sizeof(NullElement),
  TtkGtk_NullElementOptions,
  GenericSizedElementSize,
  GenericElementDraw
};


static void TtkGtk_ThemeDeleteProc(void *clientData) {
  ckfree(clientData);
}; /* TtkGtk_ThemeDeleteProc */

#ifdef Ttk_SetThemeEnabledProc
static int TtkGtk_ThemeEnabled(Ttk_Theme theme, void *clientData) {
    return 1;
}; /* TtkGtk_ThemeEnabled */
#endif

static int GetSysFlagFromObj(Tcl_Interp *interp, Tcl_Obj *objPtr, int *resultPtr) {
#if 0
    static const char *names[] = {
	"SM_CXBORDER", "SM_CYBORDER", "SM_CXVSCROLL", "SM_CYVSCROLL",
	"SM_CXHSCROLL", "SM_CYHSCROLL", "SM_CXMENUCHECK", "SM_CYMENUCHECK",
	"SM_CXMENUSIZE", "SM_CYMENUSIZE", "SM_CXSIZE", "SM_CYSIZE", "SM_CXSMSIZE",
	"SM_CYSMSIZE"
    };
    int flags[] = {
	SM_CXBORDER, SM_CYBORDER, SM_CXVSCROLL, SM_CYVSCROLL,
	SM_CXHSCROLL, SM_CYHSCROLL, SM_CXMENUCHECK, SM_CYMENUCHECK,
	SM_CXMENUSIZE, SM_CYMENUSIZE, SM_CXSIZE, SM_CYSIZE, SM_CXSMSIZE,
	SM_CYSMSIZE
    };

    Tcl_Obj **objv;
    int i, objc;

    if (Tcl_ListObjGetElements(interp, objPtr, &objc, &objv) != TCL_OK)
	return TCL_ERROR;
    if (objc != 2) {
	Tcl_SetResult(interp, "wrong # args", TCL_STATIC);
	return TCL_ERROR;
    }
    for (i = 0; i < objc; ++i) {
	int option;
	if (Tcl_GetIndexFromObj(interp, objv[i], names, "system constant", 0, &option)
		!= TCL_OK)
	    return TCL_ERROR;
	*resultPtr |= (flags[option] << (8 * (1 - i)));
    }
#endif
    return TCL_OK;
}; /* GetSysFlagFromObj */

int TtkGtk_GetStateSpecFromObj(Tcl_Interp *interp, Tcl_Obj *objPtr,
                               Ttk_StateSpec *spec) {
  int status;
  int objc;
  Tcl_Obj **objv;
  int i;
  unsigned int onbits = 0, offbits = 0;

  status = Tcl_ListObjGetElements(interp, objPtr, &objc, &objv);
  if (status != TCL_OK)
      return status;

  for (i = 0; i < objc; ++i) {
    const char *stateName = Tcl_GetString(objv[i]);
    int on, j;

    if (*stateName == '!') {
        ++stateName;
        on = 0;
    } else {
        on = 1;
    }

    for (j = 0; TtkGtk_stateNames[j] != 0; ++j) {
        if (strcmp(stateName, TtkGtk_stateNames[j]) == 0)
    	break;
    }

      if (TtkGtk_stateNames[j] == 0) {
        if (interp) {
    	Tcl_ResetResult(interp);
    	Tcl_AppendResult(interp, "Invalid state name ", stateName,NULL);
        }
        return TCL_ERROR;
    }

    /* Ignore GTK_STATE_FLAG_NORMAL, whose value is 0 */
    if (j == 0) continue;
    j--;

    if (on) {
        onbits  |= (1<<j);
    } else {
        offbits |= (1<<j);
    }
  }
  spec->onbits  = onbits;
  spec->offbits = offbits;
  return TCL_OK;
}; /* TtkGtk_GetStateSpecFromObj */

/*----------------------------------------------------------------------
 * Windows Visual Styles API Element Factory
 *
 * The Vista release has shown that the Windows Visual Styles can be
 * extended with additional elements. This element factory can permit
 * the programmer to create elements for use with script-defined layouts
 *
 * eg: to create the small close button:
 * style element create smallclose vsapi \
 *    WINDOW 19 {disabled 4 pressed 3 active 2 {} 1}
 */

static int TtkGtk_CreateVsapiElement(Tcl_Interp *interp, void *clientData,
                                     Ttk_Theme theme, const char *elementName,
                                     int objc, Tcl_Obj *const objv[]) {
  GtkThemeData *themeData = clientData;
  ElementInfo *elementPtr = NULL;
  ClientData elementData;
  const char *className;
  int partId = 0;
  Ttk_StateTable *stateTable;
  Ttk_Padding pad = {0, 0, 0, 0};
  int flags = 0;
  int length = 0;
  int classNameIndex = 0, size = 0, orientation = 0;
  char *name = NULL, *iconName = NULL;
  Ttk_ElementSpec *elementSpec = &GenericElementSpec;

  static const char *optionStrings[] =
      { "-padding","-width","-height","-margins", "-syssize",
        "-halfheight", "-halfwidth",
        "-iconname", "-size", "-orientation", NULL };
  enum { O_PADDING, O_WIDTH, O_HEIGHT, O_MARGINS, O_SYSSIZE,
         O_HALFHEIGHT, O_HALFWIDTH,
         O_ICONNAME, O_SIZE, O_ORIENTATION };

  
  if (objc < 2) {
      Tcl_AppendResult(interp,
          "missing required arguments 'class' and/or 'partId'", NULL);
      return TCL_ERROR;
  }

  if (Tcl_GetIndexFromObj(interp, objv[0], TtkGtk_classNames,
                    "className", 0, &classNameIndex) != TCL_OK) {
    if (Tcl_GetIndexFromObj(interp, objv[0], TtkGtk_classNameDefines,
                    "className", 0, &classNameIndex) != TCL_OK) {
      /* This is not a Gtk class name */
      /* Tcl_SetResult(interp, "invalid class name: ", TCL_STATIC);
         Tcl_AppendResult(interp, Tcl_GetString(objv[0]), NULL); */
      return TCL_ERROR;
    }
  }
  className = TtkGtk_classNames[classNameIndex];
  length = strlen(className);

  if (Tcl_GetIndexFromObj(interp, objv[1], TtkGtk_partNames,
                  "partName", 0, &partId) != TCL_OK) {
    return TCL_ERROR;
  }

  /* flags or padding */
  if (objc > 3) {
    int i = 3, option = 0;
    for (i = 3; i < objc; i += 2) {
      int tmp = 0;
      if (i == objc -1) {
        Tcl_AppendResult(interp, "Missing value for \"",
                Tcl_GetString(objv[i]), "\".", NULL);
        return TCL_ERROR;
      }
      if (Tcl_GetIndexFromObj(interp, objv[i], optionStrings,
          "option", 0, &option) != TCL_OK)
        return TCL_ERROR;
      switch (option) {
        case O_PADDING:
          if (Ttk_GetBorderFromObj(interp, objv[i+1], &pad) != TCL_OK) {
              return TCL_ERROR;
          }
          break;
        case O_MARGINS:
          if (Ttk_GetBorderFromObj(interp, objv[i+1], &pad) != TCL_OK) {
              return TCL_ERROR;
          }
          flags |= PAD_MARGINS;
          break;
        case O_WIDTH:
          if (Tcl_GetIntFromObj(interp, objv[i+1], &tmp) != TCL_OK) {
              return TCL_ERROR;
          }
          pad.left = pad.right = tmp;
          flags |= IGNORE_THEMESIZE;
          break;
        case O_HEIGHT:
          if (Tcl_GetIntFromObj(interp, objv[i+1], &tmp) != TCL_OK) {
              return TCL_ERROR;
          }
          pad.top = pad.bottom = tmp;
          flags |= IGNORE_THEMESIZE;
          break;
        case O_SYSSIZE:
          if (GetSysFlagFromObj(interp, objv[i+1], &tmp) != TCL_OK) {
              return TCL_ERROR;
          }
          elementSpec = &GenericSizedElementSpec;
          flags |= (tmp & 0xFFFF);
          break;
        case O_HALFHEIGHT:
          if (Tcl_GetBooleanFromObj(interp, objv[i+1], &tmp) != TCL_OK) {
              return TCL_ERROR;
          }
          if (tmp)
              flags |= HALF_HEIGHT;
          break;
        case O_HALFWIDTH:
          if (Tcl_GetBooleanFromObj(interp, objv[i+1], &tmp) != TCL_OK) {
              return TCL_ERROR;
          }
          if (tmp)
              flags |= HALF_WIDTH;
          break;
        case O_ICONNAME:
          iconName = Tcl_GetString(objv[i+1]);
          break;
        case O_SIZE:
          if (Tcl_GetIntFromObj(interp, objv[i+1], &size) != TCL_OK) {
              return TCL_ERROR;
          }
          break;
        case O_ORIENTATION:
          if (Tcl_GetIndexFromObj(interp, objv[i+1], TtkGtk_orientationNames,
                    "orientation", 0, &orientation) != TCL_OK) {
              return TCL_ERROR;
          }
          orientation = TtkGtk_OrientationNames[orientation];
          break;
      }
    }
  }

  /* convert a statemap into a state table */
   stateTable = NULL;
  if (objc > 2) {
    Tcl_Obj **specs;
    int n,j,count, status = TCL_OK;
    if (Tcl_ListObjGetElements(interp, objv[2], &count, &specs) != TCL_OK)
        return TCL_ERROR;
    if (count) {
      /* we over-allocate to ensure there is a terminating entry */
      stateTable = ckalloc(sizeof(Ttk_StateTable) * (count + 1));
      memset(stateTable, 0, sizeof(Ttk_StateTable) * (count + 1));
      for (n = 0, j = 0; status == TCL_OK && n < count; n += 2, ++j) {
          Ttk_StateSpec spec = {0,0};
          status = Ttk_GetStateSpecFromObj(interp, specs[n], &spec);
          if (status == TCL_OK) {
            stateTable[j].onBits  = spec.onbits;
            stateTable[j].offBits = spec.offbits;
            status = TtkGtk_GetStateSpecFromObj(interp, specs[n+1], &spec);
            stateTable[j].index   = spec.onbits;
          }
      }
      if (status != TCL_OK) {
          ckfree(stateTable);
          return status;
      }
    }
  }

  elementPtr = ckalloc(sizeof(ElementInfo));
  memset(elementPtr, 0, sizeof(ElementInfo));
  elementPtr->elementSpec = elementSpec;
  elementPtr->partId      = partId;
  elementPtr->statemap    = stateTable;
  elementPtr->padding     = pad;
  elementPtr->flags       = HEAP_ELEMENT | flags;
  elementPtr->size        = size;
  elementPtr->orientation = orientation;

  /* set the element name to an allocated copy */
  name = ckalloc(strlen(elementName) + 1);
  strcpy(name, elementName);
  elementPtr->elementName = name;

  /* set the class name to an allocated copy */
  elementPtr->className = ckalloc(sizeof(char) * (length + 1));
  strncpy(elementPtr->className, className, length + 1);
  elementPtr->classNameIndex = classNameIndex;

  /* set the icon name to an allocated copy */
  if (iconName) {
    elementPtr->iconName = ckalloc(strlen(iconName) + 1);
    strcpy(elementPtr->iconName, iconName);
  }

  elementData = NewElementData(themeData, elementPtr);
  Ttk_RegisterElementSpec(
      theme, elementName, elementPtr->elementSpec, elementData);

  Ttk_RegisterCleanup(interp, elementData, DestroyElementData);
  Tcl_SetObjResult(interp, Tcl_NewStringObj(elementName, -1));
  return TCL_OK;
}; /* TtkGtk_CreateVsapiElement */

/*
 * ============================================================================
 *
 * TtkGtk element state tables
 *
 * ============================================================================
 */

unsigned int TtkGtk_Ttk2GtkState(unsigned int state) {
  unsigned int gtk_state = GTK_STATE_FLAG_NORMAL;

  if (state & TTK_STATE_ACTIVE)     gtk_state |= GTK_STATE_FLAG_PRELIGHT;
  if (state & TTK_STATE_DISABLED)   gtk_state |= GTK_STATE_FLAG_INSENSITIVE;
  if (state & TTK_STATE_FOCUS)      gtk_state |= GTK_STATE_FLAG_FOCUSED;
  if (state & TTK_STATE_PRESSED)    gtk_state |= GTK_STATE_FLAG_ACTIVE;
  if (state & TTK_STATE_BACKGROUND) gtk_state |= GTK_STATE_FLAG_BACKDROP;
  if (state & TTK_STATE_ALTERNATE)  gtk_state |= GTK_STATE_FLAG_INCONSISTENT;
  if (state & TTK_STATE_INVALID)    gtk_state |= GTK_STATE_FLAG_INCONSISTENT;
  if (state & TTK_STATE_READONLY)   gtk_state |= GTK_STATE_FLAG_INSENSITIVE;
  if (state & TTK_STATE_HOVER)      gtk_state |= GTK_STATE_FLAG_PRELIGHT;
  if (state & TTK_STATE_SELECTED)   {
      gtk_state |= GTK_STATE_FLAG_SELECTED;
      gtk_state |= GTK_STATE_FLAG_ACTIVE;     /* Needed for checkbuttons */
  }
  return gtk_state;
}; /* TtkGtk_Ttk2GtkState */

/*
 * ============================================================================
 *
 * TtkGtk widget layouts
 *
 * ============================================================================
 */
TTK_BEGIN_LAYOUT_TABLE(TtkGtk_LayoutTable)

TTK_LAYOUT("TButton",
    TTK_GROUP("Button.button", TTK_FILL_BOTH,
	TTK_GROUP("Button.focus", TTK_FILL_BOTH,
	    TTK_GROUP("Button.padding", TTK_FILL_BOTH,
		TTK_NODE("Button.label", TTK_FILL_BOTH)))))

TTK_END_LAYOUT_TABLE

TTK_BEGIN_LAYOUT(ButtonLayout)
TTK_GROUP("Button.button", TTK_FILL_BOTH,
	TTK_GROUP("Button.focus", TTK_FILL_BOTH,
	    TTK_GROUP("Button.padding", TTK_FILL_BOTH,
		TTK_NODE("Button.label", TTK_FILL_BOTH))))
TTK_END_LAYOUT

TTK_BEGIN_LAYOUT(SpinboxLayout)
     TTK_GROUP("Spinbox.field", TTK_PACK_TOP|TTK_FILL_X,
	 TTK_GROUP("null", TTK_PACK_RIGHT,
	     TTK_NODE("Spinbox.uparrow", TTK_PACK_RIGHT|TTK_STICK_E)
	     TTK_NODE("Spinbox.downarrow", TTK_PACK_LEFT|TTK_STICK_E))
	 TTK_GROUP("Spinbox.padding", TTK_FILL_BOTH,
	     TTK_NODE("Spinbox.textarea", TTK_FILL_BOTH)))
TTK_END_LAYOUT

/* Notebook tabs -- no focus ring */
TTK_BEGIN_LAYOUT(TabLayout)
    TTK_LAYOUT("Tab",
        TTK_GROUP("Notebook.tab", TTK_FILL_BOTH,
            TTK_GROUP("Notebook.padding", TTK_EXPAND|TTK_FILL_BOTH,
                TTK_NODE("Notebook.label", TTK_EXPAND|TTK_FILL_BOTH))))
TTK_END_LAYOUT


/*
 * ============================================================================
 *
 * TtkGtk element info table
 *
 * ============================================================================
 */

#define PAD(l,t,r,b) {l,t,r,b}
#define NOPAD {0,0,0,0}

/* name spec className classNameIndex partId statemap padding flags
 * angle size orientation */
static ElementInfo ElementInfoTable[] = {
 /* Buttons */
 { "Checkbutton.indicator", &GenericElementSpec, GTK_STYLE_CLASS_CHECK,
	CN_CLASS_CHECK,		PN_CHECK,		NULL,
	NOPAD, 0, 0, 0, 0 },
 { "Checkbutton.focus",     &GenericElementSpec, GTK_STYLE_CLASS_CHECK,
	CN_CLASS_CHECK,		PN_FOCUS,		NULL,
	NOPAD, 0, 0, 0, 0 },
 { "Radiobutton.indicator", &GenericElementSpec, GTK_STYLE_CLASS_RADIO,
	CN_CLASS_RADIO,		PN_CHECK,		NULL,
	NOPAD, 0, 0, 0, 0 },
 { "Radiobutton.focus",     &GenericElementSpec, GTK_STYLE_CLASS_RADIO,
	CN_CLASS_RADIO,		PN_FOCUS,		NULL,
	NOPAD, 0, 0, 0, 0 },
 { "Button.button",         &GenericElementSpec, GTK_STYLE_CLASS_BUTTON,
	CN_CLASS_BUTTON,	PN_BUTTON,		NULL,
	NOPAD, 0, 0, 0, 0 },
 { "Button.focus",          &GenericElementSpec, GTK_STYLE_CLASS_BUTTON,
	CN_CLASS_BUTTON,	PN_FOCUS,		NULL,
	NOPAD, 0, 0, 0, 0 },

 /* Entries */
 { "Entry.field",           &GenericElementSpec, GTK_STYLE_CLASS_ENTRY,
	CN_CLASS_ENTRY,		PN_BACKGROUND_FRAME,	NULL,
	NOPAD, 0, 0, 0, 0 },
 { "Combobox.field",        &GenericElementSpec, GTK_STYLE_CLASS_BUTTON,
	CN_CLASS_BUTTON,	PN_BUTTON,		NULL,
	NOPAD, 0, 0, 0, 0 },
 { "Combobox.downarrow",    &GenericElementSpec, GTK_STYLE_CLASS_COMBOBOX_ENTRY,
	CN_CLASS_COMBOBOX_ENTRY,PN_ARROW,		NULL,
	NOPAD, 0, 0, 0, GTK_ARROW_DOWN },
 { "Menubutton.border",     &GenericElementSpec, GTK_STYLE_CLASS_BUTTON,
	CN_CLASS_BUTTON,	PN_BUTTON,		NULL,
	NOPAD, 0, 0, 0, 0 },
 { "Menubutton.indicator",  &GenericElementSpec, GTK_STYLE_CLASS_COMBOBOX_ENTRY,
	CN_CLASS_COMBOBOX_ENTRY,PN_ARROW,		NULL,
	NOPAD, 0, 0, 0, GTK_ARROW_DOWN },
 { "Spinbox.field",         &GenericElementSpec, GTK_STYLE_CLASS_ENTRY,
	CN_CLASS_ENTRY,		PN_BACKGROUND_FRAME,	NULL,
	NOPAD, 0, 0, 0, 0 },
 { "Spinbox.uparrow",       &GenericElementSpec, GTK_STYLE_CLASS_SPINBUTTON,
	CN_CLASS_SPINBUTTON,	PN_ICON,		NULL,
	NOPAD, GTK_ICON_LOOKUP_USE_BUILTIN | GTK_ICON_LOOKUP_GENERIC_FALLBACK |
               GTK_ICON_LOOKUP_FORCE_SIZE,
        "list-add-symbolic",	GTK_ICON_SIZE_MENU, 0 },
 { "Spinbox.downarrow",     &GenericElementSpec, GTK_STYLE_CLASS_SPINBUTTON,
	CN_CLASS_SPINBUTTON,	PN_ICON,		NULL,
	NOPAD, GTK_ICON_LOOKUP_USE_BUILTIN | GTK_ICON_LOOKUP_GENERIC_FALLBACK |
               GTK_ICON_LOOKUP_FORCE_SIZE,
        "list-remove-symbolic",	GTK_ICON_SIZE_MENU, 0 },

 /* Scales, Progressbars */
 { "Horizontal.Scale.trough",	&GenericElementSpec,	GTK_STYLE_CLASS_SCALE,
	CN_CLASS_SCALE,		PN_BACKGROUND_FRAME,	NULL,
	NOPAD, 0, 0, 0, GTK_ORIENTATION_HORIZONTAL },
 { "Horizontal.Scale.slider",	&GenericElementSpec,	GTK_STYLE_CLASS_SCALE,
	CN_CLASS_SCALE,		PN_SLIDER,		NULL,
	NOPAD, 0, 0, 0, GTK_ORIENTATION_HORIZONTAL },
 { "Vertical.Scale.trough",	&GenericElementSpec,	GTK_STYLE_CLASS_SCALE,
	CN_CLASS_SCALE,		PN_BACKGROUND_FRAME,	NULL,
	NOPAD, 0, 0, 0, GTK_ORIENTATION_VERTICAL },
 { "Vertical.Scale.slider",	&GenericElementSpec,	GTK_STYLE_CLASS_SCALE,
	CN_CLASS_SCALE,		PN_SLIDER,		NULL,
	NOPAD, 0, 0, 0, GTK_ORIENTATION_VERTICAL },
 { "Horizontal.Progressbar.trough", &GenericElementSpec, GTK_STYLE_CLASS_TROUGH,
	CN_CLASS_PROGRESSBAR,	PN_BACKGROUND_FRAME,	NULL,
	NOPAD, 0, 0, 0, GTK_ORIENTATION_HORIZONTAL },
 { "Horizontal.Progressbar.pbar", &GenericElementSpec,	GTK_STYLE_CLASS_PROGRESSBAR,
	CN_CLASS_PROGRESSBAR,	PN_ACTIVITY,		NULL,
	NOPAD, 0, 0, 0, GTK_ORIENTATION_HORIZONTAL },
 { "Vertical.Progressbar.trough", &GenericElementSpec,	GTK_STYLE_CLASS_TROUGH,
	CN_CLASS_PROGRESSBAR,	PN_BACKGROUND_FRAME,	NULL,
	NOPAD, 0, 0, 0, GTK_ORIENTATION_VERTICAL },
 { "Vertical.Progressbar.pbar",	&GenericElementSpec,	GTK_STYLE_CLASS_PROGRESSBAR,
	CN_CLASS_PROGRESSBAR,	PN_ACTIVITY,		NULL,
	NOPAD, 0, 0, 0, GTK_ORIENTATION_VERTICAL },

 /* Scrollbars */
 { "Horizontal.Scrollbar.trough", &GenericElementSpec, GTK_STYLE_CLASS_SCROLLBAR,
	CN_CLASS_SCROLLBAR,	PN_BACKGROUND_FRAME,	NULL,
	NOPAD, 0, 0, 0, GTK_ORIENTATION_HORIZONTAL },
 { "Horizontal.Scrollbar.thumb", &GenericElementSpec, GTK_STYLE_CLASS_SCROLLBAR,
	CN_CLASS_SCROLLBAR,	PN_SLIDER,		NULL,
	NOPAD, 0, 0, 0, GTK_ORIENTATION_HORIZONTAL },
 { "Horizontal.Scrollbar.leftarrow", &GenericElementSpec, GTK_STYLE_CLASS_SCROLLBAR,
	CN_CLASS_SCROLLBAR,	PN_ARROW,		NULL,
	NOPAD, 0, 0, 0, GTK_ARROW_LEFT },
 { "Horizontal.Scrollbar.rightarrow", &GenericElementSpec, GTK_STYLE_CLASS_SCROLLBAR,
	CN_CLASS_SCROLLBAR,	PN_ARROW,		NULL,
	NOPAD, 0, 0, 0, GTK_ARROW_RIGHT },
 { "Vertical.Scrollbar.trough", &GenericElementSpec, GTK_STYLE_CLASS_SCROLLBAR,
	CN_CLASS_SCROLLBAR,	PN_BACKGROUND_FRAME,	NULL,
	NOPAD, 0, 0, 0, GTK_ORIENTATION_VERTICAL },
 { "Vertical.Scrollbar.thumb", &GenericElementSpec, GTK_STYLE_CLASS_SCROLLBAR,
	CN_CLASS_SCROLLBAR,	PN_SLIDER,		NULL,
	NOPAD, 0, 0, 0, GTK_ORIENTATION_VERTICAL },
 { "Vertical.Scrollbar.uparrow", &GenericElementSpec, GTK_STYLE_CLASS_SCROLLBAR,
	CN_CLASS_SCROLLBAR,	PN_ARROW,		NULL,
	NOPAD, 0, 0, 0, GTK_ARROW_UP },
 { "Vertical.Scrollbar.downarrow", &GenericElementSpec, GTK_STYLE_CLASS_SCROLLBAR,
	CN_CLASS_SCROLLBAR,	PN_ARROW,		NULL,
	NOPAD, 0, 0, 0, GTK_ARROW_DOWN },

 /* Notebook */
 { "Notebook.client",       &GenericElementSpec, GTK_STYLE_CLASS_NOTEBOOK,
	CN_CLASS_NOTEBOOK,	PN_BACKGROUND_FRAME,	NULL,
	NOPAD, 0, 0, 0, 0 },
 { "Notebook.tab"   ,       &GenericElementSpec, GTK_STYLE_CLASS_NOTEBOOK,
	CN_CLASS_NOTEBOOK,	PN_EXTENSION,		NULL,
	NOPAD, 0, 0, 0, GTK_POS_TOP },
 { "Notebook.focus",        &GenericElementSpec, GTK_STYLE_CLASS_NOTEBOOK,
	CN_CLASS_NOTEBOOK,	PN_FOCUS,		NULL,
	NOPAD, 0, 0, 0, 0 },

 /* Handles */
 { "sizegrip",              &GenericElementSpec, GTK_STYLE_CLASS_GRIP,
	CN_CLASS_GRIP,		PN_HANDLE,		NULL,
	NOPAD, 0, 0, 0, 0 },
 { "separator",             &GenericElementSpec, GTK_STYLE_CLASS_SEPARATOR,
	CN_CLASS_SEPARATOR,	PN_SEPARATOR,		NULL,
	NOPAD, 0, 0, 0, GTK_ORIENTATION_VERTICAL },
 { "hsash",                 &GenericElementSpec, GTK_STYLE_CLASS_PANE_SEPARATOR,
	CN_CLASS_PANE_SEPARATOR,PN_HANDLE,		NULL,
	NOPAD, 0, 0, 0, GTK_ORIENTATION_HORIZONTAL },
 { "vsash",                 &GenericElementSpec, GTK_STYLE_CLASS_PANE_SEPARATOR,
	CN_CLASS_PANE_SEPARATOR,PN_HANDLE,		NULL,
	NOPAD, 0, 0, 0, GTK_ORIENTATION_VERTICAL },

 /* Frames */
 { "Labelframe.border",     &GenericElementSpec, GTK_STYLE_CLASS_FRAME,
	CN_CLASS_FRAME,		PN_FRAME,		NULL,
	NOPAD, 0, 0, 0, GTK_ORIENTATION_HORIZONTAL },

 /* Treeview */
 { "Treeview.field",        &GenericElementSpec, GTK_STYLE_CLASS_VIEW,
	CN_CLASS_VIEW,		PN_BACKGROUND_FRAME,	NULL,
	NOPAD, 0, 0, 0, 0 },
 { "Treeheading.border",    &GenericElementSpec, GTK_STYLE_CLASS_VIEW,
	CN_CLASS_VIEW,		PN_HEADER_ROW,		NULL,
	NOPAD, 0, 0, 0, 0 },
 { "Treeitem.indicator",    &GenericElementSpec, GTK_STYLE_CLASS_VIEW,
	CN_CLASS_VIEW,		PN_EXPANDER,		NULL,
	PAD(4,4,4,4), 0, 0, 0, 0 },
 { "Treeitem.row",          &GenericElementSpec, GTK_STYLE_CLASS_VIEW,
	CN_CLASS_VIEW,		PN_ROW,			NULL,
	NOPAD, 0, 0, 0, 0 },

 { 0, 0, 0, 0, 0, 0, NOPAD, 0, 0, 0, 0 }
};
#undef PAD
#undef NOPAD

int TtkGtkTheme_Init(Tcl_Interp *interp, GtkThemeData **td) {
  GtkThemeData *themeData;
  Ttk_Theme themePtr;
  ElementInfo *infoPtr;

  /*
   * Set theme data and cleanup proc
   */
  themeData = ckalloc(sizeof(GtkThemeData));
  if (!themeData) return TCL_ERROR;
  memset(themeData, 0, sizeof(GtkThemeData));
  TtkGtk_AllocateCairoContexts(themeData);
  Ttk_RegisterCleanup(interp, themeData, TtkGtk_ThemeDeleteProc);

  /*
   * Create the new style engine.
   */
  themePtr = Ttk_CreateTheme(interp, PACKAGE_NAME, NULL);
  if (!themePtr) return TCL_ERROR;

#ifdef Ttk_SetThemeEnabledProc
  Ttk_SetThemeEnabledProc(themePtr, TtkGtk_ThemeEnabled, themeData);
#endif
  Ttk_RegisterElementFactory(interp, "vsapi",
      TtkGtk_CreateVsapiElement, themeData);

  /*
   * Register elements:
   */
  for (infoPtr = ElementInfoTable; infoPtr->elementName != 0; ++infoPtr) {
     ClientData clientData = NewElementData(themeData, infoPtr);
     Ttk_RegisterElementSpec(
         themePtr, infoPtr->elementName, infoPtr->elementSpec, clientData);
     Ttk_RegisterCleanup(interp, clientData, DestroyElementData);
  }

  /*
   * Layouts:
   */
  // Ttk_RegisterLayouts(themePtr, TtkGtk_LayoutTable);
  Ttk_RegisterLayout(themePtr, "TButton",   ButtonLayout);
  Ttk_RegisterLayout(themePtr, "TSpinbox",  SpinboxLayout);
  Ttk_RegisterLayout(themePtr, "Tab",       TabLayout);

  Tcl_PkgProvide(interp, "ttk::theme::"PACKAGE_NAME, PACKAGE_VERSION);

  if (td) *td = themeData;

  return TCL_OK;
}; /* TtkGtkTheme_Init */
