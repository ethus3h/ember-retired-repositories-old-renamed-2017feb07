/*
 * ttk-gtk.c 
 * -------------------
 *
 * This file is part of the TtkGtk package, a Ttk based theme that uses
 * Gtk/GNOME for drawing.
 *
 * Copyright (C) 2012 by:
 * Georgios Petasis, petasis@iit.demokritos.gr, petasisg@yahoo.gr
 * Software and Knowledge Engineering Laboratory,
 * Institute of Informatics and Telecommunications,
 * National Centre for Scientific Research (NCSR) "Demokritos",
 * Aghia Paraskevi, 153 10, Athens, Greece.
 *
 */

#include "ttkgtk.h"

extern int TtkGtk_CairoInit(ClientData clientData, Tcl_Interp *interp,
                    int objc, Tcl_Obj *const objv[]);
extern int TtkGtk_GtkInit(ClientData clientData, Tcl_Interp *interp,
                    int objc, Tcl_Obj *const objv[]);

int Ttkgtk_Init(Tcl_Interp *interp) {
  /*
   * Initialise Tcl stubs, ensure Tk is loaded, and initialise Tk stubs...
   */
  if (Tcl_InitStubs(interp, "8.6", 0) == NULL) {
    return TCL_ERROR;
  }
  if (Tcl_PkgRequire(interp, "Tk", "8.6", 0) == NULL) {
    return TCL_ERROR;
  }
  if (Tk_InitStubs(interp, "8.6", 0) == NULL) {
    return TCL_ERROR;
  }
  if (Ttk_InitStubs(interp) == NULL) {
    return TCL_ERROR;
  }

  /*
   * Create our namespace...
   */
  if (Tcl_Eval(interp, "namespace eval ::ttk::theme::" PACKAGE_NAME
          " { variable version " PACKAGE_VERSION " };") != TCL_OK) {
    return TCL_ERROR;
  }

  /*
   * Define the package commands...
   */
  Tcl_CreateObjCommand(interp, "::ttk::theme::" PACKAGE_NAME
                               "::initialiseCairo",
      TtkGtk_CairoInit, (ClientData) NULL, NULL);
  Tcl_CreateObjCommand(interp, "::ttk::theme::" PACKAGE_NAME
                               "::initialiseGtk",
      TtkGtk_GtkInit, (ClientData) NULL, NULL);

  /* This sill provide the package ttkgtk */
  if (Tcl_PkgProvide(interp, PACKAGE_NAME, PACKAGE_VERSION) != TCL_OK) {
    return TCL_ERROR;
  }

  /* Initialise our libraries... */
#ifdef LINK_TO_GTK
  if (Tcl_Eval(interp, "::ttk::theme::"PACKAGE_NAME"::initialise 0;") != TCL_OK)
    return TCL_ERROR;
#else
  if (Tcl_Eval(interp, "::ttk::theme::"PACKAGE_NAME"::initialise 1;") != TCL_OK)
    return TCL_ERROR;
#endif

  return TCL_OK;
}; /* Ttkgtk_Init */
