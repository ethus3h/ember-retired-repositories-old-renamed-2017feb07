/*
 * symbols.h 
 * -------------------
 *
 * This file is part of the TtkGtk package, a Ttk based theme that uses
 * Gtk/GNOME for drawing.
 *
 * Copyright (C) 2012 by:
 * Georgios Petasis, petasis@iit.demokritos.gr, petasisg@yahoo.gr
 * Software and Knowledge Engineering Laboratory,
 * Institute of Informatics and Telecommunications,
 * National Centre for Scientific Research (NCSR) "Demokritos",
 * Aghia Paraskevi, 153 10, Athens, Greece.
 *
 */

#ifndef _TTKGTK_SYMBOLS_H
#define _TTKGTK_SYMBOLS_H

#include "ttkgtk.h"

/* Declare symbol type */
#define DST(m, t, ...) \
typedef t (*ptr_##m) (__VA_ARGS__);

/*
 * ============================================================================
 *
 * Symbols we need from the Cairo library...
 *
 * ============================================================================
 */

#ifdef CAIRO_HAS_XLIB_SURFACE
DST(cairo_xlib_surface_create, cairo_surface_t*,Display *dpy,
	Drawable drawable, Visual *visual, int width, int height);
#endif /* CAIRO_HAS_XLIB_SURFACE */
DST(cairo_create, cairo_t*, cairo_surface_t *target);
DST(cairo_surface_destroy, void, cairo_surface_t *surface);
DST(cairo_destroy, void, cairo_t *cr);

/*
 * ============================================================================
 * End of section for symbols we need from the Cairo library...
 * ============================================================================
 */

/*
 * ============================================================================
 *
 * Symbols we need from the Gtk library...
 *
 * ============================================================================
 */

DST(gtk_init, void, int *argc, char ***argv);

DST(gtk_style_context_new, GtkStyleContext*, void);
DST(gtk_style_context_get_border, void, GtkStyleContext *context,
	GtkStateFlags state, GtkBorder *border);
DST(gtk_style_context_get_background_color, void, GtkStyleContext *context,
	GtkStateFlags state, GdkRGBA *color);
DST(gtk_style_context_get_color, void, GtkStyleContext *context,
	GtkStateFlags state, GdkRGBA *color);
DST(gtk_style_context_get_style, void, GtkStyleContext *context, ...);
DST(gtk_style_context_get_style_property, void, GtkStyleContext *context,
	const gchar *property_name, GValue *value);
DST(gtk_style_context_get_padding, void, GtkStyleContext *context,
	GtkStateFlags state, GtkBorder *padding);
DST(gtk_style_context_get_path, GtkWidgetPath*, GtkStyleContext *context);
DST(gtk_style_context_set_junction_sides, void, GtkStyleContext *context,
	GtkJunctionSides sides);
DST(gtk_style_context_set_path, void, GtkStyleContext *context,
	GtkWidgetPath *path);
DST(gtk_style_context_set_screen, void, GtkStyleContext *context,
	GdkScreen *screen);
DST(gtk_style_context_set_state, void, GtkStyleContext *context,
	GtkStateFlags flags);
DST(gtk_style_context_add_class, void, GtkStyleContext *context,
	const gchar *class_name);
DST(gtk_style_context_add_region, void, GtkStyleContext *context,
	const gchar *region_name, GtkRegionFlags flags);
DST(gtk_style_context_remove_class, void, GtkStyleContext *context,
	const gchar *class_name);
DST(gtk_style_context_save, void, GtkStyleContext *context);
DST(gtk_style_context_restore, void, GtkStyleContext *context);

DST(gtk_widget_path_new, GtkWidgetPath*, void);
DST(gtk_widget_path_append_type, gint, GtkWidgetPath *path,
	GType type);
DST(gtk_widget_path_append_with_siblings, gint, GtkWidgetPath *path,
	GtkWidgetPath *siblings, guint sibling_index);
DST(gtk_widget_path_iter_add_class, void, GtkWidgetPath *path,
	gint pos, const gchar *name);
DST(gtk_widget_path_get_object_type, GType, GtkWidgetPath *path);
DST(gtk_widget_path_to_string, char*, GtkWidgetPath *path);
DST(gtk_widget_path_ref, GtkWidgetPath*, GtkWidgetPath *path);
DST(gtk_widget_path_free, void, GtkWidgetPath *path);

DST(gtk_icon_theme_get_default, GtkIconTheme*, void);
DST(gtk_icon_theme_lookup_icon, GtkIconInfo*, GtkIconTheme *icon_theme,
	 const gchar *icon_name, gint size, GtkIconLookupFlags flags);
DST(gtk_icon_info_free, void, GtkIconInfo *icon_info);
DST(gtk_icon_info_get_filename, const gchar*, GtkIconInfo *icon_info);
DST(gtk_icon_info_load_symbolic_for_context, GdkPixbuf*, GtkIconInfo *icon_info,
	GtkStyleContext *context, gboolean *was_symbolic, GError **error);
DST(gtk_icon_size_lookup_for_settings, void, GtkSettings *settings,
	GtkIconSize icon_size, gint *width_out, gint *height_out);

DST(gtk_settings_get_default, GtkSettings*, void);

DST(g_object_new, GObject*, GType object_type,
	const gchar *first_property_name, ...);
DST(g_object_get_property, void, GObject *object,
	const gchar *property_name, GValue *value);
DST(g_object_set_property, void, GObject *object,
	const gchar *property_name, GValue *value);
DST(g_object_unref, void, GObject *object);

DST(g_value_init, void, GValue *value, GType g_type);
DST(g_value_get_string, const gchar*, GValue *value);
DST(g_value_unset, void, GValue *value);

DST(gdk_screen_get_default, GdkScreen*, void);

DST(gtk_border_free, void, GtkBorder *border);

DST(gtk_render_activity, void, GtkStyleContext *context, cairo_t *cr,
	gdouble x, gdouble y, gdouble width, gdouble height);
DST(gtk_render_background, void, GtkStyleContext *context, cairo_t *cr,
	gdouble x, gdouble y, gdouble width, gdouble height);
DST(gtk_render_arrow, void, GtkStyleContext *context, cairo_t *cr,
	gdouble angle, gdouble x, gdouble y, gdouble size);
DST(gtk_render_check, void, GtkStyleContext *context, cairo_t *cr,
	gdouble x, gdouble y, gdouble width, gdouble height);
DST(gtk_render_expander, void, GtkStyleContext *context, cairo_t *cr,
	gdouble x, gdouble y, gdouble width, gdouble height);
DST(gtk_render_extension, void, GtkStyleContext *context, cairo_t *cr,
	gdouble x, gdouble y, gdouble width, gdouble height,
	GtkPositionType gap_side);
DST(gtk_render_focus, void, GtkStyleContext *context, cairo_t *cr,
	gdouble x, gdouble y, gdouble width, gdouble height);
DST(gtk_render_frame, void, GtkStyleContext *context, cairo_t *cr,
	gdouble x, gdouble y, gdouble width, gdouble height);
DST(gtk_render_frame_gap, void, GtkStyleContext *context, cairo_t *cr,
	gdouble x, gdouble y, gdouble width, gdouble height,
	GtkPositionType gap_side, gdouble xy0_gap, gdouble xy1_gap);
DST(gtk_render_handle, void, GtkStyleContext *context, cairo_t *cr,
	gdouble x, gdouble y, gdouble width, gdouble height);
DST(gtk_render_layout, void, GtkStyleContext *context, cairo_t *cr,
	gdouble x, gdouble y, PangoLayout *layout);
DST(gtk_render_line, void, GtkStyleContext *context, cairo_t *cr,
	gdouble x0, gdouble y0, gdouble x1, gdouble y1);
DST(gtk_render_option, void, GtkStyleContext *context, cairo_t *cr,
	gdouble x, gdouble y, gdouble width, gdouble height);
DST(gtk_render_slider, void, GtkStyleContext *context, cairo_t *cr,
	gdouble x, gdouble y, gdouble width, gdouble height,
	GtkOrientation orientation);
DST(gtk_render_icon_pixbuf, void, GtkStyleContext *context,
	const GtkIconSource *source, GtkIconSize size);
DST(gtk_render_icon, void, GtkStyleContext *context, cairo_t *cr,
	GdkPixbuf *pixbuf, gdouble x, gdouble y);
DST(gtk_render_insertion_cursor, void, GtkStyleContext *context, cairo_t *cr,
	gdouble x, gdouble y, PangoLayout *layout, int index,
	PangoDirection direction);

DST(gtk_window_get_type, GType, void);
DST(gtk_button_get_type, GType, void);
DST(gtk_check_button_get_type, GType, void);
DST(gtk_toggle_button_get_type, GType, void);
DST(gtk_radio_button_get_type, GType, void);
DST(gtk_spin_button_get_type, GType, void);
DST(gtk_entry_get_type, GType, void);
DST(gtk_combo_box_get_type, GType, void);
DST(gtk_scale_get_type, GType, void);
DST(gtk_progress_bar_get_type, GType, void);
DST(gtk_scrollbar_get_type, GType, void);
DST(gtk_notebook_get_type, GType, void);
DST(gtk_paned_get_type, GType, void);
DST(gtk_frame_get_type, GType, void);
DST(gtk_tree_view_get_type, GType, void);
DST(gtk_arrow_get_type, GType, void);

#undef DST

/*
 * ============================================================================
 * End of section for symbols we need from the Gtk library...
 * ============================================================================
 */

#ifdef LINK_TO_GTK

/*
 * Use Cairo symbols
 */

#define TtkGtk_cairo_xlib_surface_create		cairo_xlib_surface_create
#define TtkGtk_cairo_create				cairo_create
#define TtkGtk_cairo_surface_destroy			cairo_surface_destroy
#define TtkGtk_cairo_destroy				cairo_destroy

/*
 * Use Gtk symbols
 */

#define TtkGtk_gtk_init					gtk_init

#define TtkGtk_gtk_style_context_new			gtk_style_context_new
#define TtkGtk_gtk_style_context_get_border		gtk_style_context_get_border
#define TtkGtk_gtk_style_context_get_background_color	gtk_style_context_get_background_color
#define TtkGtk_gtk_style_context_get_color		gtk_style_context_get_color
#define TtkGtk_gtk_style_context_get_style		gtk_style_context_get_style
#define TtkGtk_gtk_style_context_get_style_property	gtk_style_context_get_style_property
#define TtkGtk_gtk_style_context_get_padding		gtk_style_context_get_padding
#define TtkGtk_gtk_style_context_get_path		gtk_style_context_get_path
#define TtkGtk_gtk_style_context_set_junction_sides	gtk_style_context_set_junction_sides
#define TtkGtk_gtk_style_context_set_path		gtk_style_context_set_path
#define TtkGtk_gtk_style_context_set_screen		gtk_style_context_set_screen
#define TtkGtk_gtk_style_context_set_state		gtk_style_context_set_state
#define TtkGtk_gtk_style_context_add_class		gtk_style_context_add_class
#define TtkGtk_gtk_style_context_add_region		gtk_style_context_add_region
#define TtkGtk_gtk_style_context_remove_class		gtk_style_context_remove_class
#define TtkGtk_gtk_style_context_save			gtk_style_context_save
#define TtkGtk_gtk_style_context_restore		gtk_style_context_restore

#define TtkGtk_gtk_widget_path_new			gtk_widget_path_new
#define TtkGtk_gtk_widget_path_append_type		gtk_widget_path_append_type
#define TtkGtk_gtk_widget_path_append_with_siblings	gtk_widget_path_append_with_siblings
#define TtkGtk_gtk_widget_path_iter_add_class		gtk_widget_path_iter_add_class
#define TtkGtk_gtk_widget_path_get_object_type		gtk_widget_path_get_object_type
#define TtkGtk_gtk_widget_path_to_string		gtk_widget_path_to_string
#define TtkGtk_gtk_widget_path_ref			gtk_widget_path_ref
#define TtkGtk_gtk_widget_path_free			gtk_widget_path_free

#define TtkGtk_gtk_icon_theme_get_default		gtk_icon_theme_get_default
#define TtkGtk_gtk_icon_theme_lookup_icon		gtk_icon_theme_lookup_icon
#define TtkGtk_gtk_icon_info_free			gtk_icon_info_free
#define TtkGtk_gtk_icon_info_get_filename		gtk_icon_info_get_filename
#define TtkGtk_gtk_icon_info_load_symbolic_for_context	gtk_icon_info_load_symbolic_for_context
#define TtkGtk_gtk_icon_size_lookup_for_settings	gtk_icon_size_lookup_for_settings

#define TtkGtk_gtk_settings_get_default			gtk_settings_get_default

#define TtkGtk_g_object_new				g_object_new
#define TtkGtk_g_object_get_property			g_object_get_property
#define TtkGtk_g_object_set_property			g_object_set_property
#define TtkGtk_g_object_unref				g_object_unref

#define TtkGtk_g_value_init				g_value_init
#define TtkGtk_g_value_get_string			g_value_get_string
#define TtkGtk_g_value_unset				g_value_unset

#define TtkGtk_gdk_screen_get_default			gdk_screen_get_default

#define TtkGtk_gtk_border_free				gtk_border_free

#define TtkGtk_gtk_render_background			gtk_render_background
#define TtkGtk_gtk_render_arrow				gtk_render_arrow
#define TtkGtk_gtk_render_check				gtk_render_check
#define TtkGtk_gtk_render_expander			gtk_render_expander
#define TtkGtk_gtk_render_focus				gtk_render_focus
#define TtkGtk_gtk_render_frame				gtk_render_frame
#define TtkGtk_gtk_render_handle			gtk_render_handle
#define TtkGtk_gtk_render_line				gtk_render_line
#define TtkGtk_gtk_render_option			gtk_render_option
#define TtkGtk_gtk_render_activity			gtk_render_activity
#define TtkGtk_gtk_render_extension			gtk_render_extension
#define TtkGtk_gtk_render_frame_gap			gtk_render_frame_gap
#define TtkGtk_gtk_render_layout			gtk_render_layout
#define TtkGtk_gtk_render_slider			gtk_render_slider
#define TtkGtk_gtk_render_icon_pixbuf			gtk_render_icon_pixbuf
#define TtkGtk_gtk_render_icon				gtk_render_icon
#define TtkGtk_gtk_render_insertion_cursor		gtk_render_insertion_cursor

#define TtkGtk_gtk_window_get_type			gtk_window_get_type
#define TtkGtk_gtk_button_get_type			gtk_button_get_type
#define TtkGtk_gtk_check_button_get_type		gtk_check_button_get_type
#define TtkGtk_gtk_toggle_button_get_type		gtk_toggle_button_get_type
#define TtkGtk_gtk_radio_button_get_type		gtk_radio_button_get_type
#define TtkGtk_gtk_spin_button_get_type			gtk_spin_button_get_type
#define TtkGtk_gtk_entry_get_type			gtk_entry_get_type
#define TtkGtk_gtk_combo_box_get_type			gtk_combo_box_get_type
#define TtkGtk_gtk_scale_get_type			gtk_scale_get_type
#define TtkGtk_gtk_progress_bar_get_type		gtk_progress_bar_get_type
#define TtkGtk_gtk_scrollbar_get_type			gtk_scrollbar_get_type
#define TtkGtk_gtk_notebook_get_type			gtk_notebook_get_type
#define TtkGtk_gtk_paned_get_type			gtk_paned_get_type
#define TtkGtk_gtk_frame_get_type			gtk_frame_get_type
#define TtkGtk_gtk_tree_view_get_type			gtk_tree_view_get_type
#define TtkGtk_gtk_arrow_get_type			gtk_arrow_get_type

#else

/*
 * Use our symbol table
 */

/* Define symbol */
#define DEFINE_SYMBOL(m) \
ptr_##m p_##m;

typedef struct {
#ifdef    CAIRO_HAS_XLIB_SURFACE
  DEFINE_SYMBOL(cairo_xlib_surface_create);
#endif /* CAIRO_HAS_XLIB_SURFACE */
  DEFINE_SYMBOL(cairo_create);
  DEFINE_SYMBOL(cairo_surface_destroy);
  DEFINE_SYMBOL(cairo_destroy);

  DEFINE_SYMBOL(gtk_init);

  DEFINE_SYMBOL(gtk_style_context_new);
  DEFINE_SYMBOL(gtk_style_context_get_border);
  DEFINE_SYMBOL(gtk_style_context_get_background_color);
  DEFINE_SYMBOL(gtk_style_context_get_color);
  DEFINE_SYMBOL(gtk_style_context_get_style);
  DEFINE_SYMBOL(gtk_style_context_get_style_property);
  DEFINE_SYMBOL(gtk_style_context_get_padding);
  DEFINE_SYMBOL(gtk_style_context_get_path);
  DEFINE_SYMBOL(gtk_style_context_set_junction_sides);
  DEFINE_SYMBOL(gtk_style_context_set_path);
  DEFINE_SYMBOL(gtk_style_context_set_screen);
  DEFINE_SYMBOL(gtk_style_context_set_state);
  DEFINE_SYMBOL(gtk_style_context_add_class);
  DEFINE_SYMBOL(gtk_style_context_add_region);
  DEFINE_SYMBOL(gtk_style_context_remove_class);
  DEFINE_SYMBOL(gtk_style_context_save);
  DEFINE_SYMBOL(gtk_style_context_restore);

  DEFINE_SYMBOL(gtk_widget_path_new);
  DEFINE_SYMBOL(gtk_widget_path_append_type);
  DEFINE_SYMBOL(gtk_widget_path_append_with_siblings);
  DEFINE_SYMBOL(gtk_widget_path_iter_add_class);
  DEFINE_SYMBOL(gtk_widget_path_get_object_type);
  DEFINE_SYMBOL(gtk_widget_path_to_string);
  DEFINE_SYMBOL(gtk_widget_path_ref);
  DEFINE_SYMBOL(gtk_widget_path_free);

  DEFINE_SYMBOL(gtk_icon_theme_get_default);
  DEFINE_SYMBOL(gtk_icon_theme_lookup_icon);
  DEFINE_SYMBOL(gtk_icon_info_free);
  DEFINE_SYMBOL(gtk_icon_info_get_filename);
  DEFINE_SYMBOL(gtk_icon_info_load_symbolic_for_context);
  DEFINE_SYMBOL(gtk_icon_size_lookup_for_settings);

  DEFINE_SYMBOL(gtk_settings_get_default);

  DEFINE_SYMBOL(g_object_new);
  DEFINE_SYMBOL(g_object_get_property);
  DEFINE_SYMBOL(g_object_set_property);
  DEFINE_SYMBOL(g_object_unref);

  DEFINE_SYMBOL(g_value_init);
  DEFINE_SYMBOL(g_value_get_string);
  DEFINE_SYMBOL(g_value_unset);

  DEFINE_SYMBOL(gdk_screen_get_default);

  DEFINE_SYMBOL(gtk_border_free);

  DEFINE_SYMBOL(gtk_render_background);
  DEFINE_SYMBOL(gtk_render_arrow);
  DEFINE_SYMBOL(gtk_render_check);
  DEFINE_SYMBOL(gtk_render_expander);
  DEFINE_SYMBOL(gtk_render_focus);
  DEFINE_SYMBOL(gtk_render_frame);
  DEFINE_SYMBOL(gtk_render_handle);
  DEFINE_SYMBOL(gtk_render_line);
  DEFINE_SYMBOL(gtk_render_option);
  DEFINE_SYMBOL(gtk_render_activity);
  DEFINE_SYMBOL(gtk_render_extension);
  DEFINE_SYMBOL(gtk_render_frame_gap);
  DEFINE_SYMBOL(gtk_render_layout);
  DEFINE_SYMBOL(gtk_render_slider);
  DEFINE_SYMBOL(gtk_render_icon_pixbuf);
  DEFINE_SYMBOL(gtk_render_icon);
  DEFINE_SYMBOL(gtk_render_insertion_cursor);

  DEFINE_SYMBOL(gtk_window_get_type);
  DEFINE_SYMBOL(gtk_button_get_type);
  DEFINE_SYMBOL(gtk_check_button_get_type);
  DEFINE_SYMBOL(gtk_toggle_button_get_type);
  DEFINE_SYMBOL(gtk_radio_button_get_type);
  DEFINE_SYMBOL(gtk_spin_button_get_type);
  DEFINE_SYMBOL(gtk_entry_get_type);
  DEFINE_SYMBOL(gtk_combo_box_get_type);
  DEFINE_SYMBOL(gtk_scale_get_type);
  DEFINE_SYMBOL(gtk_progress_bar_get_type);
  DEFINE_SYMBOL(gtk_scrollbar_get_type);
  DEFINE_SYMBOL(gtk_notebook_get_type);
  DEFINE_SYMBOL(gtk_paned_get_type);
  DEFINE_SYMBOL(gtk_frame_get_type);
  DEFINE_SYMBOL(gtk_tree_view_get_type);
  DEFINE_SYMBOL(gtk_arrow_get_type);
} TtkGtk_SymbolTable;

#undef DEFINE_SYMBOL

#define TtkGtk_cairo_xlib_surface_create		TtkGtk_symbols.p_cairo_xlib_surface_create
#define TtkGtk_cairo_create				TtkGtk_symbols.p_cairo_create
#define TtkGtk_cairo_surface_destroy			TtkGtk_symbols.p_cairo_surface_destroy
#define TtkGtk_cairo_destroy				TtkGtk_symbols.p_cairo_destroy

#define TtkGtk_gtk_init					TtkGtk_symbols.p_gtk_init

#define TtkGtk_gtk_style_context_new			TtkGtk_symbols.p_gtk_style_context_new
#define TtkGtk_gtk_style_context_get_border		TtkGtk_symbols.p_gtk_style_context_get_border
#define TtkGtk_gtk_style_context_get_background_color	TtkGtk_symbols.p_gtk_style_context_get_background_color
#define TtkGtk_gtk_style_context_get_color		TtkGtk_symbols.p_gtk_style_context_get_color
#define TtkGtk_gtk_style_context_get_style		TtkGtk_symbols.p_gtk_style_context_get_style
#define TtkGtk_gtk_style_context_get_style_property	TtkGtk_symbols.p_gtk_style_context_get_style_property
#define TtkGtk_gtk_style_context_get_padding		TtkGtk_symbols.p_gtk_style_context_get_padding
#define TtkGtk_gtk_style_context_get_path		TtkGtk_symbols.p_gtk_style_context_get_path
#define TtkGtk_gtk_style_context_set_junction_sides	TtkGtk_symbols.p_gtk_style_context_set_junction_sides
#define TtkGtk_gtk_style_context_set_path		TtkGtk_symbols.p_gtk_style_context_set_path
#define TtkGtk_gtk_style_context_set_screen		TtkGtk_symbols.p_gtk_style_context_set_screen
#define TtkGtk_gtk_style_context_set_state		TtkGtk_symbols.p_gtk_style_context_set_state
#define TtkGtk_gtk_style_context_add_class		TtkGtk_symbols.p_gtk_style_context_add_class
#define TtkGtk_gtk_style_context_add_region		TtkGtk_symbols.p_gtk_style_context_add_region
#define TtkGtk_gtk_style_context_remove_class		TtkGtk_symbols.p_gtk_style_context_remove_class
#define TtkGtk_gtk_style_context_save			TtkGtk_symbols.p_gtk_style_context_save
#define TtkGtk_gtk_style_context_restore		TtkGtk_symbols.p_gtk_style_context_restore

#define TtkGtk_gtk_widget_path_new			TtkGtk_symbols.p_gtk_widget_path_new
#define TtkGtk_gtk_widget_path_append_type		TtkGtk_symbols.p_gtk_widget_path_append_type
#define TtkGtk_gtk_widget_path_append_with_siblings	TtkGtk_symbols.p_gtk_widget_path_append_with_siblings
#define TtkGtk_gtk_widget_path_iter_add_class		TtkGtk_symbols.p_gtk_widget_path_iter_add_class
#define TtkGtk_gtk_widget_path_get_object_type		TtkGtk_symbols.p_gtk_widget_path_get_object_type
#define TtkGtk_gtk_widget_path_to_string		TtkGtk_symbols.p_gtk_widget_path_to_string
#define TtkGtk_gtk_widget_path_ref			TtkGtk_symbols.p_gtk_widget_path_ref
#define TtkGtk_gtk_widget_path_free			TtkGtk_symbols.p_gtk_widget_path_free

#define TtkGtk_gtk_icon_theme_get_default		TtkGtk_symbols.p_gtk_icon_theme_get_default
#define TtkGtk_gtk_icon_theme_lookup_icon		TtkGtk_symbols.p_gtk_icon_theme_lookup_icon
#define TtkGtk_gtk_icon_info_free			TtkGtk_symbols.p_gtk_icon_info_free
#define TtkGtk_gtk_icon_info_get_filename		TtkGtk_symbols.p_gtk_icon_info_get_filename
#define TtkGtk_gtk_icon_info_load_symbolic_for_context	TtkGtk_symbols.p_gtk_icon_info_load_symbolic_for_context
#define TtkGtk_gtk_icon_size_lookup_for_settings	TtkGtk_symbols.p_gtk_icon_size_lookup_for_settings

#define TtkGtk_gtk_settings_get_default			TtkGtk_symbols.p_gtk_settings_get_default

#define TtkGtk_g_object_new				TtkGtk_symbols.p_g_object_new
#define TtkGtk_g_object_get_property			TtkGtk_symbols.p_g_object_get_property
#define TtkGtk_g_object_set_property			TtkGtk_symbols.p_g_object_set_property
#define TtkGtk_g_object_unref				TtkGtk_symbols.p_g_object_unref

#define TtkGtk_g_value_init				TtkGtk_symbols.p_g_value_init
#define TtkGtk_g_value_get_string			TtkGtk_symbols.p_g_value_get_string
#define TtkGtk_g_value_unset				TtkGtk_symbols.p_g_value_unset

#define TtkGtk_gdk_screen_get_default			TtkGtk_symbols.p_gdk_screen_get_default

#define TtkGtk_gtk_border_free				TtkGtk_symbols.p_gtk_border_free

#define TtkGtk_gtk_render_background			TtkGtk_symbols.p_gtk_render_background
#define TtkGtk_gtk_render_arrow				TtkGtk_symbols.p_gtk_render_arrow
#define TtkGtk_gtk_render_check				TtkGtk_symbols.p_gtk_render_check
#define TtkGtk_gtk_render_expander			TtkGtk_symbols.p_gtk_render_expander
#define TtkGtk_gtk_render_focus				TtkGtk_symbols.p_gtk_render_focus
#define TtkGtk_gtk_render_frame				TtkGtk_symbols.p_gtk_render_frame
#define TtkGtk_gtk_render_handle			TtkGtk_symbols.p_gtk_render_handle
#define TtkGtk_gtk_render_line				TtkGtk_symbols.p_gtk_render_line
#define TtkGtk_gtk_render_option			TtkGtk_symbols.p_gtk_render_option
#define TtkGtk_gtk_render_activity			TtkGtk_symbols.p_gtk_render_activity
#define TtkGtk_gtk_render_extension			TtkGtk_symbols.p_gtk_render_extension
#define TtkGtk_gtk_render_frame_gap			TtkGtk_symbols.p_gtk_render_frame_gap
#define TtkGtk_gtk_render_layout			TtkGtk_symbols.p_gtk_render_layout
#define TtkGtk_gtk_render_slider			TtkGtk_symbols.p_gtk_render_slider
#define TtkGtk_gtk_render_icon_pixbuf			TtkGtk_symbols.p_gtk_render_icon_pixbuf
#define TtkGtk_gtk_render_icon				TtkGtk_symbols.p_gtk_render_icon
#define TtkGtk_gtk_render_insertion_cursor		TtkGtk_symbols.p_gtk_render_insertion_cursor

#define TtkGtk_gtk_window_get_type			TtkGtk_symbols.p_gtk_window_get_type
#define TtkGtk_gtk_button_get_type			TtkGtk_symbols.p_gtk_button_get_type
#define TtkGtk_gtk_check_button_get_type		TtkGtk_symbols.p_gtk_check_button_get_type
#define TtkGtk_gtk_toggle_button_get_type		TtkGtk_symbols.p_gtk_toggle_button_get_type
#define TtkGtk_gtk_radio_button_get_type		TtkGtk_symbols.p_gtk_radio_button_get_type
#define TtkGtk_gtk_spin_button_get_type			TtkGtk_symbols.p_gtk_spin_button_get_type
#define TtkGtk_gtk_entry_get_type			TtkGtk_symbols.p_gtk_entry_get_type
#define TtkGtk_gtk_combo_box_get_type			TtkGtk_symbols.p_gtk_combo_box_get_type
#define TtkGtk_gtk_scale_get_type			TtkGtk_symbols.p_gtk_scale_get_type
#define TtkGtk_gtk_progress_bar_get_type		TtkGtk_symbols.p_gtk_progress_bar_get_type
#define TtkGtk_gtk_scrollbar_get_type			TtkGtk_symbols.p_gtk_scrollbar_get_type
#define TtkGtk_gtk_notebook_get_type			TtkGtk_symbols.p_gtk_notebook_get_type
#define TtkGtk_gtk_paned_get_type			TtkGtk_symbols.p_gtk_paned_get_type
#define TtkGtk_gtk_frame_get_type			TtkGtk_symbols.p_gtk_frame_get_type
#define TtkGtk_gtk_tree_view_get_type			TtkGtk_symbols.p_gtk_tree_view_get_type
#define TtkGtk_gtk_arrow_get_type			TtkGtk_symbols.p_gtk_arrow_get_type
#endif

#endif /* _TTKGTK_SYMBOLS_H */
