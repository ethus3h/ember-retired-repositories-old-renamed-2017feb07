/*
 * ttkgtk.h 
 * -------------------
 *
 * This file is part of the TtkGtk package, a Ttk based theme that uses
 * Gtk/GNOME for drawing.
 *
 * Copyright (C) 2012 by:
 * Georgios Petasis, petasis@iit.demokritos.gr, petasisg@yahoo.gr
 * Software and Knowledge Engineering Laboratory,
 * Institute of Informatics and Telecommunications,
 * National Centre for Scientific Research (NCSR) "Demokritos",
 * Aghia Paraskevi, 153 10, Athens, Greece.
 *
 */

#ifndef _TTKGTK_H
#define _TTKGTK_H

#include <tcl.h>
#include <tk.h>

#include <gtk/gtk.h>

#include <cairo.h>
#ifdef CAIRO_HAS_XLIB_SURFACE
#include <cairo-xlib.h>
#endif

#include "ttkTheme.h"

#define PRINT_TTK_STATE(state) {\
if (state & TTK_STATE_ACTIVE)     printf("TTK_STATE_ACTIVE %d ", TTK_STATE_ACTIVE);\
if (state & TTK_STATE_DISABLED)   printf("TTK_STATE_DISABLED %d ", TTK_STATE_DISABLED);\
if (state & TTK_STATE_FOCUS)      printf("TTK_STATE_FOCUS %d ", TTK_STATE_FOCUS);\
if (state & TTK_STATE_PRESSED)    printf("TTK_STATE_PRESSED %d ", TTK_STATE_PRESSED);\
if (state & TTK_STATE_SELECTED)   printf("TTK_STATE_SELECTED %d ", TTK_STATE_SELECTED);\
if (state & TTK_STATE_BACKGROUND) printf("TTK_STATE_BACKGROUND %d ", TTK_STATE_BACKGROUND);\
if (state & TTK_STATE_ALTERNATE)  printf("TTK_STATE_ALTERNATE %d ", TTK_STATE_ALTERNATE);\
if (state & TTK_STATE_INVALID)    printf("TTK_STATE_INVALID %d ", TTK_STATE_INVALID);\
if (state & TTK_STATE_READONLY)   printf("TTK_STATE_READONLY %d ", TTK_STATE_READONLY);\
if (state & TTK_STATE_USER1)      printf("TTK_STATE_USER1 %d ", TTK_STATE_USER1);\
if (state & TTK_STATE_USER2)      printf("TTK_STATE_USER2 %d ", TTK_STATE_USER2);\
if (state & TTK_STATE_USER3)      printf("TTK_STATE_USER3 %d ", TTK_STATE_USER3);\
if (state & TTK_STATE_USER4)      printf("TTK_STATE_USER4 %d ", TTK_STATE_USER4);\
if (state & TTK_STATE_USER5)      printf("TTK_STATE_USER5 %d ", TTK_STATE_USER5);\
if (state & TTK_STATE_USER6)      printf("TTK_STATE_USER6 %d ", TTK_STATE_USER6);\
}

#define PRINT_GTK_STATE(state) {\
if (state & GTK_STATE_FLAG_NORMAL)       printf("GTK_STATE_FLAG_NORMAL %d ", GTK_STATE_FLAG_NORMAL);\
if (state & GTK_STATE_FLAG_ACTIVE)       printf("GTK_STATE_FLAG_ACTIVE %d ", GTK_STATE_FLAG_ACTIVE);\
if (state & GTK_STATE_FLAG_PRELIGHT)     printf("GTK_STATE_FLAG_PRELIGHT %d ", GTK_STATE_FLAG_PRELIGHT);\
if (state & GTK_STATE_FLAG_SELECTED)     printf("GTK_STATE_FLAG_SELECTED %d ", GTK_STATE_FLAG_SELECTED);\
if (state & GTK_STATE_FLAG_INSENSITIVE)  printf("GTK_STATE_FLAG_INSENSITIVE %d ", GTK_STATE_FLAG_INSENSITIVE);\
if (state & GTK_STATE_FLAG_INCONSISTENT) printf("GTK_STATE_FLAG_INCONSISTENT %d ", GTK_STATE_FLAG_INCONSISTENT);\
if (state & GTK_STATE_FLAG_FOCUSED)      printf("GTK_STATE_FLAG_FOCUSED %d ", GTK_STATE_FLAG_FOCUSED);\
if (state & GTK_STATE_FLAG_BACKDROP)     printf("GTK_STATE_FLAG_BACKDROP %d ", GTK_STATE_FLAG_BACKDROP);\
}

#endif /* _TTKGTK_H */
