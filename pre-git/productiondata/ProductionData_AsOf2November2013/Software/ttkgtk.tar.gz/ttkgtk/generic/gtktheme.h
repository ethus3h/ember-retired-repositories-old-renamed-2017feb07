/*
 * gtktheme.h 
 * -------------------
 *
 * This file is part of the TtkGtk package, a Ttk based theme that uses
 * Gtk/GNOME for drawing.
 *
 * Copyright (C) 2012 by:
 * Georgios Petasis, petasis@iit.demokritos.gr, petasisg@yahoo.gr
 * Software and Knowledge Engineering Laboratory,
 * Institute of Informatics and Telecommunications,
 * National Centre for Scientific Research (NCSR) "Demokritos",
 * Aghia Paraskevi, 153 10, Athens, Greece.
 *
 */

#ifndef _TTKGTK_GTK_THEME_H
#define _TTKGTK_GTK_THEME_H

/*
 * The following enumeration must be kept in sync with
 * TtkGtk_classNames, in gtktheme.c
 */
enum TtkGtk_ClassNames {
    CN_CLASS_BACKGROUND,        CN_CLASS_BUTTON, 
    CN_CLASS_CALENDAR,          CN_CLASS_CELL, 
    CN_CLASS_COMBOBOX_ENTRY,    CN_CLASS_CHECK, 
    CN_CLASS_DEFAULT,           CN_CLASS_ENTRY, 
    CN_CLASS_HEADER,            CN_CLASS_MENU, 
    CN_CLASS_RADIO,             CN_CLASS_RUBBERBAND, 
    CN_CLASS_SCROLLBAR,         CN_CLASS_SCROLLBARS_JUNCTION, 
    CN_CLASS_SLIDER,            CN_CLASS_TOOLTIP, 
    CN_CLASS_TROUGH,            CN_CLASS_ACCELERATOR, 
    CN_CLASS_DOCK,              CN_CLASS_GRIP, 
    CN_CLASS_MENUBAR,           CN_CLASS_MENUITEM, 
    CN_CLASS_PROGRESSBAR,       CN_CLASS_SPINNER, 
    CN_CLASS_TOOLBAR,           CN_CLASS_PRIMARY_TOOLBAR, 
    CN_CLASS_INLINE_TOOLBAR,    CN_CLASS_PANE_SEPARATOR, 
    CN_CLASS_SEPARATOR,         CN_CLASS_SIDEBAR, 
    CN_CLASS_DND,               CN_CLASS_ERROR, 
    CN_CLASS_EXPANDER,          CN_CLASS_FRAME, 
    CN_CLASS_HIGHLIGHT,         CN_CLASS_IMAGE, 
    CN_CLASS_INFO,              CN_CLASS_MARK, 
    CN_CLASS_NOTEBOOK,          CN_CLASS_QUESTION, 
    CN_CLASS_SCALE,             CN_CLASS_SCALE_HAS_MARKS_ABOVE, 
    CN_CLASS_SCALE_HAS_MARKS_BELOW,   CN_CLASS_SPINBUTTON, 
    CN_CLASS_VIEW,              CN_CLASS_WARNING, 
    CN_CLASS_HORIZONTAL,        CN_CLASS_VERTICAL, 
    CN_CLASS_TOP,               CN_CLASS_BOTTOM, 
    CN_CLASS_LEFT,              CN_CLASS_RIGHT, 
    CN_CLASS_LINKED,            CN_CLASS_ARROW, 
    CN_REGION_COLUMN,           CN_REGION_COLUMN_HEADER, 
    CN_REGION_ROW,              CN_REGION_TAB,
    CN_NUMBER_OF_CLASSES
};

/*
 * The following enumeration must be kept in sync with
 * TtkGtk_partNames, in gtktheme.c
 */
enum TtkGtk_PartNames {
   PN_ARROW,
   PN_BACKGROUND,
   PN_CHECK,
   PN_EXPANDER,
   PN_EXTENSION,
   PN_FOCUS,
   PN_FRAME,
   PN_FRAME_GAP,
   PN_HANDLE,
   PN_LAYOUT,
   PN_LINE,
   PN_OPTION,
   PN_SLIDER,
   PN_ACTIVITY,
   PN_ICON_PIXBUF,
   PN_ICON,
   PN_INSERTION_CURSOR,
   PN_BACKGROUND_FRAME,
   PN_BUTTON,
   PN_BUTTON_ARROW,
   PN_SEPARATOR,
   PN_HEADER_ROW,
   PN_ROW,
   PN_NUMBER_OF_PARTS
};

typedef struct {
  GtkStyleContext *context;
  GtkStyleContext *class_context[CN_NUMBER_OF_CLASSES];
} GtkThemeData;

typedef struct { /* Gtk element specifications */
  const char      *elementName;	/* Tk theme engine element name */
  Ttk_ElementSpec *elementSpec;	/* Element spec (usually GenericElementSpec) */
  char		  *className;	/* Windows window class name */
  unsigned int     classNameIndex;
  int 		   partId;	/* BP_PUSHBUTTON, BP_CHECKBUTTON, etc. */
  Ttk_StateTable  *statemap;	/* Map Tk states to XP states */
  Ttk_Padding	   padding;	/* See NOTE-GetThemeMargins */
  int  	           flags;
#define    IGNORE_THEMESIZE	0x80000000 /* See NOTE-GetThemePartSize */
#define    PAD_MARGINS		0x40000000 /* See NOTE-GetThemeMargins */
#define    HEAP_ELEMENT		0x20000000 /* ElementInfo is on heap */
#define    HALF_HEIGHT		0x10000000 /* Used by GenericSizedElements */
#define    HALF_WIDTH		0x08000000 /* Used by GenericSizedElements */
  char		  *iconName;    /* Used by icons */
  int              size;        /* Used by icons */
  int              orientation; /* GTK_ORIENTATION_HORIZONTAL/VERTICAL */
} ElementInfo;

typedef struct {
  ElementInfo	*info;
  GtkThemeData  *themeData;
} ElementData;

typedef GType (*ptr_class_get_type) (void);

#define TTK_STATE_NOTEBOOK_FIRST	TTK_STATE_USER1
#define TTK_STATE_NOTEBOOK_LAST		TTK_STATE_USER2
#define TTK_STATE_OPEN			TTK_STATE_USER1
#define TTK_STATE_LEAF			TTK_STATE_USER2

#endif /* _TTKGTK_GTK_THEME_H */
