using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyVersion("2.4.0")]

