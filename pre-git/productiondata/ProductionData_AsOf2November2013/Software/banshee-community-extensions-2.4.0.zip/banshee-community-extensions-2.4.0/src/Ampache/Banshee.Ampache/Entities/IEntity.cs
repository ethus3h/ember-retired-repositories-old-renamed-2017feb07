
using System;
using System.Collections.Generic;
namespace Banshee.Ampache
{
    public interface IEntity
    {
        int Id { get; set; }
    }
}
