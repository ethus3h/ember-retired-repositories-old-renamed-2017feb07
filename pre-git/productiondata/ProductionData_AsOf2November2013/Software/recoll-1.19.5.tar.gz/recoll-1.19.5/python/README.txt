How to build and use the python interface is documented in the Recoll 
user manual, inside the "Programming interface" chapter.
