#!/bin/sh
rm -rf CMakeCache.txt CMakeFiles CTestTestfile.cmake \
    cmake_install.cmake CMakeTmp cmake_uninstall.cmake \
    CPackConfig.cmake CPackSourceConfig.cmake DartTestfile.txt \
    install_manifest.txt kio_recoll_automoc.cpp \
    kio_recoll_automoc.cpp.files kio_recoll.so lib Makefile
