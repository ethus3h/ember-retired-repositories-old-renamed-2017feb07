tile-gtk
========

This is my fork of tile-gtk, a [ttk](http://wiki.tcl.tk/14796) theme that
gives your [Tk](http://wiki.tcl.tk/477) application native
[GTK+](http://www.gtk.org/) look and feel.

Since [according to the author][1] tilegtk as well as tileqt is
undermaintained, I created this fork on Github to integrate my bugfixes and
possible improvements.

You may want to visit the [original project][2] site.

[1]: http://www.tclcommunityassociation.org/wub/proceedings/Proceedings-2010/GeorgePetasis/TileQtAndTileGTK.pdf

[2]: http://www.ellogon.org/petasis/tcltk-projects/tilegtk
