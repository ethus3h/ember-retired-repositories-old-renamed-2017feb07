
#include <assert.h>   
#include <X11/Xutil.h>
#include <X11/keysym.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <locale.h>
#include <X11/Xlib.h>
#include <X11/Xatom.h>
#include <X11/cursorfont.h>
#include <X11/Xmu/WinUtil.h>
#include <glib.h>
#include <X11/extensions/XTest.h>
#include <X11/Xmu/Error.h>
#define MAX_PROPERTY_VALUE_LEN 4096
#define HELP "ctrlwm \n" \
"App for automatic positioning and resizing of 1-9 windows\n" \
"\n" \
"Usage: ctrlwm [Action]...\n" \
"\n" \
"Actions:\n" \
"Window Actions:\n" \
"  -gui           Start gui\n" \
"  -t  [Options]  Tile windows with active as main/biggest window	 \n" \
"  -v  [Options]  Tile windows in vertical stripes	 \n" \
"  -h  [Options]  Tile windows in horizontal stripes	 \n" \
"  -m  [Options]  Maximize active		\n" \
"  -n             Next window (like alt+esc, without bugs/features)\n" \
"  -s  [-o]       Place active Window moving it to the screen borders	\n"\
"  -z  [-o]       Place active with placement/size depending on mouse position \n"\
"      [-b]       Add moving windows to another workspace (bottom of screen)\n" \
"      [-u]       Show sectors on screen	\n" \
"\n" \
"Desktop Actions:\n" \
"  -e             Go on empty workspace.If none available, create one		\n" \
"  -d             Delete last workspace		\n" \
"\n" \
"Daemon Mode Actions:\n" \
"  -snap [-o]     Some sort of snap like Windows \n" \
"  -k             Daemon Mode screen corner/border actions --> out of order atm\n" \
"\n" \
"Other:\n" \
"  -rc            Read .rc file\n" \
"  -i             Print some info	\n" \
"\n" \
"Options:\n" \
"  -p             Tile windows in order opened	\n" \
"  -a             Use alternative layout for tiling \n" \
"  -w             Include minimized windows when tiling	\n" \
"  -j             Include maximized windows when tiling	\n" \
"  -o             Offset top/bottom/left/right   (-o XX XX XX XX)\n"\
"  -f             Auto offset 1-3  (-f X)\n" \
"  -c             Exclude selected window from tiling	\n"\
"  -mn            Window decoration offset  (-mn XX XX)\n" \
"\n" \
"\n" \
"Hints:\n" \
"If Windows overlap with tiling, you have to try out different values for -mn\n" \
"Default is -mn 12 29\n" \
"Use the software with key shortcuts, mouse strokes or panel starters\n" \
"\n" \
"\n" \
"Author, current maintainer: zlatko kartelo\n" \
"Some code taken from wmctrl \n" \
"Released under the GNU General Public License.\n" \
"Copyright (C) 2009-2012\n"
//~ Window wcount;
char *version="0.8.9";
int i;
float win_pm [9][4];

int winondesk=1;
int winl [20]={0}; 

int nmbrdesks;
int activedesk;
int dskrw, dskrh;
int dskww, dskwh;
float dskcw, dskch;
int deskZx, deskZy;

int dcw=12; /*decoration width*/
int dch=29; /*decoration height*/
int offset_auto=0;
int tilewindowsoorder=0;
int screen_sec=0;
int tile_min_win=0;
int min_o_max=0;
int win_move_desk=0;
int win_exclude=0;

unsigned int offset_top=0,offset_bottom=0,offset_left=0,offset_right=0;
int WIN_HEIGHT, WIN_WIDTH;
int BUTHEIGHT=40;
int BUTWIDTH,BUTTON1_X,BUTTON1_Y,BUTTON2_X,BUTTON2_Y,BUTTON3_X,BUTTON3_Y,BUTTON4_X,BUTTON4_Y,
BUTTON5_X,BUTTON5_Y,BUTTON6_X,BUTTON6_Y,BUTTON7_X,BUTTON7_Y,BUTTON8_X,BUTTON8_Y,BUTTON9_X,BUTTON9_Y;
unsigned char stillused; 
unsigned char toberefreshed;
unsigned char cpslock;
int mousex;
int mousey;
unsigned char clicked;
unsigned char rightclicked;
unsigned char typedchar;
int screen_num;
Window win;
XFontStruct *font_info;
GC black_gc, color_gc, text_gc;
XGCValues gc_values;
unsigned long gc_valuemask = 0;
XColor color_info;
unsigned int color_table[256];
unsigned short color_data[256][3];
char *window_name = "ctrlwm";
XTextProperty wname;
char *font_name = "10x20";
XEvent event;
KeySym keysym;

void Menu_gui ();
int  Graphics_init (Display *disp, unsigned int, unsigned int );
void Graphics_refresh (Display *disp);
void Graphics_shutdown (Display *disp);
unsigned char Graphics_get_xchar (Display *disp);

void Prepare_values (int place_win,int tile_stripes,int alternative_layout, int win_max);

void Tile (Display *disp, int oh, int ow);
void Place_window (Display *disp, int oh, int ow, int place_window);	
void Print_screen_sections (Display *disp);

void Stripe_wins(Display *disp, int oh, int ow, int tile_stripes);

void Get_info_desk (Display *disp);
void Get_info_win_desk (Display *disp);
static Window Get_active_window(Display *disp);

void Sort_list (int active_win);
void Sort_list_xchg (int sel_win, int last_win);
void Max_remove (Display *disp);
void Min_remove (Display *disp);
void Win_raise (Display *disp);
void Print_info ();
void Empty_desk ();
void Del_desk ();
static int Client_msg(Display *disp, Window win, char *msg, 
           unsigned long data0, unsigned long data1,unsigned long data2,
		   unsigned long data3, unsigned long data4);
static gchar *Get_property (Display *disp, Window win, 
              Atom xa_prop_type, gchar *prop_name, unsigned long *size);
static Window *Get_client_list (Display *disp, unsigned long *size);
static Window Select_Window(Display *disp);
void Mouse_daemon ();
void Next_win ();
void Read_rc ();
void Get_win_layout (int alternative_layout);
void LinSnap ();
