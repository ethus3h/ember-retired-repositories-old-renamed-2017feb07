#include "ctrlwm.h"

int main (int argc, char *argv[])
{
	int alternative_layout=0;

	//~XSetErrorHandler(XmuSimpleErrorHandler);
	//~ Read_rc ();

	/*+++++++++++++++++++++++++++options++++++++++++++++++++++++++++++*/
	for (i = 1; i < argc; i++)  
		{
		 if (strcmp(argv[i], "--help") == 0) {fputs(HELP, stdout);return 1;}
		 if (strcmp(argv[i], "-c") == 0) {win_exclude=1;} 	
		 if (strcmp(argv[i], "-p") == 0) {tilewindowsoorder=1;}
		 if (strcmp(argv[i], "-w") == 0) {tile_min_win=1;}
		 if (strcmp(argv[i], "-u") == 0) {screen_sec=1;}
		 if (strcmp(argv[i], "-b") == 0) {win_move_desk=1;}
		 if (strcmp(argv[i], "-j") == 0) {min_o_max=1;}
		 if (strcmp(argv[i], "-o") == 0) 
			{
			 if (i + 4 <= argc - 1) 
				{
				 i++;offset_top=atoi(argv[i]);i++;offset_bottom=atoi(argv[i]); 
				 i++;offset_left=atoi(argv[i]);i++;offset_right=atoi(argv[i]); 
				}
			}
		 if (strcmp(argv[i], "-a") == 0)
			{if (i + 1 <= argc - 1){i++;alternative_layout = atoi(argv[i]);}}
		 if (strcmp(argv[i], "-f") == 0) 
			{if (i + 1 <= argc - 1){i++;offset_auto = atoi(argv[i]);}}
		 if (strcmp(argv[i], "-mn") == 0) 
			{if (i+2<=argc-1){i++;dcw=atoi(argv[i]);i++; dch = atoi(argv[i]);}}
		}
	
	for (i = 1; i < argc; i++)  
		{
		 if (strcmp(argv[i], "-rc") == 0) {Read_rc ();}
		}
	
	/*+++++++++++++++++++++++++++actions++++++++++++++++++++++++++++++*/
	for (i = 1; i < argc; i++)  
		{
		 if (strcmp(argv[i], "-snap") == 0) {LinSnap ();return 0;}
		 if (strcmp(argv[i], "-gui") == 0) {Menu_gui ();return 0;}
		 if (strcmp(argv[i], "-t") == 0) {Prepare_values (0,0,alternative_layout,0);return 0;}
		 if (strcmp(argv[i], "-m") == 0) {Prepare_values (0,0,0,1);return 0;}
		 if (strcmp(argv[i], "-h") == 0) {Prepare_values (0,1,0,0);return 0;} 	
		 if (strcmp(argv[i], "-v") == 0) {Prepare_values (0,2,0,0);return 0;} 	
		 if (strcmp(argv[i], "-s") == 0) {Prepare_values (1,0,0,0);return 0;} 	
		 if (strcmp(argv[i], "-z") == 0) {Prepare_values (2,0,0,0);return 0;} 	
		 if (strcmp(argv[i], "-e") == 0) {Empty_desk();return 0;}
		 if (strcmp(argv[i], "-d") == 0) {Del_desk();return 0;}
		 if (strcmp(argv[i], "-n") == 0) {Next_win ();return 0;} 
		 if (strcmp(argv[i], "-i") == 0) {Print_info ();return 0;}
		 //if (strcmp(argv[i], "-k") == 0) {Mouse_daemon ();return 0;}
		}
	
	fputs(HELP, stdout);
	return 1;
}

void Read_rc ()
{
	FILE *fp=fopen(".ctrlwm.rc","r");
	char var [512],value[512],line[512];
	
	if (fp) 
		{
		 while (fgets(line,sizeof(line),fp))
			{
			 memset (var,0,sizeof(var));
			 memset (value,0,sizeof(value));
			 sscanf(line,"%[^'=']=%[^\' '\n]%*[\t]%*[\t]",var,value);
			 if (strcmp (var, "dcw")==0){dcw=atoi (value);}
			 if (strcmp (var, "dch")==0){dch=atoi (value);}
			 if (strcmp (var, "tilewindowsoorder")==0){tilewindowsoorder=atoi (value);}
			 if (strcmp (var, "tile_min_win")==0){tile_min_win=atoi (value);}
			 if (strcmp (var, "tile_max_win")==0){min_o_max=atoi (value);}
			 if (strcmp (var, "offset_top")==0){offset_top=atoi (value);}
			 if (strcmp (var, "offset_bottom")==0){offset_bottom=atoi (value);}
			 if (strcmp (var, "offset_left")==0){offset_left=atoi (value);}
			 if (strcmp (var, "offset_right")==0){offset_right=atoi (value);}
			 if (strcmp (var, "gui_button_height")==0){BUTHEIGHT=atoi (value);}
			}
	 fclose (fp);
	 return ;
	}

	return ;
}

void Tile (Display *disp, int oh, int ow)
{
	for (i =1; i < winondesk+1; i++) 
	   {XMoveResizeWindow(disp,winl[i],(dskcw*win_pm [i-1][0])+ow,
	                    (dskch*win_pm [i-1][1])+oh, (win_pm [i-1][2]*dskcw)-dcw,
	                          (win_pm [i-1][3]*dskch)-dch);
	   }
	
	return;
}

void Mouse_daemon ()
{
	FILE *fp=fopen(".ctrlwm.rc","r");
	char var [512],value[512],line[512];
	char cornerNW [512];
	char cornerSW [512];
	char cornerNE [512];
	char cornerSE [512];
	char borderN [512];
	char borderS [512];
	char borderW [512];
	char borderE [512];
	
	if (fp) 
		{
		 while (fgets(line,sizeof(line),fp))
			{
			 memset (var,0,sizeof(var));
			 memset (value,0,sizeof(value));
			 
			 sscanf(line,"%[^'=']=%[^\'#'\n]%*[\t]%*[\t]",var,value);  
			 if (strcmp (var, "cornerNW")==0){for( i=0;i<100;i++){cornerNW[i]=value[i];}}
			 if (strcmp (var, "cornerSW")==0){for( i=0;i<512;i++){cornerSW[i]=value[i];}}
			 if (strcmp (var, "cornerNE")==0){for( i=0;i<512;i++){cornerNE[i]=value[i];}}
			 if (strcmp (var, "cornerSE")==0){for( i=0;i<512;i++){cornerSE[i]=value[i];}}
			 if (strcmp (var, "borderN")==0){for( i=0;i<512;i++){borderN[i]=value[i];}}
			 if (strcmp (var, "borderS")==0){for( i=0;i<512;i++){borderS[i]=value[i];}}
			 if (strcmp (var, "borderW")==0){for( i=0;i<512;i++){borderW[i]=value[i];}}
			 if (strcmp (var, "borderE")==0){for( i=0;i<512;i++){borderE[i]=value[i];}}
			}
		 fclose (fp);
		}

	Display *disp = XOpenDisplay(NULL);
	Window root = XDefaultRootWindow(disp);
	Window ret_root;
	Window ret_child;
	int ret_val=0;
	int root_x=10;
	int root_y=10;
	int win_x;
	int win_y;
	unsigned int mask;
while (1)
	{
	ret_val=0;
	root_x=10;
	root_y=10;
	win_x=0;
	win_y=0;
	mask=0;
		
		while ((root_x>6) & (root_y>6)& (root_x<(dskcw-6)) & (root_y<(dskch-6)) )
		{
		 if(XQueryPointer(disp, root, &ret_root, &ret_child, &root_x, &root_y,
							&win_x, &win_y, &mask))
			{usleep (20000);}
		}
	
	/*corners*/
	if ((root_x<(6)) & (root_y<(6))) 
		{ret_val=system (cornerNW);}	
	if ((root_x>(dskrw-6)) & (root_y<(6))) 
		{ret_val=system (cornerNE);}
	if ((root_x<(6)) & (root_y>(dskrh-6))) 
		{ret_val=system (cornerSW);}
	if ((root_x>(dskrw-6)) & (root_y>(dskrh-6))) 
		{ret_val=system (cornerSE);}
	
	/*borders*/
	if ((root_x>((dskrw/8))) & (root_x<(dskrw-(dskrw/8))) & (root_y<(6))) 
		{ret_val=system (borderN);}
	if ((root_x>((dskrw/8))) & (root_x<(dskrw-(dskrw/8))) & (root_y>(dskrh-6))) 
		{ret_val=system (borderS);}
	if ((root_x<(6)) & (root_y>((dskrh/8))) & (root_y<(dskrh-(dskrh/8)))) 
		{ret_val=system (borderW);}
	if ((root_x>(dskrw-6)) & (root_y>((dskrh/8))) & (root_y<(dskrh-(dskrh/8)))) 
		{ret_val=system (borderE);}
	}
	XCloseDisplay(disp);
	
	
}

void Prepare_values (int place_win,int tile_stripes,int alternative_layout, int win_max)
{
	int ow=deskZx+0;
	int oh=deskZy+0;
	
	Display *disp = XOpenDisplay(NULL);
	
	Get_info_desk (disp);
	Get_info_win_desk (disp);
	int active_win = Get_active_window(disp);	 
	if (winondesk==0) {return;}
	
	if (!tilewindowsoorder){Sort_list(active_win);}
	if (win_exclude)
		{
		 int sel_win=Select_Window(disp);
		 int last_win=winl[winondesk];
		 Sort_list_xchg(sel_win,last_win);
		 winondesk=winondesk-1;
		 }
	if (win_max) {winondesk=1;}
	if (min_o_max) {Max_remove (disp);}
	if (tile_min_win) {Win_raise (disp);Min_remove (disp);}
	
	dskwh=dskch;
	dskww=dskcw;
	dskch=dskch-offset_bottom;oh=deskZy+offset_top;dskch=dskch-offset_top;
	dskcw=dskcw-offset_right;ow=deskZx+offset_left;dskcw=dskcw-offset_left;	
	
	switch (offset_auto)
		{
		 case 0:
		 break;
		 case 1: 
		 ow=deskZx+dskcw/4;oh=deskZy+dskch/4;dskcw=dskcw/4*3;dskch=dskch/4*3;break;
		 case 2:
		 ow=deskZx+dskcw/3;oh=deskZy+dskch/3;dskcw=dskcw/3*2;dskch=dskch/3*2;break;
		 case 3:
		 ow=deskZx+dskcw/2;oh=deskZy+dskch/2;dskcw=dskcw/2;dskch=dskch/2;break;
		}
	
	if (tile_stripes) 
		{
		 Stripe_wins (disp, oh, ow, tile_stripes);
		 XCloseDisplay (disp);
		 return;
		}
	
	if (place_win) 
		{
		 Place_window (disp, oh, ow, place_win);
		 XCloseDisplay (disp);
		 return;
		}
	
	Get_win_layout (alternative_layout);
	Tile (disp, oh, ow);    
	
	XCloseDisplay (disp);
		 
	return;
}

void Place_window (Display *disp, int oh, int ow, int place_win)
{
	int root_x=10;
	int root_y=10;
	int win_x;
	int win_y;
	int active_win = Get_active_window(disp);	 
	
	Window root = XDefaultRootWindow(disp);
	Window ret_root;
	Window ret_child;
	unsigned int mask;
	int status;
	
	Client_msg(disp, active_win, "_NET_ACTIVE_WINDOW",0,0,0,0,0);
	Client_msg(disp, active_win, "_NET_WM_STATE", 
			   XInternAtom(disp,"_NET_WM_STATE_REMOVE",False) , 
			    XInternAtom(disp,"_NET_WM_STATE_MAXIMIZED_VERT",False),
			     XInternAtom(disp,"_NET_WM_STATE_MAXIMIZED_HORZ",False),0,0);
	
	/*pointer feedback*/
	Cursor cursor = XCreateFontCursor(disp, XC_crosshair);
	status = XGrabPointer(disp, root, False,ButtonPressMask|ButtonReleaseMask,
                      GrabModeSync,GrabModeAsync, root, cursor, CurrentTime);
	
	if (status != GrabSuccess) 
		{
		 fputs("ERROR: Cannot grab mouse.\n", stderr);
		 return ;
		}
	XAllowEvents(disp, SyncPointer, CurrentTime);
	
	if (place_win==1)
		{
		 while ((root_x>3) & (root_y>3)& (root_x<(dskrw-3)) & (root_y<(dskrh-3)) )
			{
			 if(XQueryPointer(disp, root, &ret_root, &ret_child, &root_x, &root_y,
			  &win_x, &win_y, &mask))
				{
				 if (mask & (Button1Mask)){return;}
				 XMoveResizeWindow(disp,active_win,root_x,root_y,300,200);
				}	
			}
		
		 if ((root_x>(dskrw-3)))
			{XMoveResizeWindow(disp,active_win,(dskcw/2)+ow,0+oh, (dskcw/2)-dcw,dskch-dch);}
		 if ((root_x<3))
			{XMoveResizeWindow(disp,active_win,0+ow,0+oh, (dskcw/2)-dcw,dskch-dch);}
		 if ((root_y<3))
			{XMoveResizeWindow(disp,active_win,0+ow,0+oh, (dskcw)-dcw,(dskch/2)-dch);}
		 if ((root_y>(dskrh-3)))
			{XMoveResizeWindow(disp,active_win,0+ow,(dskch/2)+oh, (dskcw)-dcw,(dskch/2)-dch);}
		}
	
	if (place_win==2)
		{
		 if (screen_sec) {Print_screen_sections (disp);}
		
		 while (1)
			{  
			 if(XQueryPointer(disp, root, &ret_root, &ret_child, &root_x, &root_y,
					   &win_x, &win_y, &mask))
				{
				 if (mask & (Button1Mask))
					{
					 if (screen_sec) 
						{Print_screen_sections (disp);}
					 ;return;
					 }
					 
				 /*CenterVerticalB*/
				 if ((root_x>((dskww/16)*7)+ow) & (root_x<((dskww/16)*8)+ow)& (root_y>((dskwh/16)*7)+oh) & (root_y<((dskwh/16)*9)+oh))
				 {XMoveResizeWindow(disp,active_win,0+ow,0+oh,(((dskcw/4)*3)-dcw),dskch-dch);}
				 if ((root_x>((dskww/16)*8)+ow) & (root_x<((dskww/16)*9)+ow)& (root_y>((dskwh/16)*7)+oh) & (root_y<((dskwh/16)*9)+oh))
				 {XMoveResizeWindow(disp,active_win,(dskcw/4)+ow,0+oh,(((dskcw/4)*3)-dcw),dskch-dch);}
				 /*CenterHorizontalB*/
				 if ((root_x>((dskww/16)*7)+ow) & (root_x<((dskww/16)*9)+ow)& (root_y>((dskwh/16)*6)+oh) & (root_y<((dskwh/16)*7)+oh))
				 {XMoveResizeWindow(disp,active_win,0+ow,0+oh,(dskcw-dcw),((dskch/4)*3)-dch);}
				 if ((root_x>((dskww/16)*7)+ow) & (root_x<((dskww/16)*9)+ow)& (root_y>((dskwh/16)*9)+oh) & (root_y<((dskwh/16)*10)+oh))
				 {XMoveResizeWindow(disp,active_win,0+ow,(dskch/4)+oh,(dskcw-dcw),((dskch/4)*3)-dch);}
				 /*CenterVertical*/
				 if ((root_x>((dskww/16)*9)+ow) & (root_x<((dskww/8)*5)+ow)& (root_y>((dskwh/8)*3)+oh) & (root_y<((dskwh/8)*5)+oh))
				 {XMoveResizeWindow(disp,active_win,((dskcw/2))+ow,0+oh,((dskcw/2)-dcw),dskch);}
				 if ((root_x>((dskww/8)*3)+ow) & (root_x<((dskww/16)*7)+ow)& (root_y>((dskwh/8)*3)+oh) & (root_y<((dskwh/8)*5)+oh))
				 {XMoveResizeWindow(disp,active_win,0+ow,0+oh,((dskcw/2)-dcw),dskch);}
				 /*CenterHorizontal*/
				 if ((root_x>((dskww/8)*3)+ow) & (root_x<((dskww/8)*5)+ow)& (root_y>((dskwh/8)*2)+oh) & (root_y<((dskwh/8)*3)+oh))
				 {XMoveResizeWindow(disp,active_win,0+ow,0+oh,(dskcw-dcw),(dskch/2)-dch);}
				 if ((root_x>((dskww/8)*3)+ow) & (root_x<((dskww/8)*5)+ow)& (root_y>((dskwh/8)*5)+oh) & (root_y<((dskwh/8)*6)+oh))
				 {XMoveResizeWindow(disp,active_win,0+ow,(dskch/2)+oh,(dskcw-dcw),(dskch/2)-dch);}
				 /*EastWestVertical*/
				 if ((root_x>((dskww/8)*2)+ow) & (root_x<((dskww/8)*3)+ow)& (root_y>((dskwh/8)*2)+oh) & (root_y<((dskwh/8)*4)+oh))
				 {XMoveResizeWindow(disp,active_win,0+ow,0+oh,((dskcw/2)-dcw),(dskch/2)-dch);}
				 if ((root_x>((dskww/8)*2)+ow) & (root_x<((dskww/8)*3)+ow)& (root_y>((dskwh/8)*4)+oh) & (root_y<((dskwh/8)*6)+oh))
				 {XMoveResizeWindow(disp,active_win,0+ow,(dskch/2)+oh,((dskcw/2)-dcw),(dskch/2)-dch);}
				 if ((root_x>((dskww/8)*5)+ow) & (root_x<((dskww/8)*6)+ow)& (root_y>((dskwh/8)*2)+oh) & (root_y<((dskwh/8)*4)))
				 {XMoveResizeWindow(disp,active_win,((dskcw/2)-dcw)+ow,0+oh,((dskcw/2)-dcw),(dskch/2)-dch);}
				 if ((root_x>((dskww/8)*5)+ow) & (root_x<((dskww/8)*6)+ow)& (root_y>((dskwh/8)*4)+oh) & (root_y<((dskwh/8)*6)))
				 {XMoveResizeWindow(disp,active_win,((dskcw/2)-dcw)+ow,(dskch/2)+oh,((dskcw/2)-dcw),(dskch/2)-dch);}
				 /*MiddleCross*/
				 if ((root_x>((dskww/8)*3)+ow) & (root_x<((dskww/8)*5)+ow)& (root_y>((dskwh/8)*1)+oh) & (root_y<((dskwh/8)*2)+oh))
				 {XMoveResizeWindow(disp,active_win,(((dskcw/8)*1)-dcw)+ow,0+oh,((dskcw/8)*6)-dcw,((dskch/8)*2)-dch);}
				 if ((root_x>((dskww/8)*3)+ow) & (root_x<((dskww/8)*5)+ow)& (root_y>((dskwh/8)*6)+oh) & (root_y<((dskwh/8)*7)+oh))
				 {XMoveResizeWindow(disp,active_win,(((dskcw/8)*1)-dcw)+ow,((dskch/8)*6)+oh,((dskcw/8)*6)-dcw,((dskch/8)*2)-dch);}
				 if ((root_x>((dskww/8)*1)+ow) & (root_x<((dskww/8)*2)+ow)& (root_y>((dskwh/8)*3)+oh) & (root_y<((dskwh/8)*5)+oh))
				 {XMoveResizeWindow(disp,active_win,0+ow,((dskch/8)*1)+oh,(((dskcw/8)*2)-dcw),((dskch/8)*6)-dch);}
				 if ((root_x>((dskww/8)*6)+ow) & (root_x<((dskww/8)*7)+ow)& (root_y>((dskwh/8)*3)+oh) & (root_y<((dskwh/8)*5)+oh))
				 {XMoveResizeWindow(disp,active_win,((dskcw/8)*6)+ow,((dskch/8)*1)+oh,(((dskcw/8)*2)-dcw),((dskch/8)*6)-dch);}
				 /*CornersMiddleScreen*/
				 if ((root_x>((dskww/8)*1)+ow) & (root_x<((dskww/8)*3)+ow)& (root_y>((dskwh/8)*1)+oh) & (root_y<((dskwh/8)*2)+oh))
				 {XMoveResizeWindow(disp,active_win,0+ow,0+oh,(((dskcw/8)*4)-dcw),((dskch/8)*2)-dch);}
				 if ((root_x>((dskww/8)*5)+ow) & (root_x<((dskww/8)*7)+ow)& (root_y>((dskwh/8)*1)+oh) & (root_y<((dskwh/8)*2)+oh))
				 {XMoveResizeWindow(disp,active_win,(((dskcw/8)*4))+ow,0+oh,(((dskcw/8)*4)-dcw),((dskch/8)*2)-dch);}
				 if ((root_x>((dskww/8)*1)+ow) & (root_x<((dskww/8)*3)+ow)& (root_y>((dskwh/8)*6)+oh) & (root_y<((dskwh/8)*7)+oh))
				 {XMoveResizeWindow(disp,active_win,0+ow,((dskch/8)*6)+oh,(((dskcw/8)*4)-dcw),((dskch/8)*2)-dch);}
				 if ((root_x>((dskww/8)*5)+ow) & (root_x<((dskww/8)*7)+ow)& (root_y>((dskwh/8)*6)+oh) & (root_y<((dskwh/8)*7)+oh))
				 {XMoveResizeWindow(disp,active_win,(((dskcw/8)*4))+ow,((dskch/8)*6)+oh,(((dskcw/8)*4)-dcw),((dskch/8)*2)-dch);}
				 if ((root_x>((dskww/8)*1)+ow) & (root_x<((dskww/8)*2)+ow)& (root_y>((dskwh/8)*2)+oh) & (root_y<((dskwh/8)*3)+oh))
				 {XMoveResizeWindow(disp,active_win,0+ow,0+oh,(((dskcw/8)*2)-dcw),((dskch/8)*4)-dch);}
				 if ((root_x>((dskww/8)*6)+ow) & (root_x<((dskww/8)*7)+ow)& (root_y>((dskwh/8)*2)+oh) & (root_y<((dskwh/8)*3)+oh))
				 {XMoveResizeWindow(disp,active_win,((dskcw/8)*6)+ow,0+oh,(((dskcw/8)*2)-dcw),((dskch/8)*4)-dch);}
				 if ((root_x>((dskww/8)*1)+ow) & (root_x<((dskww/8)*2)+ow)& (root_y>((dskwh/8)*5)+oh) & (root_y<((dskwh/8)*6)+oh))
				 {XMoveResizeWindow(disp,active_win,0+ow,((dskch/8)*4)+oh,(((dskcw/8)*2)-dcw),((dskch/8)*4)-dch);}
				 if ((root_x>((dskww/8)*6)+ow) & (root_x<((dskww/8)*7)+ow)& (root_y>((dskwh/8)*5)+oh) & (root_y<((dskwh/8)*6)+oh))
				 {XMoveResizeWindow(disp,active_win,((dskcw/8)*6)+ow,((dskch/8)*4)+oh,(((dskcw/8)*2)-dcw),((dskch/8)*4)-dch);}
				 /*NorthEdge*/
				 if ((root_x>((dskww/8)*0)+ow) & (root_x<((dskww/8)*1)+ow)& (root_y>((dskwh/8)*0)+oh) & (root_y<((dskwh/8)*1)+oh))
				 {XMoveResizeWindow(disp,active_win,((dskcw/8)*0)+ow,((dskch/8)*0)+oh,(((dskcw/8)*3)-dcw),((dskch/8)*1)-dch);}
				 if ((root_x>((dskww/8)*1)+ow) & (root_x<((dskww/8)*3)+ow)& (root_y>((dskwh/8)*0)+oh) & (root_y<((dskwh/8)*1)+oh))
				 {XMoveResizeWindow(disp,active_win,((dskcw/8)*0)+ow,((dskch/8)*0)+oh,(((dskcw/8)*3)-dcw),((dskch/8)*2)-dch);}
				 if ((root_x>((dskww/8)*3)+ow) & (root_x<((dskww/8)*5)+ow)& (root_y>((dskwh/8)*0)+oh) & (root_y<((dskwh/8)*1)+oh))
				 {XMoveResizeWindow(disp,active_win,(((dskcw/8)*2))+ow,((dskch/8)*0)+oh,(((dskcw/8)*4)-dcw),((dskch/8)*2)-dch);}
				 if ((root_x>((dskww/8)*5)+ow) & (root_x<((dskww/8)*7)+ow)& (root_y>((dskwh/8)*0)+oh) & (root_y<((dskwh/8)*1)+oh))
				 {XMoveResizeWindow(disp,active_win,((dskcw/8)*5)+ow,((dskch/8)*0)+oh,(((dskcw/8)*3)-dcw),((dskch/8)*2)-dch);}
				 if ((root_x>((dskww/8)*7)+ow) & (root_x<((dskww/8)*8)+ow)& (root_y>((dskwh/8)*0)+oh) & (root_y<((dskwh/8)*1)+oh))
				 {XMoveResizeWindow(disp,active_win,((dskcw/8)*5)+ow,((dskch/8)*0)+oh,(((dskcw/8)*3)-dcw),((dskch/8)*1)-dch);}
				 /*SouthEdge*/
				 if ((root_x>((dskww/8)*0)+ow) & (root_x<((dskww/8)*1)+ow)& (root_y>((dskwh/8)*7)+oh) & (root_y<(((dskwh/8)*8)+oh)))
				 {XMoveResizeWindow(disp,active_win,((dskcw/8)*0)+ow,((dskch/8)*7)+oh,(((dskcw/8)*3)-dcw),((dskch/8)*1)-dch);}
				 if ((root_x>((dskww/8)*1)+ow) & (root_x<((dskww/8)*3)+ow)& (root_y>((dskwh/8)*7)+oh) & (root_y<((dskwh/8)*7.5)+oh))
				 {XMoveResizeWindow(disp,active_win,((dskcw/8)*0)+ow,((dskch/8)*7)+oh,(((dskcw/8)*3)-dcw),((dskch/8)*2)-dch);}
				 if ((root_x>((dskww/8)*3)+ow) & (root_x<((dskww/8)*5)+ow)& (root_y>((dskwh/8)*7)+oh) & (root_y<((dskwh/8)*7.5)+oh))
				 {XMoveResizeWindow(disp,active_win,(((dskcw/8)*2))+ow,((dskch/8)*7)+oh,(((dskcw/8)*4)-dcw),((dskch/8)*2)-dch);}
				 if ((root_x>((dskww/8)*5)+ow) & (root_x<((dskww/8)*7)+ow)& (root_y>((dskwh/8)*7)+oh) & (root_y<((dskwh/8)*7.5)+oh))
				 {XMoveResizeWindow(disp,active_win,((dskcw/8)*5)+ow,((dskch/8)*7)+oh,(((dskcw/8)*3)-dcw),((dskch/8)*2)-dch);}
				 if ((root_x>((dskww/8)*7)+ow) & (root_x<((dskww/8)*8)+ow)& (root_y>((dskwh/8)*7)+oh) & (root_y<(((dskwh/8)*8)+oh)))
				 {XMoveResizeWindow(disp,active_win,((dskcw/8)*5)+ow,((dskch/8)*7)+oh,(((dskcw/8)*3)-dcw),((dskch/8)*1)-dch);}
				 /*LeftEdge*/
				 if ((root_x>((dskww/8)*0)+ow) & (root_x<((dskww/8)*1)+ow)& (root_y>((dskwh/8)*1)+oh) & (root_y<((dskwh/8)*2)+oh))
				 {XMoveResizeWindow(disp,active_win,((dskcw/8)*0)+ow,((dskch/8)*0)+oh,(((dskcw/8)*1)-dcw),((dskch/8)*2)-dch);}
				 if ((root_x>((dskww/8)*0)+ow) & (root_x<((dskww/8)*1)+ow)& (root_y>((dskwh/8)*2)+oh) & (root_y<((dskwh/8)*3)+oh))
				 {XMoveResizeWindow(disp,active_win,((dskcw/8)*0)+ow,((dskch/8)*0)+oh,(((dskcw/8)*2)-dcw),((dskch/8)*2)-dch);}
				 if ((root_x>((dskww/8)*0)+ow) & (root_x<((dskww/8)*1)+ow)& (root_y>((dskwh/8)*3)+oh) & (root_y<((dskwh/8)*5)+oh))
				 {XMoveResizeWindow(disp,active_win,((dskcw/8)*0)+ow,((dskch/8)*2)+oh,(((dskcw/8)*2)-dcw),((dskch/8)*4)-dch);}
				 if ((root_x>((dskww/8)*0)+ow) & (root_x<((dskww/8)*1)+ow)& (root_y>((dskwh/8)*5)+oh) & (root_y<((dskwh/8)*6)+oh))
				 {XMoveResizeWindow(disp,active_win,((dskcw/8)*0)+ow,((dskch/8)*6)+oh,(((dskcw/8)*2)-dcw),((dskch/8)*2)-dch);}
				 if ((root_x>((dskww/8)*0)+ow) & (root_x<((dskww/8)*1)+ow)& (root_y>((dskwh/8)*6)+oh) & (root_y<((dskwh/8)*7)+oh))
				 {XMoveResizeWindow(disp,active_win,((dskcw/8)*0)+ow,((dskch/8)*6)+oh,(((dskcw/8)*1)-dcw),((dskch/8)*2)-dch);}
				 /*RightEdge*/
				 if ((root_x>((dskww/8)*7)+ow) & (root_x<((dskww/8)*8)+ow)& (root_y>((dskwh/8)*1)+oh) & (root_y<((dskwh/8)*2)+oh))
				 {XMoveResizeWindow(disp,active_win,((dskcw/8)*7)+ow,((dskch/8)*0)+oh,(((dskcw/8)*1)-dcw),((dskch/8)*2)-dch);}
				 if ((root_x>((dskww/8)*7)+ow) & (root_x<((dskww/8)*8)+ow)& (root_y>((dskwh/8)*2)+oh) & (root_y<((dskwh/8)*3)+oh))
				 {XMoveResizeWindow(disp,active_win,((dskcw/8)*6)+ow,((dskch/8)*0)+oh,(((dskcw/8)*2)-dcw),((dskch/8)*2)-dch);}
				 if ((root_x>((dskww/8)*7)+ow) & (root_x<((dskww/8)*8)+ow)& (root_y>((dskwh/8)*3)+oh) & (root_y<((dskwh/8)*5)+oh))
				 {XMoveResizeWindow(disp,active_win,((dskcw/8)*6)+ow,((dskch/8)*2)+oh,(((dskcw/8)*2)-dcw),((dskch/8)*4)-dch);}
				 if ((root_x>((dskww/8)*7)+ow) & (root_x<((dskww/8)*8)+ow)& (root_y>((dskwh/8)*5)+oh) & (root_y<((dskwh/8)*6)+oh))
				 {XMoveResizeWindow(disp,active_win,((dskcw/8)*6)+ow,((dskch/8)*6)+oh,(((dskcw/8)*2)-dcw),((dskch/8)*2)-dch);}
				 if ((root_x>((dskww/8)*7)+ow) & (root_x<((dskww/8)*8)+ow)& (root_y>((dskwh/8)*6)+oh) & (root_y<((dskwh/8)*7)+oh))
				 {XMoveResizeWindow(disp,active_win,((dskcw/8)*7)+ow,((dskch/8)*6)+oh,(((dskcw/8)*1)-dcw),((dskch/8)*2)-dch);}
				 
				 if (win_move_desk)
					{
					 for (i=1;i<nmbrdesks+1;i++)
						{
						 if ((root_x>(((dskww/8)*1)+((((dskww/8)*6)/nmbrdesks)*(i-1)))+ow)
						  & (root_x<(((dskww/8)*1)+((((dskww/8)*6)/nmbrdesks)*i))+ow)
						   & (root_y>((dskwh/16)*15)+oh) & ((root_y<((dskwh/16)*16)+oh)))
								{
								 Client_msg(disp, active_win, "_NET_WM_DESKTOP", i-1,0, 0, 0, 0);
								 XUngrabPointer(disp, CurrentTime);
								 return;
								 }
						}
					}
				}
			}
		}
		
	XMapRaised(disp, active_win);
	XUngrabPointer(disp, CurrentTime);
	
	return;
}

void Print_screen_sections (Display *disp)
{
	int dpw=dskww/8;
	int dph=dskwh/8;
	int ow=deskZx+0;
	int oh=deskZy+0;
	double transparency = 0.4;	/* between 1.0 and 0.0 */
	unsigned int opacity = (unsigned int) (0xffffffff * transparency);
	int blackColor = BlackPixel(disp, DefaultScreen(disp));
	int whiteColor = WhitePixel(disp, DefaultScreen(disp));
	screen_num = DefaultScreen ( disp );
	XSetWindowAttributes xwinattrs;
	xwinattrs.override_redirect = TRUE;
	win = XCreateWindow(disp, RootWindow(disp,screen_num),0,0,dskcw,dskch,0,0,0,0,CWOverrideRedirect,&xwinattrs);
	XSelectInput(disp, win, StructureNotifyMask);
	GC gc = XCreateGC(disp, win, 0, NULL);
	XSetForeground(disp, gc, whiteColor);
	XSetBackground(disp, gc, blackColor);
	XMapWindow(disp,win );
	XStringListToTextProperty ( &window_name, 1, &wname );
	XSetWMProperties ( disp, win, &wname, NULL, NULL, 0, NULL, NULL, NULL );
	Atom atom_window_opacity = XInternAtom(disp, "_NET_WM_WINDOW_OPACITY", TRUE);
	XChangeProperty(disp,win,atom_window_opacity,XA_CARDINAL,32,PropModeReplace,(unsigned char *) &opacity,1);
	XFlush(disp);
	char green[] = "#00FF00";
	Colormap colormap;
	XColor green_col;
	colormap = DefaultColormap(disp, 0);
	XParseColor(disp, colormap, green, &green_col);
	XAllocColor(disp, colormap, &green_col);

	XSetForeground(disp, gc, blackColor);
	XFillRectangle(disp, win, gc, 0, 0, dskww,dskwh);
	XSetForeground(disp, gc, green_col.pixel);

	/*CenterVerticalB*/
	XDrawRectangle(disp, win, gc, ((dpw)*3.5)+ow, ((dph)*3.5)+oh, ((dpw)*0.5), ((dph)*1));
	XDrawRectangle(disp, win, gc, ((dpw)*4)+ow, ((dph)*3.5)+oh, ((dpw)*0.5), ((dph)*1));
	/*CenterHorizontalB*/
	XDrawRectangle(disp, win, gc, ((dpw)*3.5)+ow, ((dph)*3)+oh, ((dpw)*1), ((dph)*0.5));
	XDrawRectangle(disp, win, gc, ((dpw)*3.5)+ow, ((dph)*4.5)+oh, ((dpw)*1), ((dph)*0.5));
	/*CenterVertical*/
	XDrawRectangle(disp, win, gc, ((dpw)*3)+ow, ((dph)*3)+oh, ((dpw)*0.5), ((dph)*2));
	XDrawRectangle(disp, win, gc, ((dpw)*4.5)+ow, ((dph)*3)+oh, ((dpw)*0.5), ((dph)*2));
	/*CenterHorizontal*/
	XDrawRectangle(disp, win, gc, ((dpw)*3)+ow, ((dph)*2)+oh, ((dpw)*2), ((dph)*1));
	XDrawRectangle(disp, win, gc, ((dpw)*3)+ow, ((dph)*5)+oh, ((dpw)*2), ((dph)*1));
	/*EastWestVertical*/
	XDrawRectangle(disp, win, gc, ((dpw)*2)+ow, ((dph)*2)+oh, ((dpw)*1), ((dph)*2));
	XDrawRectangle(disp, win, gc, ((dpw)*2)+ow, ((dph)*4)+oh, ((dpw)*1), ((dph)*2));
	XDrawRectangle(disp, win, gc, ((dpw)*5)+ow, ((dph)*2)+oh, ((dpw)*1), ((dph)*2));
	XDrawRectangle(disp, win, gc, ((dpw)*5)+ow, ((dph)*4)+oh, ((dpw)*1), ((dph)*2));
	/*MiddleCross*/
	XDrawRectangle(disp, win, gc, ((dpw)*3)+ow, ((dph)*1)+oh, ((dpw)*2), ((dph)*1));
	XDrawRectangle(disp, win, gc, ((dpw)*3)+ow, ((dph)*6)+oh, ((dpw)*2), ((dph)*1));
	XDrawRectangle(disp, win, gc, ((dpw)*1)+ow, ((dph)*3)+oh, ((dpw)*1), ((dph)*2));
	XDrawRectangle(disp, win, gc, ((dpw)*6)+ow, ((dph)*3)+oh, ((dpw)*1), ((dph)*2));
	/*CornersMiddleScreen*/
	XDrawRectangle(disp, win, gc, ((dpw)*1)+ow, ((dph)*1)+oh, ((dpw)*2), ((dph)*1));
	XDrawRectangle(disp, win, gc, ((dpw)*5)+ow, ((dph)*1)+oh, ((dpw)*2), ((dph)*1));
	XDrawRectangle(disp, win, gc, ((dpw)*1)+ow, ((dph)*6)+oh, ((dpw)*2), ((dph)*1));
	XDrawRectangle(disp, win, gc, ((dpw)*5)+ow, ((dph)*6)+oh, ((dpw)*2), ((dph)*1));
	XDrawRectangle(disp, win, gc, ((dpw)*1)+ow, ((dph)*2)+oh, ((dpw)*1), ((dph)*1));
	XDrawRectangle(disp, win, gc, ((dpw)*6)+ow, ((dph)*2)+oh, ((dpw)*1), ((dph)*1));
	XDrawRectangle(disp, win, gc, ((dpw)*1)+ow, ((dph)*5)+oh, ((dpw)*1), ((dph)*1));
	XDrawRectangle(disp, win, gc, ((dpw)*6)+ow, ((dph)*5)+oh, ((dpw)*1), ((dph)*1));
	/*NorthEdge*/
	XDrawRectangle(disp, win, gc, ((dpw)*0)+ow, ((dph)*0)+oh, ((dpw)*1), ((dph)*1));
	XDrawRectangle(disp, win, gc, ((dpw)*1)+ow, ((dph)*0)+oh, ((dpw)*2), ((dph)*1));
	XDrawRectangle(disp, win, gc, ((dpw)*3)+ow, ((dph)*0)+oh, ((dpw)*2), ((dph)*1));
	XDrawRectangle(disp, win, gc, ((dpw)*5)+ow, ((dph)*0)+oh, ((dpw)*2), ((dph)*1));
	XDrawRectangle(disp, win, gc, ((dpw)*7)+ow, ((dph)*0)+oh, ((dpw)*1), ((dph)*1));
	/*SouthEdge*/
	XDrawRectangle(disp, win, gc, ((dpw)*0)+ow, ((dph)*7)+oh, ((dpw)*1), (((dph)*1)-1));
	XDrawRectangle(disp, win, gc, ((dpw)*1)+ow, ((dph)*7)+oh, ((dpw)*2), ((dph)*0.5));
	XDrawRectangle(disp, win, gc, ((dpw)*3)+ow, ((dph)*7)+oh, ((dpw)*2), ((dph)*0.5));
	XDrawRectangle(disp, win, gc, ((dpw)*5)+ow, ((dph)*7)+oh, ((dpw)*2), ((dph)*0.5));
	XDrawRectangle(disp, win, gc, ((dpw)*7)+ow, ((dph)*7)+oh, ((dpw)*1), (((dph)*1)-4));
	/*LeftEdge*/
	XDrawRectangle(disp, win, gc, ((dpw)*0)+ow, ((dph)*1)+oh, ((dpw)*1), ((dph)*1));
	XDrawRectangle(disp, win, gc, ((dpw)*0)+ow, ((dph)*2)+oh, ((dpw)*1), ((dph)*1));
	XDrawRectangle(disp, win, gc, ((dpw)*0)+ow, ((dph)*3)+oh, ((dpw)*1), ((dph)*2));
	XDrawRectangle(disp, win, gc, ((dpw)*0)+ow, ((dph)*5)+oh, ((dpw)*1), ((dph)*1));
	XDrawRectangle(disp, win, gc, ((dpw)*0)+ow, ((dph)*6)+oh, ((dpw)*1), ((dph)*1));
	/*RightEdge*/
	XDrawRectangle(disp, win, gc, ((dpw)*7)+ow, ((dph)*1)+oh, ((dpw)*1), ((dph)*1));
	XDrawRectangle(disp, win, gc, ((dpw)*7)+ow, ((dph)*2)+oh, ((dpw)*1), ((dph)*1));
	XDrawRectangle(disp, win, gc, ((dpw)*7)+ow, ((dph)*3)+oh, ((dpw)*1), ((dph)*2));
	XDrawRectangle(disp, win, gc, ((dpw)*7)+ow, ((dph)*5)+oh, ((dpw)*1), ((dph)*1));
	XDrawRectangle(disp, win, gc, ((dpw)*7)+ow, ((dph)*6)+oh, ((dpw)*1), ((dph)*1));
	
	if (win_move_desk)
		{
		 for (i=1;i<nmbrdesks;i++)
			{
			 XDrawRectangle(disp, win, gc, (((dpw)*1)+((((dpw)*6)/nmbrdesks)*i))+ow,((dph)*7.5)+oh,
										 (((dpw)*6)/nmbrdesks),((dph)*0.5));									
			}
		}

	XFlush(disp);
	
	return ;
}

void Stripe_wins (Display *disp, int oh, int ow, int tile_stripes)
{
	for (i = 1; i < winondesk+1;i++ )
		{
		 if (tile_stripes==2)
			{XMoveResizeWindow(disp,winl[i],(((i-1)*(dskcw/winondesk))+ow),0+oh,((dskcw/winondesk)-dcw),dskch-dch);}
		 else
		    {XMoveResizeWindow(disp,winl[i],0+ow,(((i-1)*(dskch/winondesk))+oh),dskcw-dcw,((dskch/winondesk)-dch));}
		}
		
	return;
}

void Get_info_desk (Display *disp)
{
	Window root = DefaultRootWindow(disp);
	unsigned long *cur_desktop = NULL;
	
	cur_desktop = (unsigned long *)Get_property(disp, root, XA_CARDINAL,
					"_NET_CURRENT_DESKTOP", NULL);
	activedesk= (int) *cur_desktop; 
	
	cur_desktop = (unsigned long *)Get_property(disp, root,XA_CARDINAL,
					"_NET_NUMBER_OF_DESKTOPS", NULL);
	nmbrdesks= (int) *cur_desktop; 
	
	cur_desktop = (unsigned long *)Get_property(disp, root, XA_CARDINAL,
					"_NET_DESKTOP_GEOMETRY",NULL);
	dskrw= (int) cur_desktop[0];
	dskrh= (int) cur_desktop[1];
	
	cur_desktop = (unsigned long *)Get_property(disp, root, XA_CARDINAL,
					"_NET_WORKAREA",NULL);
	deskZx= (int) cur_desktop[0];
	deskZy= (int) cur_desktop[1];
	dskww= (int) cur_desktop[2];
	dskwh= (int) cur_desktop[3];
	dskcw=dskww;
	dskch=dskwh;

	return;
}

void Get_info_win_desk (Display *disp)
{
	winondesk=1;
	Window *client_list;
	unsigned long client_list_size;
	int i;
	unsigned long *desktop;

	if ((client_list=Get_client_list(disp,&client_list_size))==NULL) {return;}          
	for (i = 0; i < client_list_size / sizeof(Window); i++) 
		{
		if ((desktop=(unsigned long *)Get_property(disp, client_list[i],
												   XA_CARDINAL, "_NET_WM_DESKTOP", NULL)) == NULL) 
		  {
		   desktop = (unsigned long *)Get_property(disp, client_list[i],
												   XA_CARDINAL, "_WIN_WORKSPACE", NULL);
		  }
		if (desktop!=0)
		{if ((signed long)*desktop==activedesk) {winl[winondesk]=client_list[i];winondesk=winondesk+1;}}   
		}
	winondesk=winondesk-1;
		
	return;
}

void Sort_list(int active_win)
{
	int wintemp=0;
	for (i =1; i < winondesk+1; i++)
		{
		 if (winl[i]==active_win)
			{wintemp=winl[1]; winl[1]=active_win;winl[i]=wintemp;}
		}
}

void Sort_list_xchg(sel_win, last_win)
{
	int b;
	
	for (i =1; i < winondesk+1;i++)
		{
		 if (winl[i]==sel_win){b=i;};
		}
	
	for (i =1; i < winondesk+1;i++)
		{
		 if (winl[i]==last_win){winl[b]=last_win ;winl[i]=sel_win; break;};
		}
	
	return;
}


void Print_info ()
{
	Display *disp = XOpenDisplay(NULL);
	Get_info_desk (disp);
	Get_info_win_desk (disp);
	int active_win= Get_active_window(disp);
	Sort_list (active_win);
	
	printf("Info:\n");
	printf ("Version: %s\n",version);
	printf("Windows on desktop:\n");
	for (i = 1; i < winondesk+1;i++ ){printf("Win id: %i\n",winl[i]);}   
	printf("Number of Windows on desk: %i   \n",winondesk) ;
	printf("Active window id: %i\n",active_win);
	printf("Active desktop: %i   ",activedesk);printf("Desks %i   \n",nmbrdesks);
	printf("Real width %i  ",dskrw);printf("Real height %i \n ",dskrh);
	printf("Work width %i  ",dskww);printf("Work_height %i \n ",dskwh);
	printf("Desk Zero x: %i  ",deskZx); printf("Desk Zero y: %i  \n ",deskZy) ;
	printf("Runtime Var:\n");
	printf("Custm width %f   ",dskcw); printf("Custom height %f\n",dskch) ;
	
	XCloseDisplay(disp);
	return;
}

static int Client_msg (Display *disp, Window win, char *msg, unsigned long data0,
						unsigned long data1,unsigned long data2, unsigned long data3,
						unsigned long data4)
{
	XEvent event;
	long mask = SubstructureRedirectMask | SubstructureNotifyMask;
	
	event.xclient.type = ClientMessage;
	event.xclient.serial = 0;
	event.xclient.send_event = True;
	event.xclient.message_type = XInternAtom(disp, msg, False);
	event.xclient.window = win;
	event.xclient.format = 32;
	event.xclient.data.l[0] = data0;
	event.xclient.data.l[1] = data1;
	event.xclient.data.l[2] = data2;
	event.xclient.data.l[3] = data3;
	event.xclient.data.l[4] = data4;
	
	if (XSendEvent(disp, DefaultRootWindow(disp), False, mask, &event)) 
		{return EXIT_SUCCESS; }
	else 
		{
		 fprintf(stderr, "Cannot send %s event.\n", msg); 
		 return EXIT_FAILURE; 
		}
}

static Window Get_active_window(Display *disp) 
{
	char *prop;
	unsigned long size;
	Window ret = (Window)0;
	prop = Get_property(disp, DefaultRootWindow(disp), XA_WINDOW, 
						"_NET_ACTIVE_WINDOW", &size);
	
	if (prop){ret = *((Window*)prop); g_free(prop);}
	
	return(ret);    
}

static gchar *Get_property (Display *disp, Window win, Atom xa_prop_type, 
                             gchar *prop_name, unsigned long *size) 
{
	int ret_format;
	unsigned long ret_nitems;
	unsigned long ret_bytes_after;
	unsigned long tmp_size;
	unsigned char *ret_prop;
	gchar *ret;
	Atom xa_ret_type;
	Atom xa_prop_name = XInternAtom(disp, prop_name, False);
	
	if (XGetWindowProperty (disp, win, xa_prop_name, 0, MAX_PROPERTY_VALUE_LEN / 4, False,
						    xa_prop_type, &xa_ret_type, &ret_format, &ret_nitems, 
						    &ret_bytes_after, &ret_prop) != Success) 
		{return NULL;}
	
	if (xa_ret_type != xa_prop_type) 
		{XFree(ret_prop); return NULL;}
	
	tmp_size = (ret_format / 8) * ret_nitems;
	ret = g_malloc(tmp_size + 1);
	memcpy(ret, ret_prop, tmp_size);
	ret[tmp_size] = '\0';
	
	if (size) 
		{ *size = tmp_size; }
	
	XFree(ret_prop);
	
	return ret;
}

static Window *Get_client_list (Display *disp, unsigned long *size) 
{
	Window *client_list;
	if ((client_list=(Window *)Get_property(disp, DefaultRootWindow(disp), 
                                          XA_WINDOW, "_NET_CLIENT_LIST", size)) == NULL) 
		{
		 if ((client_list = (Window *)Get_property(disp, DefaultRootWindow(disp), 
                                                XA_CARDINAL, "_WIN_CLIENT_LIST", size)) == NULL) 
			{
			 fputs("Cannot get client list properties. \n"
				"(_NET_CLIENT_LIST or _WIN_CLIENT_LIST)"
					"\n", stderr);
			 return NULL;
			}
		}

	return client_list;
}

static Window Select_Window(Display *disp) 
{
	int status;
	Cursor cursor;
	XEvent event;
	Window target_win = None, root = DefaultRootWindow(disp);
	int buttons = 0;
	int dummyi;
	unsigned int dummy;
	/* Make the target cursor */
	cursor = XCreateFontCursor(disp, XC_crosshair);
	/* Grab the pointer using target cursor, letting it room all over */
	status = XGrabPointer(disp, root, False,ButtonPressMask|ButtonReleaseMask,
						  GrabModeSync,GrabModeAsync, root, cursor, CurrentTime);
	  if (status != GrabSuccess) 
		{
		 fputs("ERROR: Cannot grab mouse.\n", stderr);
		 return 0;
		}
	  while ((target_win == None) || (buttons != 0)) 
		{
		 /* allow one more event */
		 XAllowEvents(disp, SyncPointer, CurrentTime);
		 XWindowEvent(disp, root, ButtonPressMask|ButtonReleaseMask, &event);
		   switch (event.type) 
			 {
			  case ButtonPress:
				if (target_win == None) 
				  {
				   target_win = event.xbutton.subwindow; /* window selected */
					 if (target_win == None) target_win = root;
				  }
			   buttons++;
			   break;
			  case ButtonRelease:
				if (buttons > 0) 
				buttons--;
				break;
			  }
		} 
	XUngrabPointer(disp, CurrentTime);      /* Done with pointer */
	  if (XGetGeometry (disp, target_win, &root, &dummyi, &dummyi,
						&dummy, &dummy, &dummy, &dummy) && target_win != root) 
		{
		target_win = XmuClientWindow (disp, target_win);
		}  
	
	return(target_win);
}

void Del_desk ()
{
	Display *disp = XOpenDisplay(NULL);
	
	Client_msg(disp, DefaultRootWindow(disp), "_NET_NUMBER_OF_DESKTOPS", 
			   nmbrdesks-1, 0, 0, 0, 0); 
	XCloseDisplay(disp);
	
	return;
}

void Empty_desk ()
{
	Display *disp = XOpenDisplay(NULL);
	
	for (i = 0; i < nmbrdesks;i++ )
		{
		 activedesk=i;
		 Get_info_win_desk (disp);
		 if (winondesk==0)
			{
		     Client_msg(disp, DefaultRootWindow(disp), "_NET_CURRENT_DESKTOP", 
			 		   i, 0, 0, 0, 0);
			 XCloseDisplay(disp);
			 return ;
			}
		 }
	
	Client_msg(disp, DefaultRootWindow(disp), "_NET_NUMBER_OF_DESKTOPS", 
			   i+1, 0, 0, 0, 0); 
	Client_msg(disp, DefaultRootWindow(disp), "_NET_CURRENT_DESKTOP", 
			   i, 0, 0, 0, 0);
	
	XCloseDisplay(disp);
	
	return;
}

void Next_win ()
{
	Display *disp = XOpenDisplay(NULL);
	
	Get_info_win_desk (disp);
	int active_win= Get_active_window(disp);	
	
	for (i =1; i < winondesk+1;)
		{
		 if (winl[i]==active_win)
			{
			 if (winl[i+1]!=0)
				{Client_msg(disp, winl[i+1], "_NET_ACTIVE_WINDOW", 
					   0, 0, 0, 0, 0);i=winondesk+2;}
			 else {Client_msg(disp, winl[1], "_NET_ACTIVE_WINDOW", 
					   0, 0, 0, 0, 0);i=winondesk+2;}
			}
		 i=i+1;
		}
	
	XCloseDisplay(disp);
	
	return;
}
	
void Max_remove (Display *disp)
{
	for (i =1; i < winondesk+1; i++)
		{
		Client_msg(disp, winl[i], "_NET_WM_STATE", 
				   XInternAtom(disp,"_NET_WM_STATE_TOGGLE",False), 
				   XInternAtom(disp,"_NET_WM_STATE_MAXIMIZED_VERT", False),
				   XInternAtom (disp,"_NET_WM_STATE_MAXIMIZED_HORZ", False),0,0);
		}
	
	return ;
}

void Min_remove (Display *disp)
{
	for (i =1; i < winondesk+1; i++)
		{Client_msg(disp, winl[i], "_NET_ACTIVE_WINDOW",0, 0, 0, 0, 0);}
	
	return ;
}

void Win_raise (Display *disp)
{
	for (i =1; i < winondesk+1; i++) {XMapRaised(disp, winl[i]);}
	
	return ;
}

void Get_win_layout (int alternative_layout)
{
	int j;
	int winondesk_tmp=winondesk;
	float win_pm_tmp [40][9][4]=
		{
		{{0}},
		{{0,0,1,1}},
		{{0,0,0.666,1},{0.666,0,0.333,1}}, 
		{{0,0,0.5,1},{0.5,0,0.5,0.5},{0.5,0.5,0.5,0.5}},
		{{0,0,0.5,0.5},{0,0.5,0.5,0.5},{0.5,0,0.5,0.5},{0.5,0.5,0.5,0.5}}, 
		{{0,0,0.333,1},{0.333,0,0.333,0.5},{0.666,0,0.333,0.5},{0.333,0.5,0.333,0.5},{0.666,0.5,0.333,0.5}},
		{{0,0,0.333,0.5},{0.333,0,0.333,0.5},{0.666,0,0.333,0.5},{0.333,0.5,0.333,0.5},{0.666,0.5,0.333,0.5},{0,0.5,0.333,0.5}},
		{{0,0,0.333,0.333},{0.333,0,0.333,0.333},{0.666,0,0.333,0.333},{0,0.333,0.333,0.333},{0.333,0.333,0.333,0.333},{0.666,0.333,0.333,0.333},{0,0.666,1,0.333}}, 
		{{0,0,0.5,0.333},{0.5,0,0.5,0.333},{0,0.333,0.333,0.333},{0.333,0.333,0.333,0.333},{0.666,0.333,0.333,0.333},{0,0.666,0.333,0.333},{0.333,0.666,0.333,0.333},{0.666,0.666,0.333,0.333}}, 
		{{0,0,0.333,0.333},{0.333,0,0.333,0.333},{0.666,0,0.333,0.333},{0,0.333,0.333,0.333},{0.333,0.333,0.333,0.333},{0.666,0.333,0.333,0.333},{0,0.666,0.333,0.333},{0.333,0.666,0.333,0.333},{0.666,0.666,0.333,0.333}},
		{{0}},
		{{0,0,1,1}}, 
		{{0,0,0.75,1},{0.75,0,0.25,1}},
		{{0,0,0.75,1},{0.75,0,0.25,0.5},{0.75,0.5,0.25,0.5}}, 
		{{0,0,0.5,1},{0.5,0,0.5,0.333},{0.5,0.333,0.5,0.333},{0.5,0.666,0.5,0.333}}, 
		{{0,0,0.5,1},{0.5,0,0.25,0.5},{0.75,0,0.25,0.5},{0.5,0.5,0.25,0.5},{0.75,0.5,0.25,0.5}},
		{{0,0,0.5,0.5},{0,0.5,0.5,0.5},{0.5,0,0.25,0.5},{0.75,0,0.25,0.5},{0.5,0.5,0.25,0.5},{0.75,0.5,0.25,0.5}}, 
		{{0,0,0.333,1},{0.333,0,0.333,0.333},{0.333,0.333,0.333,0.333},{0.333,0.666,0.333,0.333},{0.666,0,0.333,0.333},{0.666,0.333,0.333,0.333},{0.666,0.666,0.333,0.333}}, 
		{{0,0,0.25,0.5},{0.25,0,0.25,0.5},{0.5,0.0,0.25,0.5},{0.75,0.0,0.25,0.5},{0,0.5,0.25,0.5},{0.25,0.5,0.25,0.5},{0.5,0.5,0.25,0.5},{0.75,0.5,0.25,0.5}}, 
		{{0,0,0.333,0.333},{0.333,0,0.333,0.333},{0.666,0,0.333,0.333},{0,0.333,0.333,0.333},{0.333,0.333,0.333,0.333},{0.666,0.333,0.333,0.333},{0,0.666,0.333,0.333},{0.333,0.666,0.333,0.333},{0.666,0.666,0.333,0.333}},
		{{0}},
		{{0,0,1,1}}, 
		{{0,0,1,0.666},{0,0.666,1,0.333}}, 
		{{0,0,1,0.5},{0,0.5,0.5,0.5},{0.5,0.5,0.5,0.5}}, 
		{{0,0,0.666,1},{0.666,0,0.333,0.333},{0.666,0.333,0.333,0.333},{0.666,0.666,0.333,0.333}}, 
		{{0,0,0.333,1},{0.333,0,0.333,1},{0.666,0,0.333,0.333},{0.666,0.333,0.333,0.333},{0.666,0.666,0.333,0.333}},
		{{0,0,0.25,1},{0.25,0,0.25,1},{0.5,0,0.25,0.5},{0.75,0,0.25,0.5},{0.5,0.5,0.25,0.5},{0.75,0.5,0.25,0.5}}, 
		{{0,0,0.333,0.333},{0.333,0,0.333,0.333},{0.666,0,0.333,0.333},{0,0.333,0.5,0.333},{0.5,0.333,0.5,0.333},{0,0.666,0.5,0.333},{0.5,0.666,0.5,0.333}}, 
		{{0,0,0.5,0.333},{0.5,0,0.5,0.333},{0,0.333,0.333,0.333},{0.333,0.333,0.333,0.333},{0.666,0.333,0.333,0.333},{0,0.666,0.333,0.333},{0.333,0.666,0.333,0.333},{0.666,0.666,0.333,0.333}}, 
		{{0,0,0.333,0.333},{0.333,0,0.333,0.333},{0.666,0,0.333,0.333},{0,0.333,0.333,0.333},{0.333,0.333,0.333,0.333},{0.666,0.333,0.333,0.333},{0,0.666,0.333,0.333},{0.333,0.666,0.333,0.333},{0.666,0.666,0.333,0.333}},
		{{0}},
		{{0,0,1,1}}, 
		{{0,0,1,0.75},{0,0.75,1,0.25}}, 
		{{0,0,1,0.75},{0,0.75,0.5,0.25},{0.5,0.75,0.5,0.25}},  
		{{0,0,1,0.666},{0,0.666,0.333,0.333},{0.333,0.666,0.333,0.333},{0.666,0.666,0.333,0.333}}, 
		{{0,0,0.5,0.5},{0.5,0,0.5,0.5},{0.333,0.5,0.333,0.5},{0.666,0.5,0.333,0.5},{0,0.5,0.333,0.5}},
		{{0,0,1,0.25},{0,0.25,1,0.25},{0,0.5,0.5,0.25},{0.5,0.5,0.5,0.25},{0,0.75,0.5,0.25},{0.5,0.75,0.5,0.25}}, 
		{{0,0,0.333,0.333},{0,0.333,0.333,0.333},{0,0.666,0.333,0.333},{0.333,0,0.333,0.5},{0.333,0.5,0.333,0.5},{0.666,0,0.333,0.5},{0.666,0.5,0.333,0.5}}, 
		{{0,0,0.5,0.333},{0.5,0,0.5,0.333},{0,0.333,0.333,0.333},{0.333,0.333,0.333,0.333},{0.666,0.333,0.333,0.333},{0,0.666,0.333,0.333},{0.333,0.666,0.333,0.333},{0.666,0.666,0.333,0.333}}, 
		{{0,0,0.333,0.333},{0.333,0,0.333,0.333},{0.666,0,0.333,0.333},{0,0.333,0.333,0.333},{0.333,0.333,0.333,0.333},{0.666,0.333,0.333,0.333},{0,0.666,0.333,0.333},{0.333,0.666,0.333,0.333},{0.666,0.666,0.333,0.333}},
		};
	
	winondesk_tmp=winondesk + (alternative_layout *10);
	
	for( i=0;i<9;i++) 
	   {
		for( j=0;j<4;j++) 
		   {win_pm[i][j]=win_pm_tmp[winondesk_tmp][i][j];}
	   }
	
	return;
}

void Graphics_refresh (Display *disp)
{	
	//XFillRectangle ( disp, win, black_gc,0, 0, (BUTWIDTH*3)+12, (BUTHEIGHT*3)+12 );
	
	XFillRectangle ( disp, win, black_gc, BUTTON1_X, BUTTON1_Y,BUTWIDTH, BUTHEIGHT );
	XFillRectangle ( disp, win, black_gc, BUTTON2_X, BUTTON2_Y,BUTWIDTH, BUTHEIGHT );
	XFillRectangle ( disp, win, black_gc, BUTTON3_X, BUTTON3_Y,BUTWIDTH, BUTHEIGHT );
	XFillRectangle ( disp, win, black_gc, BUTTON4_X, BUTTON4_Y,BUTWIDTH, BUTHEIGHT );
	XFillRectangle ( disp, win, black_gc, BUTTON5_X, BUTTON5_Y,BUTWIDTH, BUTHEIGHT );
	XFillRectangle ( disp, win, black_gc, BUTTON6_X, BUTTON6_Y,BUTWIDTH, BUTHEIGHT );
	XFillRectangle ( disp, win, black_gc, BUTTON7_X, BUTTON7_Y,BUTWIDTH, BUTHEIGHT );
	XFillRectangle ( disp, win, black_gc, BUTTON8_X, BUTTON8_Y,BUTWIDTH, BUTHEIGHT );
	XFillRectangle ( disp, win, black_gc, BUTTON9_X, BUTTON9_Y,BUTWIDTH, BUTHEIGHT );
	
	XFillRectangle ( disp, win, color_gc, BUTTON1_X+1, BUTTON1_Y+1,BUTWIDTH-2, BUTHEIGHT-2 );
	XFillRectangle ( disp, win, color_gc, BUTTON2_X+1, BUTTON2_Y+1,BUTWIDTH-2, BUTHEIGHT-2 );
	XFillRectangle ( disp, win, color_gc, BUTTON3_X+1, BUTTON3_Y+1,BUTWIDTH-2, BUTHEIGHT-2 );
	XFillRectangle ( disp, win, color_gc, BUTTON4_X+1, BUTTON4_Y+1,BUTWIDTH-2, BUTHEIGHT-2 );
	XFillRectangle ( disp, win, color_gc, BUTTON5_X+1, BUTTON5_Y+1,BUTWIDTH-2, BUTHEIGHT-2 );
	XFillRectangle ( disp, win, color_gc, BUTTON6_X+1, BUTTON6_Y+1,BUTWIDTH-2, BUTHEIGHT-2 );
	XFillRectangle ( disp, win, color_gc, BUTTON7_X+1, BUTTON7_Y+1,BUTWIDTH-2, BUTHEIGHT-2 );
	XFillRectangle ( disp, win, color_gc, BUTTON8_X+1, BUTTON8_Y+1,BUTWIDTH-2, BUTHEIGHT-2 );
	XFillRectangle ( disp, win, color_gc, BUTTON9_X+1, BUTTON9_Y+1,BUTWIDTH-2, BUTHEIGHT-2 );
	XDrawLine(disp, win, black_gc,BUTTON7_X+2,BUTTON7_Y+2,BUTTON7_X+2+BUTWIDTH-4,BUTTON7_Y+2+BUTHEIGHT-4 );
	XDrawLine(disp, win, black_gc,BUTTON7_X+2,BUTTON7_Y+2+BUTHEIGHT-4,BUTTON7_X+2+BUTWIDTH-4,BUTTON7_Y+2 );
	XDrawLine(disp, win, black_gc,BUTTON7_X+(BUTWIDTH/2),BUTTON7_Y+2,BUTTON7_X+(BUTWIDTH/2),BUTTON7_Y+2+BUTHEIGHT-4 );
	XDrawLine(disp, win, black_gc,BUTTON7_X+2,BUTTON7_Y+(BUTHEIGHT/2),BUTTON7_X+2+BUTWIDTH-4,BUTTON7_Y+(BUTHEIGHT/2));
	XFillRectangle ( disp, win, black_gc, BUTTON8_X+4, BUTTON8_Y+4,BUTWIDTH-8, BUTHEIGHT-8 );
	XDrawRectangle ( disp, win, black_gc, BUTTON9_X+4, BUTTON9_Y+4,BUTWIDTH-8, BUTHEIGHT-8 );
	
	XDrawRectangle ( disp, win, black_gc, BUTTON1_X+1, BUTTON1_Y+1,BUTWIDTH-2, BUTHEIGHT-2);
	XDrawRectangle ( disp, win, black_gc, BUTTON2_X+1, BUTTON2_Y+1,BUTWIDTH-2, BUTHEIGHT-2);
	XDrawRectangle ( disp, win, black_gc, BUTTON3_X+1, BUTTON3_Y+1,BUTWIDTH-2, BUTHEIGHT-2);
	XDrawRectangle ( disp, win, black_gc, BUTTON4_X+1, BUTTON4_Y+1,BUTWIDTH-2, BUTHEIGHT-2);
	XDrawRectangle ( disp, win, black_gc, BUTTON5_X+1, BUTTON5_Y+1,BUTWIDTH-2, BUTHEIGHT-2);
	XDrawRectangle ( disp, win, black_gc, BUTTON6_X+1, BUTTON6_Y+1,BUTWIDTH-2, BUTHEIGHT-2);
	XDrawRectangle ( disp, win, black_gc, BUTTON7_X+1, BUTTON7_Y+1,BUTWIDTH-2, BUTHEIGHT-2);
	XDrawRectangle ( disp, win, black_gc, BUTTON8_X+1, BUTTON8_Y+1,BUTWIDTH-2, BUTHEIGHT-2);
	XDrawRectangle ( disp, win, black_gc, BUTTON9_X+1, BUTTON9_Y+1,BUTWIDTH-2, BUTHEIGHT-2);

	Get_win_layout (0);
	for (i =1; i < winondesk+1; i++) 
	   {
		XDrawRectangle(disp,win,black_gc,(BUTTON1_X+(BUTWIDTH*win_pm [i-1][0])),(BUTTON1_Y+( BUTHEIGHT*win_pm [i-1][1])),
														(win_pm [i-1][2]*BUTWIDTH),(win_pm [i-1][3]*BUTHEIGHT));
		XDrawRectangle(disp,win,black_gc,BUTTON5_X+(((i-1)*(BUTWIDTH/winondesk))),BUTTON5_Y,
															  ((BUTWIDTH/winondesk)),BUTHEIGHT );
		XDrawRectangle(disp,win,black_gc,BUTTON6_X,BUTTON6_Y+(((i-1)*(BUTHEIGHT/winondesk))),
										BUTWIDTH,((BUTHEIGHT/winondesk)));
		}
	
	Get_win_layout (1);
	for (i =1; i < winondesk+1; i++) 
		{XDrawRectangle(disp,win,black_gc,(BUTTON2_X+(BUTWIDTH*win_pm [i-1][0])),(BUTTON2_Y+( BUTHEIGHT*win_pm [i-1][1])),
														 (win_pm [i-1][2]*BUTWIDTH),(win_pm [i-1][3]*BUTHEIGHT));}
	Get_win_layout (2);
	for (i =1; i < winondesk+1; i++) 
		{XDrawRectangle(disp,win,black_gc,(BUTTON3_X+(BUTWIDTH*win_pm [i-1][0])),(BUTTON3_Y+( BUTHEIGHT*win_pm [i-1][1])),
														 (win_pm [i-1][2]*BUTWIDTH),(win_pm [i-1][3]*BUTHEIGHT));}
	Get_win_layout (3);
	for (i =1; i < winondesk+1; i++) 
		{XDrawRectangle(disp,win,black_gc,(BUTTON4_X+(BUTWIDTH*win_pm [i-1][0])),(BUTTON4_Y+( BUTHEIGHT*win_pm [i-1][1])),
														 (win_pm [i-1][2]*BUTWIDTH),(win_pm [i-1][3]*BUTHEIGHT));}
	
}

unsigned char Graphics_get_xchar (Display *disp)
{
	unsigned char key;
	key = 0;
	while ((key==0)&&(clicked==FALSE)&&(rightclicked==FALSE))
		{
		 usleep(10000);
		 XNextEvent ( disp, &event );
		 
		 if (event.type==KeyPress)
			{
			 keysym = XLookupKeysym ( &(event.xkey), 0 );
			 if (keysym <= 255)
				{
				 key = (unsigned char) keysym;
				}
			 else
				{
				 switch ( keysym )
					{
					 break;
					 case XK_Escape:
					 key = 27;
					 break;
					 default:
					 key = '?';
					 break;
					}
				}
			}
		 else
			{
			 if (event.type==Expose)
				{
				 Graphics_refresh (disp);
				 while (XCheckTypedEvent (disp, Expose, &event));
				}
			 else
				{
				 if (event.type==ButtonPress)
					{
					 if (event.xbutton.window==win)
						{
						 if(event.xbutton.button==Button1)
							{
							 clicked = TRUE;
							 mousex = event.xbutton.x;
							 mousey = event.xbutton.y;
							}
						 else
							{rightclicked = TRUE;}
						}
					}
				else
					{if (event.type==ButtonRelease){Graphics_refresh(disp);}}
				}
			}
		}
	
	return key;
}

int Graphics_init (Display *disp, unsigned int win_width, unsigned int win_height )
{
	BUTWIDTH=(BUTHEIGHT*(((float) (dskcw/dskch))));
	WIN_HEIGHT=(BUTHEIGHT*3)+12;
	WIN_WIDTH=(BUTWIDTH*3)+12;
	BUTTON1_X=0;
	BUTTON1_Y=0;
	BUTTON2_X=(BUTWIDTH)+5;
	BUTTON2_Y=0;
	BUTTON3_X=(BUTWIDTH*2)+10;;
	BUTTON3_Y=0;
	BUTTON4_X=0;
	BUTTON4_Y=(BUTHEIGHT)+5;
	BUTTON7_X=(BUTWIDTH)+5;
	BUTTON7_Y=(BUTHEIGHT)+5;
	BUTTON6_X=(BUTWIDTH*2)+10;
	BUTTON6_Y=(BUTHEIGHT)+5;
	BUTTON5_X=0;
	BUTTON5_Y=(BUTHEIGHT*2)+10;
	BUTTON8_X=(BUTWIDTH)+5;
	BUTTON8_Y=(BUTHEIGHT*2)+10;
	BUTTON9_X=(BUTWIDTH*2)+10;
	BUTTON9_Y=(BUTHEIGHT*2)+10;
	
	Window root;
	Window ret_root;
	Window ret_child;
	int root_x=10;
	int root_y=10;
	int win_x;
	int win_y;
	unsigned int mask;
	root = XDefaultRootWindow(disp);
	double transparency = 0.6;	/* between 1.0 and 0.0 */
	unsigned int opacity = (unsigned int) (0xffffffff * transparency);
	int blackColor = BlackPixel(disp, DefaultScreen(disp));
	
	if(XQueryPointer(disp,root,&ret_root,&ret_child,&root_x,&root_y,&win_x,&win_y, &mask));
	int i, j;
	screen_num = DefaultScreen ( disp );
	XSetWindowAttributes xwinattrs;
	xwinattrs.override_redirect = TRUE;
	if (dskww<(WIN_WIDTH/2)+root_x){root_x=dskww-WIN_WIDTH;};
	if (dskwh<(WIN_HEIGHT/2)+root_y){root_y=dskwh-WIN_HEIGHT;};
	XStringListToTextProperty ( &window_name, 1, &wname );
	//XSetWMProperties ( disp, win, &wname, NULL, NULL, 0, NULL, NULL, NULL );
	
	win = XCreateWindow(disp, root, root_x-(WIN_WIDTH/2), root_y-(WIN_HEIGHT/2),WIN_WIDTH, WIN_HEIGHT,0,
					   0, InputOutput, NULL  ,CWOverrideRedirect, &xwinattrs);
	XSelectInput(disp, win, ExposureMask | KeyPressMask | ButtonPressMask | KeyReleaseMask | ButtonReleaseMask | StructureNotifyMask);
	Atom atom_window_opacity = XInternAtom(disp, "_NET_WM_WINDOW_OPACITY", TRUE);
	XChangeProperty(disp,win,atom_window_opacity,XA_CARDINAL,32,PropModeReplace,(unsigned char *) &opacity,1);
	black_gc = XCreateGC ( disp, win, gc_valuemask, &gc_values );
	color_gc = XCreateGC ( disp, win, gc_valuemask, &gc_values );
	
	/* red */
	for ( i=0, j=0; i<64; i++, j++ )
		{
		color_data[i][0] = 1024 * j;
		color_data[i][1] = color_data[i][2] = 0;
		}
	   /* green */
	for ( i=64, j=0; i<128; i++, j++ )
		{
		color_data[i][1] = 1024 * j;
		color_data[i][0] = color_data[i][2] = 0;
		}
	   /* blue */
	for ( i=128, j=0; i<192; i++, j++ )
		{
		color_data[i][2] = 1024 * j;
		color_data[i][0] = color_data[i][1] = 0;
		}
	   /* white */
	for ( i=192, j=0; i<256; i++, j++ )
		{color_data[i][0] = color_data[i][1] = color_data[i][2] = j * 1024;}
	   /* yellow */
		color_data[192][0] = 63 * 1024;
		color_data[192][1] = 63 * 1024;
		color_data[192][2] = 32 * 1024;
	for ( i=0; i<256; i++ )
		{
		color_info.red   = color_data[i][0];
		color_info.green = color_data[i][1];
		color_info.blue  = color_data[i][2];
		XAllocColor ( disp, DefaultColormap ( disp, screen_num ), &color_info );
		color_table[i] = color_info.pixel;
		}
	
	XSetBackground(disp, black_gc, blackColor);
	XSetForeground ( disp, color_gc, color_table[234] );
	
	XMapWindow ( disp, win );

	return TRUE;
}

void Graphics_shutdown (Display *disp)
{
	XFreeGC ( disp, black_gc );
	XFreeGC ( disp, color_gc );
	XCloseDisplay ( disp );
}

void Menu_gui ()
{
	Display *disp = XOpenDisplay ( NULL );
	Get_info_desk (disp);
	Get_info_win_desk (disp);
	if (!Graphics_init (disp, WIN_WIDTH , WIN_HEIGHT)){printf("X11 Error!\n");exit(0);}
	stillused = TRUE;  /* Setting this variable to FALSE will terminate the application */
	
	while (stillused == TRUE)
		{
		 toberefreshed = FALSE;
		 typedchar = Graphics_get_xchar (disp);
		 if (typedchar == 27) {stillused = FALSE;}
		 if (clicked==TRUE)
			{
			 if ((mousex>BUTTON1_X)&&(mousex<(BUTTON1_X+BUTWIDTH))&&(mousey>BUTTON1_Y)&&(mousey<(BUTTON1_Y+BUTHEIGHT)))
				{stillused = FALSE;Graphics_shutdown(disp);Prepare_values (0,0,0,0);}
			 if ((mousex>BUTTON2_X)&&(mousex<(BUTTON2_X+BUTWIDTH))&&(mousey>BUTTON2_Y)&&(mousey<(BUTTON2_Y+BUTHEIGHT)))
				{stillused = FALSE;Graphics_shutdown(disp);Prepare_values (0,0,1,0);}
			 if ((mousex>BUTTON3_X)&&(mousex<(BUTTON3_X+BUTWIDTH))&&(mousey>BUTTON3_Y)&&(mousey<(BUTTON3_Y+BUTHEIGHT)))
				{stillused = FALSE;Graphics_shutdown(disp);Prepare_values (0,0,2,0);}
			 if ((mousex>BUTTON4_X)&&(mousex<(BUTTON4_X+BUTWIDTH))&&(mousey>BUTTON4_Y)&&(mousey<(BUTTON4_Y+BUTHEIGHT)))
				{stillused = FALSE;Graphics_shutdown(disp);Prepare_values (0,0,3,0);}
			 if ((mousex>BUTTON5_X)&&(mousex<(BUTTON5_X+BUTWIDTH))&&(mousey>BUTTON5_Y)&&(mousey<(BUTTON5_Y+BUTHEIGHT)))
				{stillused = FALSE;Graphics_shutdown(disp);Prepare_values (0,2,0,0);}
			 if ((mousex>BUTTON6_X)&&(mousex<(BUTTON6_X+BUTWIDTH))&&(mousey>BUTTON6_Y)&&(mousey<(BUTTON6_Y+BUTHEIGHT)))
				{stillused = FALSE;Graphics_shutdown(disp);Prepare_values (0,1,0,0);}
			 if ((mousex>BUTTON7_X)&&(mousex<(BUTTON7_X+BUTWIDTH))&&(mousey>BUTTON7_Y)&&(mousey<(BUTTON7_Y+BUTHEIGHT)))
				{stillused = FALSE;Graphics_shutdown(disp);screen_sec=1;Prepare_values (2,0,0,0);}
			 if ((mousex>BUTTON8_X)&&(mousex<(BUTTON8_X+BUTWIDTH))&&(mousey>BUTTON8_Y)&&(mousey<(BUTTON8_Y+BUTHEIGHT)))
				{stillused = FALSE;Graphics_shutdown(disp);Prepare_values (0,0,0,1);}
			 if ((mousex>BUTTON9_X)&&(mousex<(BUTTON9_X+BUTWIDTH))&&(mousey>BUTTON9_Y)&&(mousey<(BUTTON9_Y+BUTHEIGHT)))
				{stillused = FALSE;Graphics_shutdown(disp);Empty_desk();}
			 else {Graphics_shutdown(disp);}
			 clicked = FALSE;
			}
		 if(toberefreshed == TRUE){Graphics_refresh (disp);}
		 rightclicked = FALSE;
		}
	
	return;
}

void LinSnap () 
{
	Display *disp = XOpenDisplay(NULL);
	Get_info_desk (disp);
	Get_info_win_desk (disp);
	int winsn[20][6]={{0},};
	int winsnb[20][6]={{0}}; 
	for (i =1; i < 20; i++)
		   {winsn[i][5]=0;}
	int x, y, junkx, junky,wait;
	unsigned int wwidth, wheight, bw, depth;
	Window junkroot;
	
	for (i =1; i < winondesk+1; i++)
		{
		 if (!XGetGeometry (disp,winl[i],&junkroot,&junkx,&junky,&wwidth,&wheight,&bw,&depth))
			   { ;}
		 else 
			{
			 XTranslateCoordinates (disp,winl[i],junkroot,junkx,junky,&x,&y,&junkroot);
			 winsnb[i][0]=winl[i];
			 winsnb[i][1]=x;
			 winsnb[i][2]=y;
			 winsnb[i][3]=wwidth;
			 winsnb[i][4]=wheight;
			}
		}       
	
	while (1)
		{
		 usleep (100000);
		 wait=0;
		 Get_info_desk (disp);
		 Get_info_win_desk (disp);
		 for (i =1; i < winondesk+1; i++)
			{
			 if (!XGetGeometry (disp,winl[i],&junkroot,&junkx,&junky,&wwidth,&wheight,&bw,&depth)){ ;}
			 else 
				{
				 XTranslateCoordinates (disp,winl[i],junkroot,junkx,junky,&x,&y,&junkroot);
				 winsn[i][0]=winl[i];
				 winsn[i][1]=x;//printf ("winsnx %i        ",winsn[i][1]);
				 winsn[i][2]=y;//printf ("winsny %i\n",winsn[i][2]);
				 winsn[i][3]=wwidth;
				 winsn[i][4]=wheight;
				 }
			 if ((winsn[i][2]<50) && (winsnb[i][2]>y)) 
				{
				 int ev, er, ma, mi;
				 if(!XTestQueryExtension(disp, &ev, &er, &ma, &mi))
					{fprintf(stderr, "XTest extension not supported on server.\n");exit(1);}
				 XTestFakeButtonEvent(disp, 1, True, CurrentTime);
				 XTestFakeButtonEvent(disp, 1, False, CurrentTime);
				 XMoveResizeWindow(disp,winsn[i][0],0,0,dskcw-dcw,dskch-dch);
				 winsn[i][5]=1;wait=1; XFlush(disp);      
				}
			 if ((winsn[i][1]<5) && (winsnb[i][1]>x)) 
				{
				 int ev, er, ma, mi;
				 if(!XTestQueryExtension(disp, &ev, &er, &ma, &mi))
					{fprintf(stderr, "XTest extension not supported on server.\n");exit(1);}
				 XTestFakeButtonEvent(disp, 1, True, CurrentTime);
				 XTestFakeButtonEvent(disp, 1, False, CurrentTime);
				 XMoveResizeWindow(disp,winsn[i][0],0,0,(dskcw/2)-dcw,dskch-dch);
				 winsn[i][5]=1;wait=1; XFlush(disp);
				}
			 if ((winsn[i][1]+winsn[i][3]>dskww-5) && (winsnb[i][1]<x)) 
				{
				 int ev, er, ma, mi;
				 if(!XTestQueryExtension(disp, &ev, &er, &ma, &mi))
					{fprintf(stderr, "XTest extension not supported on server.\n");exit(1);}
				 XTestFakeButtonEvent(disp, 1, True, CurrentTime);
				 XTestFakeButtonEvent(disp, 1, False, CurrentTime);
				 XMoveResizeWindow(disp,winsn[i][0],(dskcw/2),0,(dskcw/2)-dcw,dskch-dch);
				 winsn[i][5]=1;wait=1;
				 XFlush(disp);
				}
			}
		 
		 for (i =1; i < winondesk+1; i++)
			{
			 if (!XGetGeometry (disp,winl[i],&junkroot,&junkx,&junky,&wwidth,&wheight,&bw,&depth))
				{ ;}
			 else 
				{
				 XTranslateCoordinates (disp,winl[i],junkroot,junkx,junky,&x,&y,&junkroot);
				 winsnb[i][0]=winl[i];
				 winsnb[i][1]=x;
				 winsnb[i][2]=y;
				 winsnb[i][3]=wwidth;
				 winsnb[i][4]=wheight;
				}
			}       
		}
}
